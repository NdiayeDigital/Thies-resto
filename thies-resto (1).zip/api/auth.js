// ---------------------------------------------------------------------------
// Serverless Authentication Proxy Handler (Zero Payload Logging)
// ---------------------------------------------------------------------------
import crypto from 'crypto';

const SESSION_SIGNING_KEY = process.env.SESSION_SECRET || 'thies_resto_production_session_signing_secret_2026';

function timingSafeStringEqual(a, b) {
  if (typeof a !== 'string' || typeof b !== 'string') return false;
  const bufA = Buffer.from(a);
  const bufB = Buffer.from(b);
  if (bufA.length !== bufB.length) {
    crypto.timingSafeEqual(bufA, bufA);
    return false;
  }
  return crypto.timingSafeEqual(bufA, bufB);
}

function generateSignedToken(payload) {
  const data = Buffer.from(JSON.stringify({
    ...payload,
    iat: Math.floor(Date.now() / 1000),
    exp: Math.floor(Date.now() / 1000) + (7 * 24 * 3600),
    nonce: crypto.randomBytes(16).toString('hex')
  })).toString('base64url');
  
  const signature = crypto
    .createHmac('sha256', SESSION_SIGNING_KEY)
    .update(data)
    .digest('base64url');
    
  return `${data}.${signature}`;
}

function cleanAuthString(str) {
  return String(str || '')
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .toLowerCase()
    .replace(/[^a-z0-9]/g, '');
}

const KNOWN_RESTAURANTS = [
  { id: 'r1', name: 'Restaurant Madiba', slug: 'restaurant-madiba', username: 'id_restaurantmadiba' },
  { id: 'r2', name: 'Le Jardin des Saveurs', slug: 'le-jardin-des-saveurs', username: 'id_lejardindessaveurs' },
  { id: 'r3', name: 'La Licorne', slug: 'la-licorne', username: 'id_lalicorne' },
  { id: 'r4', name: 'Le Croissant Magique', slug: 'le-croissant-magique', username: 'id_croissantmagique' },
  { id: 'r5', name: 'Le Dibi d\'Or', slug: 'le-dibi-dor', username: 'id_ledibidor' },
  { id: 'r6', name: 'Chez Penda Thiès', slug: 'chez-penda-thies', username: 'id_chezpendathies' },
  { id: 'r7', name: 'O\'Gourmet Thiès', slug: 'ogourmet-thies', username: 'id_ogourmet' },
  { id: 'r8', name: 'Fast-Food Le Rail', slug: 'fast-food-le-rail', username: 'id_fastfoodlerail' }
];

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Credentials', true);
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET,OPTIONS,POST');
  res.setHeader(
    'Access-Control-Allow-Headers',
    'X-CSRF-Token, X-Requested-With, Accept, Accept-Version, Content-Length, Content-MD5, Content-Type, Date, X-Api-Version'
  );
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-XSS-Protection', '1; mode=block');
  res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');

  if (req.method === 'OPTIONS') {
    return res.status(200).end();
  }

  const { action } = req.query || {};

  try {
    if (req.method === 'GET' && (action === 'verify-session' || req.url.includes('verify-session'))) {
      const authHeader = req.headers['authorization'] || '';
      const token = authHeader.startsWith('Bearer ') ? authHeader.substring(7) : (req.query.token || '');
      const payload = verifySignedToken(token);
      if (payload) {
        return res.status(200).json({ valid: true, session: payload });
      }
      return res.status(401).json({ valid: false, message: 'Session invalide ou expirée.' });
    }

    if (req.method === 'POST' && (action === 'admin' || req.url.includes('admin'))) {
      const { username, password } = req.body || {};
      const userClean = cleanAuthString(username);
      const passClean = String(password || '').trim();

      const userRaw = String(username || '').trim().toLowerCase();
      const isAdminUser = userClean === 'admin' || userClean === 'thiesresto' || userClean === 'superadmin' || userClean === 'root' || userRaw === 'thiesresto.th@gmail.com' || userClean === 'thiesrestothgmailcom';
      const strongAdminPass = process.env.ADMIN_PASSWORD || 'thiesresto221';

      // Strict timing-safe validation against strong admin password: NO length>=3 bypass, NO weak fallbacks ('admin', '1234')
      const isPassValid = timingSafeStringEqual(passClean, strongAdminPass);

      if (isAdminUser && isPassValid) {
        const token = generateSignedToken({
          role: 'superadmin',
          name: 'Super Admin THIES Resto',
          scope: 'full_platform'
        });

        return res.status(200).json({
          success: true,
          role: 'superadmin',
          name: 'Super Admin THIES Resto',
          token,
          authenticatedAt: new Date().toISOString()
        });
      }

      return res.status(401).json({ success: false, message: 'Identifiants administrateur invalides ou non reconnus.' });
    }

    if (req.method === 'POST') {
      const { username, password } = req.body || {};
      const rawUser = String(username || '').trim();
      const cleanUser = cleanAuthString(rawUser).replace(/^id_?/, '');

      let matched = KNOWN_RESTAURANTS.find(r => {
        const rSlug = cleanAuthString(r.slug);
        const rName = cleanAuthString(r.name);
        const rUser = cleanAuthString(r.username);
        return (
          rSlug === cleanUser || 
          rName === cleanUser || 
          rUser === cleanUser ||
          (cleanUser.length >= 3 && (rName.includes(cleanUser) || rSlug.includes(cleanUser)))
        );
      });

      if (!matched && cleanUser) {
        matched = {
          id: 'id_' + cleanUser,
          name: rawUser ? rawUser.charAt(0).toUpperCase() + rawUser.slice(1) : 'Restaurant Partenaire',
          slug: cleanUser || 'resto'
        };
      } else if (!matched) {
        matched = KNOWN_RESTAURANTS[0];
      }

      const sessionData = {
        id: matched.id,
        name: matched.name,
        slug: matched.slug,
        status: 'active',
        role: 'restaurant_partner'
      };

      const token = generateSignedToken(sessionData);

      return res.status(200).json({
        success: true,
        session: sessionData,
        token,
        authenticatedAt: new Date().toISOString()
      });
    }

    return res.status(404).json({ success: false, message: 'Endpoint auth non trouvé.' });
  } catch (err) {
    return res.status(500).json({ success: false, message: 'Erreur proxy auth.' });
  }
}
