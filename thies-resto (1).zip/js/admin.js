// Page: RESTAURANT DASHBOARD (Gerer ses donnees)
// ----------------------------------------------------
let dashboardActiveTab = 'accounting';
let currentOrderStatusFilter = 'Tous';
let currentAccountingFilter = 'all'; // all, today, week, month
window.currentOrdersSubView = window.currentOrdersSubView || 'orders';
window.currentDishesSubView = window.currentDishesSubView || 'all';
window.currentAccountSubView = window.currentAccountSubView || 'profile';

router.add('#/dashboard', () => {
    // Hide cart
    const cart = document.getElementById('floating-cart-bar');
    if (cart) cart.style.display = 'none';
    
    if (!currentRestaurantSession) {
        showToast("Veuillez vous connecter pour accéder au tableau de bord.", "danger");
        router.navigate('/auth');
        return;
    }
    
    dashboardActiveTab = 'accounting';
    startOrderPolling(currentRestaurantSession.id);
    hideLoadingOverlay();
    renderDashboardShell();
});

router.add('#/dashboard-accounting', () => {
    const cart = document.getElementById('floating-cart-bar');
    if (cart) cart.style.display = 'none';
    if (!currentRestaurantSession) {
        router.navigate('/auth');
        return;
    }
    dashboardActiveTab = 'accounting';
    startOrderPolling(currentRestaurantSession.id);
    hideLoadingOverlay();
    renderDashboardShell();
});

router.add('#/dashboard-orders', () => {
    const cart = document.getElementById('floating-cart-bar');
    if (cart) cart.style.display = 'none';
    if (!currentRestaurantSession) {
        router.navigate('/auth');
        return;
    }
    dashboardActiveTab = 'orders';
    window.currentOrdersSubView = 'orders';
    startOrderPolling(currentRestaurantSession.id);
    hideLoadingOverlay();
    renderDashboardShell();
});

router.add('#/dashboard-reservations', () => {
    const cart = document.getElementById('floating-cart-bar');
    if (cart) cart.style.display = 'none';
    if (!currentRestaurantSession) {
        router.navigate('/auth');
        return;
    }
    dashboardActiveTab = 'orders';
    window.currentOrdersSubView = 'reservations';
    startOrderPolling(currentRestaurantSession.id);
    hideLoadingOverlay();
    renderDashboardShell();
});

router.add('#/dashboard-dishes', () => {
    const cart = document.getElementById('floating-cart-bar');
    if (cart) cart.style.display = 'none';
    if (!currentRestaurantSession) {
        router.navigate('/auth');
        return;
    }
    dashboardActiveTab = 'dishes';
    startOrderPolling(currentRestaurantSession.id);
    hideLoadingOverlay();
    renderDashboardShell();
});

router.add('#/dashboard-dishes', () => {
    const cart = document.getElementById('floating-cart-bar');
    if (cart) cart.style.display = 'none';
    if (!currentRestaurantSession) {
        router.navigate('/auth');
        return;
    }
    dashboardActiveTab = 'dishes';
    window.currentDishesSubView = 'all';
    startOrderPolling(currentRestaurantSession.id);
    hideLoadingOverlay();
    renderDashboardShell();
});

router.add('#/dashboard-menu', () => {
    const cart = document.getElementById('floating-cart-bar');
    if (cart) cart.style.display = 'none';
    if (!currentRestaurantSession) {
        router.navigate('/auth');
        return;
    }
    dashboardActiveTab = 'dishes';
    window.currentDishesSubView = 'all';
    startOrderPolling(currentRestaurantSession.id);
    hideLoadingOverlay();
    renderDashboardShell();
});

router.add('#/dashboard-add-menu', () => {
    const cart = document.getElementById('floating-cart-bar');
    if (cart) cart.style.display = 'none';
    if (!currentRestaurantSession) {
        router.navigate('/auth');
        return;
    }
    dashboardActiveTab = 'dishes';
    window.currentDishesSubView = 'add';
    startOrderPolling(currentRestaurantSession.id);
    hideLoadingOverlay();
    renderDashboardShell();
});

router.add('#/dashboard-daily-menu', () => {
    const cart = document.getElementById('floating-cart-bar');
    if (cart) cart.style.display = 'none';
    if (!currentRestaurantSession) {
        router.navigate('/auth');
        return;
    }
    dashboardActiveTab = 'dishes';
    window.currentDishesSubView = 'daily';
    startOrderPolling(currentRestaurantSession.id);
    hideLoadingOverlay();
    renderDashboardShell();
});

router.add('#/dashboard-account', () => {
    const cart = document.getElementById('floating-cart-bar');
    if (cart) cart.style.display = 'none';
    if (!currentRestaurantSession) {
        router.navigate('/auth');
        return;
    }
    dashboardActiveTab = 'account';
    window.currentAccountSubView = 'profile';
    startOrderPolling(currentRestaurantSession.id);
    hideLoadingOverlay();
    renderDashboardShell();
});

router.add('#/dashboard-subscription', () => {
    const cart = document.getElementById('floating-cart-bar');
    if (cart) cart.style.display = 'none';
    if (!currentRestaurantSession) {
        router.navigate('/auth');
        return;
    }
    dashboardActiveTab = 'account';
    window.currentAccountSubView = 'subscription';
    startOrderPolling(currentRestaurantSession.id);
    hideLoadingOverlay();
    renderDashboardShell();
});

router.add('#/dashboard-reviews', () => {
    const cart = document.getElementById('floating-cart-bar');
    if (cart) cart.style.display = 'none';
    if (!currentRestaurantSession) {
        router.navigate('/auth');
        return;
    }
    dashboardActiveTab = 'account';
    window.currentAccountSubView = 'reviews';
    startOrderPolling(currentRestaurantSession.id);
    hideLoadingOverlay();
    renderDashboardShell();
});

router.add('#/dashboard-reports', () => {
    const cart = document.getElementById('floating-cart-bar');
    if (cart) cart.style.display = 'none';
    if (!currentRestaurantSession) {
        router.navigate('/auth');
        return;
    }
    dashboardActiveTab = 'reports';
    startOrderPolling(currentRestaurantSession.id);
    hideLoadingOverlay();
    renderDashboardShell();
});

function renderDashboardShell() {
    const container = document.getElementById('main-content');
    if (!currentRestaurantSession || !currentRestaurantSession.id) {
        router.navigate('/auth');
        return;
    }
    let r = store.getRestaurantById(currentRestaurantSession.id);
    if (!r) {
        const seedList = typeof SEED_RESTAURANTS !== 'undefined' ? SEED_RESTAURANTS : [];
        r = seedList.find(x => x.id === currentRestaurantSession.id || x.slug === currentRestaurantSession.slug || x.username === currentRestaurantSession.slug) || {
            id: currentRestaurantSession.id,
            name: currentRestaurantSession.name || "Mon Restaurant",
            slug: currentRestaurantSession.slug || "restaurant",
            status: "active",
            category: "Traditionnel",
            menu: [],
            reviews: [],
            createdAt: '2026-06-25T00:00:00Z',
            subscriptionPack: 'Pack Pro (Annuel)'
        };
        // Register in store so subsequent calls work seamlessly
        if (store && store.data && Array.isArray(store.data.restaurants)) {
            const exists = store.data.restaurants.some(item => item.id === r.id);
            if (!exists) store.data.restaurants.push(r);
        }
    }
    
    let impersonateBanner = '';
    if (isSuperAdminSession) {
        impersonateBanner = `
            <div style="background: rgba(239, 68, 68, 0.08); border: 1px solid rgba(239, 68, 68, 0.2); color: var(--text-primary); padding: 0.75rem 1.25rem; display: flex; justify-content: space-between; align-items: center; font-size: 0.85rem; font-weight: 600; border-radius: 14px; margin: 1rem auto 0 auto; max-width: 1200px;">
                <div style="display: flex; align-items: center; gap: 0.5rem;">
                    <i class='ri-shield-user-fill' style="color: var(--danger); font-size: 1.1rem;"></i>
                    <span>Mode Super-Admin : Gestion de « <strong>${r.name}</strong> »</span>
                </div>
                <button class="btn btn-secondary btn-sm" onclick="exitImpersonation()" style="font-weight: 600; font-size: 0.8rem; padding: 0.35rem 0.75rem;">
                    <i class='ri-arrow-go-back-line'></i> Console Principale
                </button>
            </div>
        `;
    }
    
    // Check trial expiry for paywall (7-day trial policy)
    const _createdAt = new Date(r.createdAt || '2026-06-25T00:00:00Z');
    const _diffTime = Math.abs(new Date() - _createdAt);
    const _diffDays = Math.ceil(_diffTime / (1000 * 60 * 60 * 24));
    const _packSubscribed = r.subscriptionPack || 'Essai 7 Jours (Gratuit)';
    const isPaidPack = (_packSubscribed && !_packSubscribed.includes('Gratuit') && !_packSubscribed.includes('Essai') && !_packSubscribed.includes('Aucun')) || r.hasPaidSubscription || r.status === 'active';
    const isTrialExpired = _diffDays > 7 && !isPaidPack && !isSuperAdminSession && r.status === 'suspended';
    const daysLeftTrial = Math.max(0, 7 - _diffDays);

    // Alert banner for expired trials or active trial countdown
    let trialAlertBanner = '';
    if (isTrialExpired) {
        trialAlertBanner = `
            <div style="background: rgba(239, 68, 68, 0.1); border: 1px solid rgba(239, 68, 68, 0.3); color: var(--text-primary); padding: 1rem 1.25rem; border-radius: 14px; margin: 1rem auto 0 auto; max-width: 1200px; display: flex; align-items: center; justify-content: space-between; gap: 1rem; flex-wrap: wrap;">
                <div style="display: flex; align-items: center; gap: 0.75rem;">
                    <i class='ri-error-warning-fill' style="font-size: 1.5rem; color: var(--danger);"></i>
                    <div>
                        <strong style="font-size: 0.95rem; display: block; color: var(--danger);">Période d'essai de 7 jours terminée (Compte Désactivé)</strong>
                        <p style="margin: 0; color: var(--text-secondary); font-size: 0.82rem;">Vos 7 jours d'accès offert sont écoulés. Choisissez un abonnement pour réactiver immédiatement la visibilité et la réception de commandes.</p>
                    </div>
                </div>
                <div style="display: flex; gap: 0.5rem; flex-wrap: wrap;">
                    <button class="btn btn-primary btn-sm" onclick="switchDashboardTab('subscription', 'wow')" style="font-weight: 700; font-size: 0.82rem; background: linear-gradient(135deg, #0284c7, #2563eb); border: none;">
                        <i class='ri-bank-card-line'></i> Voir les Avantages & M'Abonner
                    </button>
                </div>
            </div>
        `;
    } else if (!isPaidPack) {
        trialAlertBanner = `
            <div style="background: linear-gradient(135deg, rgba(245, 158, 11, 0.08), rgba(16, 185, 129, 0.08)); border: 1px solid rgba(245, 158, 11, 0.25); color: var(--text-primary); padding: 0.75rem 1.25rem; border-radius: 14px; margin: 1rem auto 0 auto; max-width: 1200px; display: flex; align-items: center; justify-content: space-between; gap: 1rem; flex-wrap: wrap;">
                <div style="display: flex; align-items: center; gap: 0.75rem;">
                    <span style="font-size: 1.3rem;"><i class='ri-gift-line'></i></span>
                    <div>
                        <span style="font-size: 0.88rem; font-weight: 700; color: var(--text-primary);">Période d'essai gratuit : <strong>${daysLeftTrial} jour(s) restant(s)</strong> (sur 7 jours offerts)</span>
                        <p style="margin: 0; color: var(--text-secondary); font-size: 0.78rem;">Testez la réception de commandes WhatsApp et le QR Code à 0% de commission !</p>
                    </div>
                </div>
                <div style="display: flex; gap: 0.5rem; flex-wrap: wrap;">
                    <button class="btn btn-primary btn-sm" onclick="switchDashboardTab('subscription', 'wow')" style="font-weight: 700; font-size: 0.8rem; background: linear-gradient(135deg, #f59e0b, #d97706); border: none; box-shadow: 0 4px 12px rgba(245, 158, 11, 0.25);">
                        <i class='ri-sparkling-fill'></i> Voir la Démo Waouh & Formules
                    </button>
                </div>
            </div>
        `;
    }

    const isSuspended = r.status === 'suspended';
    const statusBadgeHtml = isSuspended
        ? `<span class="badge" style="font-size: 0.72rem; padding: 0.25rem 0.55rem; border-radius: 6px; font-weight: 800; background: #fee2e2; color: #dc2626; border: 1px solid #fca5a5; display: inline-flex; align-items: center; gap: 0.25rem;"><i class='ri-lock-2-line'></i> SUSPENDU</span>`
        : `<span class="badge ${r.isOpenManual ? 'badge-success' : 'badge-danger'}" style="font-size: 0.72rem; padding: 0.25rem 0.55rem; border-radius: 6px; font-weight: 700;">${r.isOpenManual ? 'OUVERT' : 'FERMÉ'}</span>`;

    let suspendedAlertBanner = '';
    if (isSuspended) {
        suspendedAlertBanner = `
            <div style="background: #fef2f2; border: 1px solid #f87171; color: #991b1b; padding: 0.85rem 1.25rem; border-radius: 14px; margin: 1rem auto; max-width: 1200px; display: flex; align-items: center; justify-content: space-between; gap: 1rem; flex-wrap: wrap;">
                <div style="display: flex; align-items: center; gap: 0.75rem;">
                    <i class='ri-error-warning-fill' style="font-size: 1.5rem; color: #dc2626;"></i>
                    <div>
                        <strong style="font-size: 0.95rem; color: #b91c1c; display: block;">Restaurant actuellement SUSPENDU</strong>
                        <p style="margin: 0; font-size: 0.82rem; color: #7f1d1d;">${r.suspendReason || 'Suspension manuelle par l\'administration'}. La visibilité publique et les commandes clients sont coupées.</p>
                    </div>
                </div>
                ${isSuperAdminSession ? `
                <button class="btn btn-sm" onclick="reactivateRestaurant('${r.id}'); setTimeout(renderDashboardShell, 150);" style="background: #16a34a; color: white; border: none; font-weight: 700; padding: 0.45rem 0.85rem; border-radius: 8px; cursor: pointer; display: inline-flex; align-items: center; gap: 0.35rem;">
                    <i class='ri-checkbox-circle-line'></i> Réactiver le restaurant
                </button>
                ` : ''}
            </div>
        `;
    }

    const isAccounting = dashboardActiveTab === 'accounting' || dashboardActiveTab === 'summary' || dashboardActiveTab === 'dashboard';
    const isOrders = dashboardActiveTab === 'orders' || dashboardActiveTab === 'reservations' || dashboardActiveTab === 'consumer';
    const isDishes = dashboardActiveTab === 'dishes' || dashboardActiveTab === 'menu' || dashboardActiveTab === 'add-menu' || dashboardActiveTab === 'daily-menu' || dashboardActiveTab === 'products';
    const isReports = dashboardActiveTab === 'reports' || dashboardActiveTab === 'report';
    const isAccount = dashboardActiveTab === 'account' || dashboardActiveTab === 'settings' || dashboardActiveTab === 'reviews' || dashboardActiveTab === 'profile';
    const isSubscription = dashboardActiveTab === 'subscription';

    // Calcul du nombre de commandes en attente pour le badge
    const currentOrders = store.getOrdersByRestaurant(r.id);
    const pendingOrdersCount = currentOrders.filter(o => o.status === 'En attente' || o.status === 'Reçue').length;

    container.innerHTML = `
        <div class="gr-dashboard-container">
            ${impersonateBanner}
            ${suspendedAlertBanner}
            ${trialAlertBanner}

            <!-- Manager Top Bar (Desktop & Mobile) -->
            <div class="gr-manager-top-bar">
                <div style="display: flex; align-items: center; gap: 0.75rem;">
                    <div class="gr-brand-logo" style="width: 42px; height: 42px; font-size: 1.25rem; border-radius: 12px; display: flex; align-items: center; justify-content: center; background: var(--primary, #0B3B24); color: #ffffff; font-weight: 800; flex-shrink: 0;">
                        ${(r.name || 'G').charAt(0).toUpperCase()}
                    </div>
                    <div>
                        <div style="display: flex; align-items: center; gap: 0.5rem; flex-wrap: wrap;">
                            <span style="font-weight: 800; font-size: 1.05rem; color: var(--text-primary); line-height: 1.2;">${r.name}</span>
                            ${statusBadgeHtml}
                        </div>
                        <div style="font-size: 0.75rem; color: var(--text-secondary); margin-top: 2px;">Thiès Resto Partner • Espace Gérant</div>
                    </div>
                </div>

                <div style="display: flex; align-items: center; gap: 0.5rem;">
                    <!-- Bouton 3 Points (Menu Navigation) -->
                    <div class="gr-more-menu-wrapper">
                        <button id="gr-three-dots-btn" class="gr-three-dots-btn" onclick="toggleManagerDropdown(event)" title="Menu de gestion" aria-label="Menu de navigation Espace Gérant">
                            <i class='ri-more-2-fill' style="font-size: 1.4rem;"></i>
                        </button>

                        <!-- Menu déroulant Espace Gérant -->
                        <div id="gr-manager-dropdown" class="gr-manager-dropdown" style="display: none;">
                            <div style="padding: 0.6rem 0.85rem; border-bottom: 1px solid var(--border); margin-bottom: 0.35rem;">
                                <div style="font-weight: 700; font-size: 0.88rem; color: var(--text-primary);">${r.name}</div>
                                <div style="font-size: 0.72rem; color: var(--text-secondary);">Menu Espace Gérant</div>
                            </div>
                            <button class="gr-dropdown-item ${isAccounting ? 'active' : ''}" onclick="switchDashboardTab('accounting'); closeManagerDropdown();">
                                <i class='ri-home-4-line'></i>
                                <span>Dashboard</span>
                            </button>
                            <button class="gr-dropdown-item ${isOrders ? 'active' : ''}" onclick="switchDashboardTab('orders'); closeManagerDropdown();">
                                <i class='ri-shopping-bag-3-line'></i>
                                <span>Commandes</span>
                                ${pendingOrdersCount > 0 ? `<span class="gr-nav-badge">${pendingOrdersCount}</span>` : ''}
                            </button>
                            <button class="gr-dropdown-item ${isDishes ? 'active' : ''}" onclick="switchDashboardTab('dishes'); closeManagerDropdown();">
                                <i class='ri-restaurant-2-line'></i>
                                <span>Produits</span>
                            </button>
                            <button class="gr-dropdown-item ${isReports ? 'active' : ''}" onclick="switchDashboardTab('reports'); closeManagerDropdown();">
                                <i class='ri-file-chart-line'></i>
                                <span>Rapports</span>
                            </button>
                            <button class="gr-dropdown-item ${isAccount ? 'active' : ''}" onclick="switchDashboardTab('account'); closeManagerDropdown();">
                                <i class='ri-settings-3-line'></i>
                                <span>Paramètres &amp; QR</span>
                            </button>
                            <div style="height: 1px; background: var(--border); margin: 0.4rem 0;"></div>
                            <button class="gr-dropdown-item" onclick="switchDashboardTab('subscription', 'wow'); closeManagerDropdown();" style="color: #d97706;">
                                <i class='ri-sparkling-fill'></i>
                                <span>Formule Partenaire</span>
                            </button>
                            ${isSuperAdminSession ? `
                            <button class="gr-dropdown-item" onclick="exitImpersonation(); closeManagerDropdown();" style="color: #dc2626;">
                                <i class='ri-shield-user-fill'></i>
                                <span>Console Super-Admin</span>
                            </button>
                            ` : ''}
                            <button class="gr-dropdown-item" onclick="logoutRestaurant()" style="color: var(--danger);">
                                <i class='ri-logout-box-r-line'></i>
                                <span>Déconnexion</span>
                            </button>
                        </div>
                    </div>

                    <button class="btn btn-ghost btn-sm" onclick="logoutRestaurant()" title="Déconnexion" style="padding: 0.4rem 0.6rem; color: var(--danger); border-radius: 10px;">
                        <i class='ri-logout-box-r-line' style="font-size: 1.2rem;"></i>
                    </button>
                </div>
            </div>

            <div class="gr-dashboard-layout">
                <main class="gr-main" id="dashboard-tab-panel">
                    <!-- Sub tab contents injected here -->
                </main>
            </div>
        </div>
    `;

    renderDashboardTabContent(r);
    if (typeof renderMobileBottomNav === 'function') {
        renderMobileBottomNav();
    }
}

// ---------------------------------------------------------------------------
// 3-DOTS DROPDOWN CONTROLS
// ---------------------------------------------------------------------------
window.toggleManagerDropdown = function(event) {
    if (event) {
        event.stopPropagation();
        event.preventDefault();
    }
    const dd = document.getElementById('gr-manager-dropdown');
    if (!dd) return;
    const isVisible = dd.style.display === 'block';
    dd.style.display = isVisible ? 'none' : 'block';
};

window.closeManagerDropdown = function() {
    const dd = document.getElementById('gr-manager-dropdown');
    if (dd) dd.style.display = 'none';
};

if (typeof window !== 'undefined' && !window._grDropdownListenerAdded) {
    window._grDropdownListenerAdded = true;
    document.addEventListener('click', function(e) {
        const dd = document.getElementById('gr-manager-dropdown');
        const btn = document.getElementById('gr-three-dots-btn');
        if (dd && dd.style.display === 'block') {
            if (!dd.contains(e.target) && (!btn || !btn.contains(e.target))) {
                dd.style.display = 'none';
            }
        }
    });
}

function switchDashboardTab(tab, subTab) {
    if (tab === 'summary' || tab === 'accounting' || tab === 'dashboard') {
        dashboardActiveTab = 'accounting';
    } else if (tab === 'reservations') {
        dashboardActiveTab = 'orders';
        window.currentOrdersSubView = 'reservations';
    } else if (tab === 'orders' || tab === 'consumer') {
        dashboardActiveTab = 'orders';
        if (subTab) window.currentOrdersSubView = subTab;
    } else if (tab === 'menu' || tab === 'add-menu' || tab === 'daily-menu' || tab === 'dishes' || tab === 'products') {
        dashboardActiveTab = 'dishes';
        if (tab === 'daily-menu' || subTab === 'daily') window.currentDishesSubView = 'daily';
        else if (tab === 'add-menu' || subTab === 'add') window.currentDishesSubView = 'add';
        else if (subTab) window.currentDishesSubView = subTab;
    } else if (tab === 'reports' || tab === 'report' || tab === 'transactions' || tab === 'invoices') {
        dashboardActiveTab = 'reports';
    } else if (tab === 'subscription') {
        dashboardActiveTab = 'subscription';
        if (subTab === 'payment' || subTab === 'wow') {
            window.subscriptionFlowStep = subTab;
        } else if (!window.subscriptionFlowStep) {
            window.subscriptionFlowStep = 'wow';
        }
    } else if (tab === 'reviews' || tab === 'settings' || tab === 'account' || tab === 'profile') {
        dashboardActiveTab = 'account';
        if (subTab) window.currentAccountSubView = subTab;
    } else {
        dashboardActiveTab = tab;
    }

    if (typeof updateNavbar === 'function') updateNavbar();
    if (typeof renderMobileBottomNav === 'function') renderMobileBottomNav();
    renderDashboardShell();
}

/**
 * Global helper to navigate between subscription flow steps ('wow' -> 'payment')
 */
window.setSubscriptionStep = function(step) {
    window.subscriptionFlowStep = step;
    if (dashboardActiveTab !== 'subscription') {
        dashboardActiveTab = 'subscription';
    }
    renderDashboardShell();
    window.scrollTo({ top: 0, behavior: 'smooth' });
};

function getDashboardSubNavHtml(activeTab) {
    return '';
}

function renderDashboardTabContent(r) {
    const panel = document.getElementById('dashboard-tab-panel');
    const allRestoOrders = (typeof store !== 'undefined' && store.getOrdersByRestaurant) ? store.getOrdersByRestaurant(r.id) : [];
    const pendingOrdersCount = allRestoOrders.filter(o => o.status === 'En attente' || o.status === 'Reçue').length;
    
    // Check trial expiry for paywall (7-day trial policy) - NEVER block active restaurants or the orders tab
    const _cr = new Date(r.createdAt || new Date().toISOString());
    const _dt = Math.abs(new Date() - _cr);
    const _dd = Math.ceil(_dt / (1000 * 60 * 60 * 24));
    const _pk = r.subscriptionPack || 'Essai 7 Jours (Gratuit)';
    const isPaid = (_pk && !_pk.includes('Gratuit') && !_pk.includes('Essai') && !_pk.includes('Aucun')) || r.hasPaidSubscription || r.status === 'active';
    const trialExpired = _dd > 7 && !isPaid && !isSuperAdminSession;
    
    // Only lock management tabs if trial is explicitly expired and restaurant is not active
    const lockedTabs = ['menu', 'accounting'];
    if (trialExpired && lockedTabs.includes(dashboardActiveTab)) {
        const adminWhatsApp = '221776064596';
        const reactivateMsg = encodeURIComponent(`Bonjour Thiès Resto \n\nMa période d'essai gratuit de 7 jours est terminée et je souhaite réactiver mon restaurant.\n\n<i class="store-2-line"></i> Restaurant : ${r.name}\nIdentifiant : ${r.slug}\n\nMerci de m'indiquer la marche à suivre !`);
        panel.innerHTML = `
            <div style="text-align: center; padding: 3.5rem 2rem; background: var(--bg-card); border: 1px solid var(--border); border-radius: 20px; max-width: 680px; margin: 1.5rem auto;">
                <div style="font-size: 3.5rem; margin-bottom: 1.25rem;"><i class='ri-lock-line'></i></div>
                <h2 style="color: var(--text-primary); font-size: 1.7rem; margin-bottom: 0.75rem; font-weight: 800;">Période d'essai de 7 jours terminée</h2>
                <p style="color: var(--text-secondary); font-size: 0.95rem; max-width: 520px; margin: 0 auto 1.5rem auto; line-height: 1.6;">Votre période d'essai gratuit de 7 jours est écoulée. Votre compte a été temporairement désactivé pour les clients. Découvrez les avantages et choisissez une formule pour continuer à recevoir vos commandes sans interruption.</p>
                <div style="background: rgba(239, 68, 68, 0.08); border: 1px solid rgba(239, 68, 68, 0.25); padding: 1rem; border-radius: 12px; margin-bottom: 2rem;">
                    <p style="color: var(--danger); font-weight: 700; margin: 0; font-size: 0.88rem;"><i class='ri-alert-line'></i> Votre page restaurant est actuellement désactivée pour les clients du réseau.</p>
                </div>
                <div style="display: flex; flex-direction: column; gap: 0.75rem; max-width: 380px; margin: 0 auto;">
                    <button class="btn btn-primary" onclick="switchDashboardTab('subscription', 'wow')" style="font-weight: 700; padding: 0.75rem 1.5rem; font-size: 0.95rem; border-radius: 12px; background: linear-gradient(135deg, #f59e0b, #d97706); border: none; box-shadow: 0 4px 14px rgba(245, 158, 11, 0.3);">
                        <i class='ri-sparkling-fill'></i> Voir les Avantages & M'Abonner
                    </button>
                    <a href="https://wa.me/${adminWhatsApp}?text=${reactivateMsg}" target="_blank" class="btn btn-success" style="font-weight: 700; background: #25D366; border-color: #25D366; display: flex; align-items: center; justify-content: center; gap: 0.5rem; text-decoration: none; padding: 0.65rem; border-radius: 12px;">
                        <i class='ri-chat-1-line'></i> Contacter le support WhatsApp
                    </a>
                </div>
            </div>
        `;
        return;
    }
    
    if (dashboardActiveTab === 'accounting' || dashboardActiveTab === 'summary' || dashboardActiveTab === 'dashboard') {
        let allOrders = allRestoOrders;
        let orders = [...allOrders];
        const todayStr = new Date().toISOString().split('T')[0];
        
        if (currentAccountingFilter === 'today') {
            orders = orders.filter(o => o.date === todayStr);
        } else if (currentAccountingFilter === 'week') {
            const today = new Date();
            const weekAgo = new Date(today.getTime() - 7 * 24 * 60 * 60 * 1000).toISOString().split('T')[0];
            orders = orders.filter(o => o.date >= weekAgo && o.date <= todayStr);
        } else if (currentAccountingFilter === 'month') {
            const today = new Date();
            const monthAgo = new Date(today.getTime() - 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0];
            orders = orders.filter(o => o.date >= monthAgo && o.date <= todayStr);
        }

        const completedOrders = orders.filter(o => o.status === 'Livrée' || o.status === 'Livré');
        let totalRevenue = completedOrders.reduce((sum, o) => sum + (Number(o.total) || 0), 0);
        if (totalRevenue === 0 && orders.length > 0) {
            totalRevenue = orders.reduce((sum, o) => sum + (Number(o.total) || 0), 0);
        }
        const totalOrdersCount = orders.length;

        // Plats vendus réels
        let totalItemsSold = completedOrders.reduce((sum, o) => {
            const items = o.items || [];
            return sum + items.reduce((s, it) => s + (Number(it.qty || it.quantity) || 1), 0);
        }, 0);
        if (totalItemsSold === 0 && orders.length > 0) {
            totalItemsSold = orders.reduce((sum, o) => {
                const items = o.items || [];
                return sum + items.reduce((s, it) => s + (Number(it.qty || it.quantity) || 1), 0);
            }, 0);
        }

        // Visiteurs réels (vues réelles ou clients distincts)
        const uniqueCustomers = new Set(orders.map(o => o.customerPhone).filter(Boolean)).size;
        const totalVisitors = Number(r.viewsCount) || uniqueCustomers;

        // Date formatée en français
        const dateOpts = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
        const todayFormatted = new Date().toLocaleDateString('fr-FR', dateOpts);
        const capitalizedDate = todayFormatted.charAt(0).toUpperCase() + todayFormatted.slice(1);

        // Analyse des catégories et montants réels
        const categoryTotals = {};
        orders.forEach(o => {
            (o.items || []).forEach(it => {
                const cat = it.category || 'Plats';
                const itemPrice = Number(it.price) || 0;
                const qty = Number(it.qty || it.quantity) || 1;
                categoryTotals[cat] = (categoryTotals[cat] || 0) + (itemPrice * qty);
            });
        });

        const sortedCats = Object.entries(categoryTotals).sort((a, b) => b[1] - a[1]);
        const topCat1 = sortedCats[0] ? sortedCats[0][0] : (r.menu && r.menu[0] ? r.menu[0].category || 'Plats' : 'Plats');
        const topVal1 = sortedCats[0] ? sortedCats[0][1] : 0;
        const topCat2 = sortedCats[1] ? sortedCats[1][0] : (r.menu && r.menu[1] ? r.menu[1].category || 'Grillades' : 'Grillades');
        const topVal2 = sortedCats[1] ? sortedCats[1][1] : 0;
        const topCat3 = sortedCats[2] ? sortedCats[2][0] : (r.menu && r.menu[2] ? r.menu[2].category || 'Boissons' : 'Boissons');
        const topVal3 = sortedCats[2] ? sortedCats[2][1] : 0;

        // Répartition géographique réelle
        const locationCounts = {
            'Grand Thiès / Centre': 0,
            'Cité Lamy / Mbour 1': 0,
            'Nguinth / Randoulène': 0,
            'Médina Fall / Fahu': 0
        };
        let knownLocOrders = 0;
        orders.forEach(o => {
            const addr = ((o.address || '') + ' ' + (o.customerName || '')).toLowerCase();
            if (addr.includes('lamy') || addr.includes('mbour')) {
                locationCounts['Cité Lamy / Mbour 1']++;
                knownLocOrders++;
            } else if (addr.includes('nguinth') || addr.includes('randoulène') || addr.includes('randoulene')) {
                locationCounts['Nguinth / Randoulène']++;
                knownLocOrders++;
            } else if (addr.includes('médina') || addr.includes('medina') || addr.includes('fahu')) {
                locationCounts['Médina Fall / Fahu']++;
                knownLocOrders++;
            } else if (o.address) {
                locationCounts['Grand Thiès / Centre']++;
                knownLocOrders++;
            }
        });

        const totalForLoc = knownLocOrders > 0 ? knownLocOrders : (orders.length > 0 ? orders.length : 1);
        const locP1 = orders.length > 0 ? Math.round((locationCounts['Grand Thiès / Centre'] / totalForLoc) * 100) : 0;
        const locP2 = orders.length > 0 ? Math.round((locationCounts['Cité Lamy / Mbour 1'] / totalForLoc) * 100) : 0;
        const locP3 = orders.length > 0 ? Math.round((locationCounts['Nguinth / Randoulène'] / totalForLoc) * 100) : 0;
        const locP4 = orders.length > 0 ? Math.round((locationCounts['Médina Fall / Fahu'] / totalForLoc) * 100) : 0;

        // Rows pour la table
        let rowsHtml = '';
        if (orders.length === 0) {
            rowsHtml = `
                <tr>
                    <td colspan="6" style="text-align: center; color: var(--gr-text-muted); padding: 2.5rem 1rem;">
                        <i class='ri-inbox-line' style="font-size: 2rem; display: block; margin-bottom: 0.5rem; color: #94a3b8;"></i>
                        Aucune transaction enregistrée pour la période sélectionnée.
                    </td>
                </tr>
            `;
        } else {
            orders.slice(0, 15).forEach(o => {
                const isDelivered = o.status === 'Livrée' || o.status === 'Livré';
                const isPending = o.status === 'En attente' || o.status === 'Reçue';
                const statusBadge = isDelivered 
                    ? `<span class="gr-kpi-badge gr-badge-success"><i class='ri-checkbox-circle-fill'></i> Livrée</span>`
                    : isPending
                    ? `<span class="gr-kpi-badge" style="background: rgba(245, 158, 11, 0.15); color: #d97706;"><i class='ri-time-fill'></i> En attente</span>`
                    : `<span class="gr-kpi-badge" style="background: rgba(14, 165, 233, 0.15); color: #0284c7;"><i class='ri-loader-4-fill'></i> ${o.status}</span>`;

                rowsHtml += `
                    <tr class="accounting-row" data-client="${(o.customerName || '').toLowerCase()}" data-id="${String(o.id || '').toLowerCase()}">
                        <td><strong>${o.date} ${o.time || ''}</strong></td>
                        <td>${o.customerName || 'Client Thiès'}</td>
                        <td><a href="tel:${o.customerPhone}" style="color: var(--gr-dark-green); font-weight: 600; text-decoration: none;"><i class='ri-phone-line'></i> ${o.customerPhone || 'N/A'}</a></td>
                        <td><span style="background: #F0F4F2; padding: 2px 8px; border-radius: 6px; font-weight: 500; font-size: 0.78rem;">${o.mode || 'Livraison'}</span></td>
                        <td style="color: var(--gr-dark-green); font-weight: 700;">${(Number(o.total) || 0).toLocaleString()} FCFA</td>
                        <td>${statusBadge}</td>
                    </tr>
                `;
            });
        }

        panel.innerHTML = `
            <!-- Top Header -->
            <div class="gr-topbar">
                <div class="gr-header-titles">
                    <h1>Sales Report</h1>
                    <p>${capitalizedDate}</p>
                </div>
                <div class="gr-header-actions">
                    <button class="gr-circle-btn" onclick="const s = document.getElementById('gr-quick-search'); if (s) { s.scrollIntoView({behavior:'smooth'}); s.focus(); }" title="Rechercher">
                        <i class='ri-search-line'></i>
                    </button>
                    <button class="gr-circle-btn" onclick="switchDashboardTab('orders')" title="Commandes">
                        <i class='ri-mail-line'></i>
                        ${pendingOrdersCount > 0 ? '<span class="dot-badge"></span>' : ''}
                    </button>
                    <div class="gr-user-badge">
                        <div class="gr-user-avatar">
                            ${(r.name || 'G').charAt(0).toUpperCase()}
                        </div>
                        <div class="gr-user-info">
                            <div class="gr-user-name">${r.name || 'Gérant'}</div>
                            <div class="gr-user-role">Admin Officer</div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Bento Grid -->
            <div class="gr-bento-grid">
                <!-- Left Column (65%) -->
                <div class="gr-left-column">
                    <!-- 4 KPIs Grid (2x2) -->
                    <div class="gr-kpis-grid">
                        <!-- KPI 1: Total Sales (Forest Green Card) -->
                        <div class="gr-kpi-card gr-kpi-primary">
                            <div class="gr-kpi-top">
                                <div class="gr-kpi-icon">
                                    <i class='ri-file-text-line'></i>
                                </div>
                                <span class="gr-kpi-badge gr-badge-success">+20.9%</span>
                            </div>
                            <div class="gr-kpi-middle">
                                <div class="gr-kpi-label">Total Sales</div>
                                <div class="gr-kpi-bottom">
                                    <div class="gr-kpi-value">${totalRevenue.toLocaleString()} <span style="font-size: 1rem; font-weight: 600;">FCFA</span></div>
                                    <div class="gr-kpi-compare">Ventes vs mois dernier</div>
                                </div>
                            </div>
                        </div>

                        <!-- KPI 2: Total Orders -->
                        <div class="gr-kpi-card gr-kpi-light">
                            <div class="gr-kpi-top">
                                <div class="gr-kpi-icon">
                                    <i class='ri-shopping-bag-3-line'></i>
                                </div>
                                <span class="gr-kpi-badge gr-badge-success">+10.9%</span>
                            </div>
                            <div class="gr-kpi-middle">
                                <div class="gr-kpi-label">Total Orders</div>
                                <div class="gr-kpi-bottom">
                                    <div class="gr-kpi-value">${totalOrdersCount.toLocaleString()}</div>
                                    <div class="gr-kpi-compare">Commandes vs mois dernier</div>
                                </div>
                            </div>
                        </div>

                        <!-- KPI 3: Total Visitors -->
                        <div class="gr-kpi-card gr-kpi-light">
                            <div class="gr-kpi-top">
                                <div class="gr-kpi-icon">
                                    <i class='ri-user-add-line'></i>
                                </div>
                                <span class="gr-kpi-badge gr-badge-danger">-10.2%</span>
                            </div>
                            <div class="gr-kpi-middle">
                                <div class="gr-kpi-label">Total Visitors</div>
                                <div class="gr-kpi-bottom">
                                    <div class="gr-kpi-value">${totalVisitors.toLocaleString()}</div>
                                    <div class="gr-kpi-compare">Visiteurs vs mois dernier</div>
                                </div>
                            </div>
                        </div>

                        <!-- KPI 4: Total Products Sold -->
                        <div class="gr-kpi-card gr-kpi-light">
                            <div class="gr-kpi-top">
                                <div class="gr-kpi-icon">
                                    <i class='ri-price-tag-3-line'></i>
                                </div>
                                <span class="gr-kpi-badge gr-badge-success">+20.9%</span>
                            </div>
                            <div class="gr-kpi-middle">
                                <div class="gr-kpi-label">Total Products Sold</div>
                                <div class="gr-kpi-bottom">
                                    <div class="gr-kpi-value">${totalItemsSold.toLocaleString()}</div>
                                    <div class="gr-kpi-compare">Plats vs mois dernier</div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Customer Habits (Bar Chart Card) -->
                    <div class="gr-card">
                        <div class="gr-card-header">
                            <div>
                                <h3 class="gr-card-header-title">Customer Habits</h3>
                                <p class="gr-card-header-sub">Track your customers habit</p>
                            </div>
                            <select class="gr-select-pill" onchange="window.renderCustomerHabitsChart(this.value)">
                                <option value="year" selected>Cette année</option>
                                <option value="month">Ce mois</option>
                                <option value="week">7 derniers jours</option>
                            </select>
                        </div>
                        <div class="gr-chart-legend">
                            <div class="gr-legend-item">
                                <span class="gr-legend-dot" style="background: var(--gr-bright-green);"></span>
                                <span>Seen Products</span>
                            </div>
                            <div class="gr-legend-item">
                                <span class="gr-legend-dot" style="background: var(--gr-dark-green);"></span>
                                <span>Sales</span>
                            </div>
                        </div>
                        <div id="gr-habits-chart-container" class="gr-habits-chart-wrapper">
                            <!-- SVG chart dynamically rendered -->
                        </div>
                    </div>
                </div>

                <!-- Right Column (35%) -->
                <div class="gr-right-column">
                    <!-- Product Statistic Card -->
                    <div class="gr-product-stat-card">
                        <div class="gr-card-header" style="margin-bottom: 0.5rem;">
                            <div>
                                <h3 class="gr-card-header-title">Product Statistic</h3>
                                <p class="gr-card-header-sub">Track your product sales</p>
                            </div>
                            <select class="gr-select-pill" style="background: rgba(255,255,255,0.7);">
                                <option value="today">Today</option>
                                <option value="month">Month</option>
                            </select>
                        </div>

                        <!-- Pie / Donut SVG -->
                        <div class="gr-pie-container">
                            <svg class="gr-pie-svg" viewBox="0 0 160 160">
                                <!-- Donut Slices -->
                                <circle cx="80" cy="80" r="54" fill="none" stroke="#0B3B24" stroke-width="26" stroke-dasharray="210 340" stroke-dashoffset="0" />
                                <circle cx="80" cy="80" r="54" fill="none" stroke="#10B981" stroke-width="26" stroke-dasharray="90 340" stroke-dashoffset="-215" />
                                <circle cx="80" cy="80" r="54" fill="none" stroke="#34D399" stroke-width="26" stroke-dasharray="40 340" stroke-dashoffset="-308" />
                                <!-- Center cutout for pure donut look -->
                                <circle cx="80" cy="80" r="40" fill="#DFECE5" />
                            </svg>
                        </div>

                        <!-- Category rows -->
                        <div class="gr-stat-list">
                            <div class="gr-stat-row">
                                <div class="gr-stat-category">${topCat1}</div>
                                <div class="gr-stat-numbers">
                                    <span class="gr-stat-count">${topVal1.toLocaleString()} F</span>
                                    <span class="gr-kpi-badge gr-badge-success">+1.9%</span>
                                </div>
                            </div>
                            <div class="gr-stat-row">
                                <div class="gr-stat-category">${topCat2}</div>
                                <div class="gr-stat-numbers">
                                    <span class="gr-stat-count">${topVal2.toLocaleString()} F</span>
                                    <span class="gr-kpi-badge gr-badge-success">+2.9%</span>
                                </div>
                            </div>
                            <div class="gr-stat-row">
                                <div class="gr-stat-category">${topCat3}</div>
                                <div class="gr-stat-numbers">
                                    <span class="gr-stat-count">${topVal3.toLocaleString()} F</span>
                                    <span class="gr-kpi-badge gr-badge-danger">-2.09%</span>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Customer Growth Card -->
                    <div class="gr-growth-card">
                        <div class="gr-card-header" style="margin-bottom: 0.25rem;">
                            <div>
                                <h3 class="gr-card-header-title">Customer Growth</h3>
                                <p class="gr-card-header-sub">Track your customers by location</p>
                            </div>
                            <select class="gr-select-pill">
                                <option value="today">Today</option>
                                <option value="global">Global</option>
                            </select>
                        </div>

                        <!-- Bubbles graphic -->
                        <div class="gr-bubbles-stage">
                            <div class="gr-bubble gr-bubble-1" title="Grand Thiès / Centre">${locP1}%</div>
                            <div class="gr-bubble gr-bubble-2" title="Cité Lamy / Mbour 1">${locP2}%</div>
                            <div class="gr-bubble gr-bubble-3" title="Nguinth / Randoulène">${locP3}%</div>
                            <div class="gr-bubble gr-bubble-4" title="Médina Fall / Fahu">${locP4}%</div>
                        </div>

                        <!-- Locations list -->
                        <div class="gr-location-list">
                            <div class="gr-location-item">
                                <span class="gr-location-flag"><i class='ri-map-pin-2-fill' style="color: var(--gr-dark-green);"></i></span>
                                <span class="gr-location-name">Grand Thiès / Centre</span>
                                <div class="gr-progress-bar-wrap">
                                    <div class="gr-progress-bar-fill" style="width: ${locP1}%;"></div>
                                </div>
                            </div>
                            <div class="gr-location-item">
                                <span class="gr-location-flag"><i class='ri-map-pin-2-fill' style="color: #0D4E30;"></i></span>
                                <span class="gr-location-name">Cité Lamy / Mbour 1</span>
                                <div class="gr-progress-bar-wrap">
                                    <div class="gr-progress-bar-fill" style="width: ${locP2}%; background: #0D4E30;"></div>
                                </div>
                            </div>
                            <div class="gr-location-item">
                                <span class="gr-location-flag"><i class='ri-map-pin-2-fill' style="color: var(--gr-bright-green);"></i></span>
                                <span class="gr-location-name">Nguinth / Randoulène</span>
                                <div class="gr-progress-bar-wrap">
                                    <div class="gr-progress-bar-fill" style="width: ${locP3}%; background: var(--gr-bright-green);"></div>
                                </div>
                            </div>
                            <div class="gr-location-item">
                                <span class="gr-location-flag"><i class='ri-map-pin-2-fill' style="color: #34D399;"></i></span>
                                <span class="gr-location-name">Médina Fall / Fahu</span>
                                <div class="gr-progress-bar-wrap">
                                    <div class="gr-progress-bar-fill" style="width: ${locP4}%; background: #34D399;"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Bottom Full-Width Section: Orders & Transactions Table -->
                <div class="gr-orders-section" id="gr-orders-table-card">
                    <div class="gr-table-header">
                        <div>
                            <h3 class="gr-card-header-title">Transactions & Commandes Récentes</h3>
                            <p class="gr-card-header-sub">Historique réel des commandes enregistrées sur Thiès Resto</p>
                        </div>
                        <div style="display: flex; gap: 0.65rem; align-items: center; flex-wrap: wrap;">
                            <div style="position: relative;">
                                <i class='ri-search-line' style="position: absolute; left: 10px; top: 50%; transform: translateY(-50%); color: var(--gr-text-muted);"></i>
                                <input type="text" id="gr-quick-search" placeholder="Rechercher un client, commande..." class="gr-search-input" oninput="filterAccountingTable(this.value)">
                            </div>
                            <select class="gr-select-pill" onchange="currentAccountingFilter = this.value; renderDashboardTabContent(store.getRestaurantById('${r.id}'))">
                                <option value="all" ${currentAccountingFilter === 'all' ? 'selected' : ''}>Toutes les dates</option>
                                <option value="today" ${currentAccountingFilter === 'today' ? 'selected' : ''}>Aujourd'hui</option>
                                <option value="week" ${currentAccountingFilter === 'week' ? 'selected' : ''}>7 derniers jours</option>
                                <option value="month" ${currentAccountingFilter === 'month' ? 'selected' : ''}>30 derniers jours</option>
                            </select>
                            <button class="gr-select-pill" onclick="window.exportOrdersCSV('${r.id}')" style="background: var(--gr-dark-green); color: #fff; border-color: var(--gr-dark-green); display: inline-flex; align-items: center; gap: 0.35rem;">
                                <i class='ri-download-2-line'></i> Exporter CSV
                            </button>
                            <button class="gr-select-pill" onclick="window.printRestaurantOrdersPDF('${r.id}')" style="display: inline-flex; align-items: center; gap: 0.35rem;">
                                <i class='ri-printer-line'></i> Imprimer
                            </button>
                        </div>
                    </div>

                    <div class="gr-table-wrap">
                        <table class="gr-table">
                            <thead>
                                <tr>
                                    <th>Date & Heure</th>
                                    <th>Client</th>
                                    <th>Téléphone</th>
                                    <th>Mode</th>
                                    <th>Total</th>
                                    <th>Statut</th>
                                </tr>
                            </thead>
                            <tbody>
                                ${rowsHtml}
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        `;

        setTimeout(() => {
            if (typeof window.renderCustomerHabitsChart === 'function') {
                window.renderCustomerHabitsChart('year');
            }
        }, 50);
    }
    else if (dashboardActiveTab === 'orders') {
        if (store && typeof store.checkAndAutoCancelStaleOrders === 'function') {
            store.checkAndAutoCancelStaleOrders();
        }
        const orders = store.getOrdersByRestaurant(r.id);
        const todayStr = new Date().toISOString().split('T')[0];
        
        const todayOrders = orders.filter(o => o.date === todayStr);
        const todayRevenue = todayOrders.filter(o => o.status === 'Livrée' || o.status === 'Livré').reduce((sum, o) => sum + (Number(o.total) || 0), 0);
        const pendingOrders = orders.filter(o => typeof window.isOrderUntreated === 'function' ? window.isOrderUntreated(o) : (o.status === 'En attente' || o.status === 'Reçue'));
        const kitchenOrders = orders.filter(o => o.status === 'En cuisine' || o.status === 'En préparation' || o.status === 'Confirmée');
        const readyOrders = orders.filter(o => o.status === 'Prêt pour livraison' || o.status === 'Prête');
        const deliveryOrders = orders.filter(o => o.status === 'En cours de livraison' || o.status === 'En livraison' || o.status === 'Partie en livraison');
        const deliveredOrders = orders.filter(o => o.status === 'Livrée' || o.status === 'Livré');
        const delayed10mOrders = pendingOrders.filter(o => (typeof window.getUntreatedElapsedMinutes === 'function' ? window.getUntreatedElapsedMinutes(o) : 0) >= 10);

        // Apply filters
        let filteredOrders = [...orders];
        if (currentOrderStatusFilter === 'Retard (>10 min)') {
            filteredOrders = orders.filter(o => (typeof window.isOrderUntreated === 'function' ? window.isOrderUntreated(o) : false) && (typeof window.getUntreatedElapsedMinutes === 'function' ? window.getUntreatedElapsedMinutes(o) : 0) >= 10);
        } else if (currentOrderStatusFilter === 'En attente') {
            filteredOrders = orders.filter(o => o.status === 'En attente' || o.status === 'Reçue');
        } else if (currentOrderStatusFilter === 'En cuisine') {
            filteredOrders = kitchenOrders;
        } else if (currentOrderStatusFilter === 'Prêt pour livraison') {
            filteredOrders = readyOrders;
        } else if (currentOrderStatusFilter === 'En livraison') {
            filteredOrders = deliveryOrders;
        } else if (currentOrderStatusFilter === 'Livrées') {
            filteredOrders = deliveredOrders;
        }

        // Apply search query if present
        if (window.dashboardOrdersSearchQuery && window.dashboardOrdersSearchQuery.trim()) {
            const q = window.dashboardOrdersSearchQuery.toLowerCase().trim();
            filteredOrders = filteredOrders.filter(o => {
                const name = (o.customerName || '').toLowerCase();
                const phone = (o.customerPhone || '').toLowerCase();
                const addr = (o.address || '').toLowerCase();
                const idStr = String(o.id || '').toLowerCase();
                const itemsStr = (o.items || []).map(i => i.name || '').join(' ').toLowerCase();
                return name.includes(q) || phone.includes(q) || addr.includes(q) || idStr.includes(q) || itemsStr.includes(q);
            });
        }

        let listHtml = '';
        if (filteredOrders.length === 0) {
            listHtml = `
                <div style="text-align: center; color: var(--text-secondary); padding: 3.5rem 1.5rem; background: var(--bg-card); border: 1px solid var(--border); border-radius: 16px;">
                    <span style="font-size: 3rem; display: block; margin-bottom: 0.75rem;"><i class='ri-inbox-archive-line'></i></span>
                    <p style="font-weight: 700; font-size: 1rem; color: var(--text-primary); margin: 0 0 0.5rem 0;">Aucune commande trouvée</p>
                    <p style="font-size: 0.85rem; margin: 0;">Aucune commande ne correspond au filtre <strong>"${currentOrderStatusFilter}"</strong>${window.dashboardOrdersSearchQuery ? ` ou à la recherche "${window.dashboardOrdersSearchQuery}"` : ''}.</p>
                </div>
            `;
        } else {
            filteredOrders.forEach(o => {
                const itemsStr = (o.items || []).map(i => `<span style="background: var(--bg-secondary); padding: 0.25rem 0.55rem; border-radius: 6px; font-size: 0.8rem; font-weight: 600; border: 1px solid var(--border); display: inline-block; margin: 0.15rem 0.15rem 0.15rem 0;">${i.name} <strong>x${i.qty || i.quantity || 1}</strong></span>`).join(' ');
                
                const isUntreated = typeof window.isOrderUntreated === 'function' ? window.isOrderUntreated(o) : (o.status === 'En attente' || o.status === 'Reçue');
                const elapsedMinutes = typeof window.getUntreatedElapsedMinutes === 'function' ? window.getUntreatedElapsedMinutes(o) : 0;
                const isOverdue = isUntreated && elapsedMinutes >= 10;

                // Status styles & controls
                let statusBadge = '';
                let actionBtns = '';
                const clientLat = o.deliveryLat || o.delivery_lat || o.client_lat;
                const clientLng = o.deliveryLng || o.delivery_lng || o.client_lng;
                
                const quickStatusSelect = `
                    <div style="margin-top: 0.75rem; display: flex; align-items: center; justify-content: space-between; gap: 0.5rem; flex-wrap: wrap; background: var(--bg-secondary); padding: 0.45rem 0.75rem; border-radius: 10px; border: 1px solid var(--border);">
                        <label for="status-sel-${o.id}" style="font-size: 0.78rem; font-weight: 700; color: var(--text-secondary); margin: 0;"><i class='ri-flashlight-line'></i> Changement d'état :</label>
                        <select id="status-sel-${o.id}" class="form-control" onchange="changeOrderStatus('${o.id}', this.value)" style="width: auto; padding: 0.3rem 0.65rem; font-size: 0.82rem; font-weight: 700; border-radius: 8px; margin: 0; background: var(--bg-card); color: var(--text-primary); cursor: pointer;">
                            <option value="En attente" ${o.status === 'En attente' ? 'selected' : ''}>En attente</option>
                            <option value="Reçue" ${o.status === 'Reçue' ? 'selected' : ''}>Reçue / Acceptée</option>
                            <option value="En cuisine" ${(o.status === 'En cuisine' || o.status === 'Confirmée' || o.status === 'En préparation') ? 'selected' : ''}>‍ En cuisine</option>
                            <option value="Prêt pour livraison" ${(o.status === 'Prêt pour livraison' || o.status === 'Prête') ? 'selected' : ''}>Prêt pour livraison</option>
                            <option value="En cours de livraison" ${(o.status === 'En cours de livraison' || o.status === 'En livraison' || o.status === 'Partie en livraison') ? 'selected' : ''}>En livraison</option>
                            <option value="Livrée" ${(o.status === 'Livrée' || o.status === 'Livré') ? 'selected' : ''}>Livrée</option>
                            <option value="Annulée" ${o.status === 'Annulée' ? 'selected' : ''}>Annulée</option>
                        </select>
                    </div>
                `;

                if (isOverdue) {
                    statusBadge = `<span class="badge badge-danger pulse-red-alert" style="background: #dc2626; color: white; border: 1px solid #991b1b; font-weight: 800;"><i class='ri-alarm-warning-line'></i> NON TRAITÉE (${elapsedMinutes} MIN)</span>`;
                    actionBtns = `
                        <div class="quick-actions-container">
                            <button class="btn btn-danger pulse-red-alert quick-action-primary-btn" onclick="changeOrderStatus('${o.id}', 'En cuisine')">
                                <i class='ri-flashlight-line'></i> 1-CLIC : Accepter & Mettre en Cuisine
                            </button>
                            <div class="quick-action-grid-btns">
                                <button class="btn btn-primary" onclick="changeOrderStatus('${o.id}', 'Reçue')" style="background: #d97706; border-color: #d97706; color: white;">
                                    <i class='ri-inbox-archive-line'></i> Confirmer Réception
                                </button>
                                <button class="btn btn-danger" onclick="changeOrderStatus('${o.id}', 'Annulée')">
                                    <i class='ri-close-circle-line'></i> Refuser
                                </button>
                            </div>
                            ${quickStatusSelect}
                        </div>
                    `;
                } else if (o.status === 'En attente') {
                    statusBadge = `<span class="badge" style="background: rgba(245, 158, 11, 0.15); color: #d97706; border: 1px solid #f59e0b; font-weight: 800;">En attente (${elapsedMinutes} min)</span>`;
                    actionBtns = `
                        <div class="quick-actions-container">
                            <button class="btn btn-primary quick-action-primary-btn" onclick="changeOrderStatus('${o.id}', 'Reçue')" style="background: #d97706; border-color: #d97706; color: white;">
                                <i class='ri-inbox-archive-line'></i> 1. Confirmer Réception
                            </button>
                            <div class="quick-action-grid-btns">
                                <button class="btn btn-secondary" onclick="changeOrderStatus('${o.id}', 'En cuisine')">
                                    <i class='ri-restaurant-line'></i> Direct En Cuisine
                                </button>
                                <button class="btn btn-danger" onclick="changeOrderStatus('${o.id}', 'Annulée')">
                                    <i class='ri-close-circle-line'></i> Refuser
                                </button>
                            </div>
                            ${quickStatusSelect}
                        </div>
                    `;
                } else if (o.status === 'Reçue') {
                    statusBadge = `<span class="badge" style="background: rgba(2, 132, 199, 0.15); color: #0284c7; border: 1px solid #0284c7; font-weight: 800;"><i class='ri-inbox-archive-line'></i> Reçue (${elapsedMinutes} min)</span>`;
                    actionBtns = `
                        <div class="quick-actions-container">
                            <button class="btn btn-primary quick-action-primary-btn" onclick="changeOrderStatus('${o.id}', 'En cuisine')" style="background: var(--primary); border-color: var(--primary); color: white;">
                                <i class='ri-restaurant-line'></i> 2. Mettre en Cuisine
                            </button>
                            <div class="quick-action-grid-btns">
                                <button class="btn btn-secondary" onclick="changeOrderStatus('${o.id}', 'Prêt pour livraison')">
                                    <i class='ri-inbox-archive-line'></i> Prêt livraison
                                </button>
                                <button class="btn btn-danger" onclick="changeOrderStatus('${o.id}', 'Annulée')">
                                    <i class='ri-close-circle-line'></i> Annuler
                                </button>
                            </div>
                            ${quickStatusSelect}
                        </div>
                    `;
                } else if (o.status === 'Confirmée' || o.status === 'En préparation' || o.status === 'En cuisine') {
                    statusBadge = `<span class="badge" style="background: rgba(255, 107, 0, 0.15); color: var(--primary); border: 1px solid var(--primary); font-weight: 800;"><i class='ri-restaurant-line'></i> En Cuisine</span>`;
                    actionBtns = `
                        <div class="quick-actions-container">
                            <button class="btn btn-success quick-action-primary-btn" onclick="changeOrderStatus('${o.id}', 'Prêt pour livraison')" style="background: #0d9488; border-color: #0d9488; color: white;">
                                <i class='ri-inbox-archive-line'></i> 3. Marquer Prêt pour Livraison
                            </button>
                            <div class="quick-action-grid-btns">
                                <button class="btn btn-info" onclick="changeOrderStatus('${o.id}', 'En cours de livraison')" style="background: #0284c7; border-color: #0284c7; color: white;">
                                    <i class='ri-e-bike-2-line'></i> En Livraison
                                </button>
                                <button class="btn btn-danger" onclick="changeOrderStatus('${o.id}', 'Annulée')">
                                    <i class='ri-close-circle-line'></i> Annuler
                                </button>
                            </div>
                            ${quickStatusSelect}
                        </div>
                    `;
                } else if (o.status === 'Prêt pour livraison' || o.status === 'Prête') {
                    statusBadge = `<span class="badge" style="background: rgba(13, 148, 136, 0.15); color: #0d9488; border: 1px solid #0d9488; font-weight: 800;"><i class='ri-inbox-archive-line'></i> Prêt pour Livraison</span>`;
                    actionBtns = `
                        <div class="quick-actions-container">
                            <button class="btn btn-info quick-action-primary-btn" onclick="changeOrderStatus('${o.id}', 'En cours de livraison')" style="background: #0284c7; border-color: #0284c7; color: white;">
                                <i class='ri-e-bike-2-line'></i> 4. Partir en Livraison (Livreur)
                            </button>
                            <div class="quick-action-grid-btns">
                                <button class="btn btn-secondary" onclick="changeOrderStatus('${o.id}', 'Livrée')" title="Retrait en magasin ou remis directement au client">
                                    <i class='ri-checkbox-circle-line'></i> Remis client (Retrait)
                                </button>
                                <button class="btn btn-danger" onclick="changeOrderStatus('${o.id}', 'Annulée')">
                                    <i class='ri-close-circle-line'></i> Annuler
                                </button>
                            </div>
                            ${quickStatusSelect}
                        </div>
                    `;
                } else if (o.status === 'En cours de livraison' || o.status === 'En livraison' || o.status === 'Partie en livraison') {
                    statusBadge = `<span class="badge" style="background: rgba(2, 132, 199, 0.15); color: #0284c7; border: 1px solid #0284c7; font-weight: 800;"><i class='ri-e-bike-2-line'></i> En Cours de Livraison</span>`;
                    actionBtns = `
                        <div class="quick-actions-container">
                            <div style="background: rgba(2, 132, 199, 0.08); border: 1px solid rgba(2, 132, 199, 0.25); border-radius: 8px; padding: 0.6rem 0.8rem; font-size: 0.82rem; color: #0284c7; font-weight: 600; display: flex; align-items: center; gap: 0.4rem;">
                                <span><i class='ri-e-bike-2-line'></i></span>
                                <span>Commande en route. Le client confirmera la réception.</span>
                            </div>
                            <div class="quick-action-grid-btns">
                                <button class="btn btn-secondary" onclick="changeOrderStatus('${o.id}', 'Livrée')" title="À utiliser uniquement si le client ne dispose pas d'internet">
                                    <i class='ri-checkbox-circle-line'></i> Valider livraison (Secours)
                                </button>
                                <button class="btn btn-danger" onclick="changeOrderStatus('${o.id}', 'Annulée')">
                                    <i class='ri-close-circle-line'></i> Annuler
                                </button>
                            </div>
                            ${quickStatusSelect}
                        </div>
                    `;
                } else if (o.status === 'Annulée') {
                    statusBadge = `<span class="badge badge-danger">Annulée</span>`;
                    actionBtns = `
                        <div class="quick-actions-container">
                            <div style="font-size: 0.85rem; color: var(--danger); font-weight: 600; text-align: center; padding: 0.6rem; background: rgba(220, 38, 38, 0.08); border-radius: 8px; border: 1px solid rgba(220, 38, 38, 0.2);">
                                <div><i class='ri-close-circle-line'></i> Commande annulée</div>
                                ${o.cancelReason ? `<div style="font-size: 0.76rem; font-weight: 500; margin-top: 3px; opacity: 0.9;">${o.cancelReason}</div>` : ''}
                            </div>
                            ${quickStatusSelect}
                        </div>
                    `;
                } else {
                    statusBadge = `<span class="badge badge-success" style="background: rgba(16, 185, 129, 0.15); color: #059669; border: 1px solid #10b981; font-weight: 800;"><i class='ri-checkbox-circle-line'></i> Livrée</span>`;
                    const reviewText = `Bonjour ${o.customerName}, avez-vous aimé votre commande chez ${r.name} ? Laissez-nous un avis sur Thiès Resto ! https://thies-resto.com/#/r/${r.slug}`;
                    const waLink = `https://wa.me/${(o.customerPhone || '').replace(/\+/g, '')}?text=${encodeURIComponent(reviewText)}`;
                    actionBtns = `
                        <div class="quick-actions-container">
                            <span style="font-size: 0.82rem; color: #059669; font-weight: 700; display: block; text-align: center; padding: 0.45rem; background: rgba(16, 185, 129, 0.1); border-radius: 8px; border: 1px solid rgba(16, 185, 129, 0.25);"><i class='ri-checkbox-circle-line'></i> Réception confirmée & comptabilisée</span>
                            <a href="${waLink}" target="_blank" class="btn btn-primary" style="font-weight: 700; background: #25D366; border-color: #25D366; min-height: 44px; display: flex; justify-content: center; align-items: center; gap: 0.5rem;"><i class='ri-star-fill'></i> Demander un Avis (WhatsApp)</a>
                            ${quickStatusSelect}
                        </div>
                    `;
                }

                listHtml += `
                    <div class="dashboard-list-item ${isOverdue ? 'is-urgent' : ''}" style="background: var(--bg-card); border: 1px solid var(--border); border-radius: 16px; padding: 1.25rem; margin-bottom: 1rem; box-shadow: 0 4px 12px rgba(0,0,0,0.03);">
                        <div class="list-item-header" style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1rem; flex-wrap: wrap; gap: 0.5rem;">
                            <div style="display: flex; align-items: center; gap: 0.5rem; flex-wrap: wrap;">
                                <span class="list-item-title" style="font-family: monospace; font-size: 1.1rem; font-weight: 900; color: var(--primary);">N° ${o.id}</span>
                                <span>${statusBadge}</span>
                            </div>
                            <div style="display: flex; align-items: center; gap: 0.5rem;">
                                <span class="list-item-time" style="font-size: 0.82rem; color: var(--text-secondary);"><i class='ri-time-line'></i> ${o.date} à ${o.time}</span>
                                <button type="button" class="btn btn-sm" onclick="openCustomerDetailsModal('${o.id}')" title="Voir la fiche client détaillée" style="background: rgba(var(--primary-rgb), 0.12); color: var(--primary); font-weight: 700; border: 1px solid rgba(var(--primary-rgb), 0.25); border-radius: 8px; padding: 0.35rem 0.65rem; font-size: 0.78rem; display: inline-flex; align-items: center; gap: 0.35rem; cursor: pointer;">
                                    <span><i class='ri-user-3-line'></i> Fiche Client</span>
                                </button>
                            </div>
                        </div>
                        <div class="list-item-details" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 1rem; margin-bottom: 1rem; background: var(--bg-secondary); padding: 0.85rem; border-radius: 12px;">
                            <div>
                                <p style="margin: 0.2rem 0; font-size: 0.88rem; display: flex; align-items: center; gap: 0.35rem; flex-wrap: wrap;">
                                    <strong style="color:var(--text-secondary)"><i class='ri-user-3-line'></i> Client :</strong> 
                                    <button type="button" onclick="openCustomerDetailsModal('${o.id}')" style="background: none; border: none; padding: 0; font-weight: 800; color: var(--primary); text-decoration: underline; cursor: pointer; font-size: 0.9rem;" title="Cliquer pour afficher les détails du client">
                                        ${o.customerName || 'Client'}
                                    </button>
                                </p>
                                <p style="margin: 0.2rem 0; font-size: 0.88rem;">
                                    <strong style="color:var(--text-secondary)"><i class='ri-phone-line'></i> Contact :</strong> 
                                    <a href="tel:${o.customerPhone}" style="color: var(--text-primary); font-weight: 600; text-decoration: none; margin-right: 0.4rem;">${o.customerPhone}</a>
                                    <a href="https://wa.me/${(o.customerPhone || '').replace(/\D/g, '')}" target="_blank" class="call-btn" style="display: inline-flex; align-items: center; gap: 0.25rem; font-size: 0.76rem; color: #25D366; font-weight: 700; text-decoration: none;"><i class='ri-chat-1-line'></i> WhatsApp</a>
                                </p>
                                ${o.address ? `<p style="margin: 0.2rem 0; font-size: 0.88rem;"><strong style="color:var(--text-secondary)"><i class='ri-map-pin-line'></i> Adresse :</strong> ${o.address}</p>` : ''}
                                ${(clientLat && clientLng) ? `
                                    <p style="margin: 0.3rem 0; font-size: 0.88rem;">
                                        <strong style="color:var(--text-secondary)"><i class='ri-map-pin-line'></i> GPS Client :</strong> 
                                        <a href="https://www.google.com/maps?q=${clientLat},${clientLng}" target="_blank" class="call-btn" style="background: rgba(2, 132, 199, 0.12); color: #0284c7; border: 1px solid rgba(2, 132, 199, 0.3); font-weight: 700; display: inline-flex; align-items: center; gap: 0.35rem; padding: 3px 7px; border-radius: 6px; margin-top: 0.2rem; text-decoration: none;">
                                            <i class='ri-map-2-line'></i>️ Voir GPS Client
                                        </a>
                                    </p>
                                ` : ''}
                            </div>
                            <div>
                                <p style="margin: 0.2rem 0; font-size: 0.88rem;"><strong style="color:var(--text-secondary)"><i class='ri-e-bike-2-line'></i> Mode :</strong> <span class="badge ${o.mode === 'Livraison' ? 'badge-primary' : 'badge-info'}" style="font-weight:700;">${o.mode}</span></p>
                                <p style="margin: 0.2rem 0; font-size: 0.88rem;"><strong style="color:var(--text-secondary)"><i class='ri-money-dollar-circle-line'></i> Total :</strong> <span style="font-size: 1.05rem; color: var(--primary); font-weight: 800;">${Number(o.total || 0).toLocaleString()} FCFA</span></p>
                                ${(o.paymentMethod || o.payment_method) ? `<p style="margin: 0.2rem 0; font-size: 0.88rem;"><strong style="color:var(--text-secondary)"><i class='ri-bank-card-line'></i> Paiement :</strong> <span style="font-weight: 600;">${o.paymentMethod || o.payment_method}</span></p>` : ''}
                                ${o.note ? `<p style="margin: 0.2rem 0; font-size: 0.88rem;"><strong style="color:var(--text-secondary)"><i class='ri-edit-line'></i> Note :</strong> <span style="font-style: italic; color:var(--text-secondary);">"${o.note}"</span></p>` : ''}
                                ${o.mode === 'Livraison' ? `
                                    <div style="margin-top: 0.4rem;">
                                        <a href="https://wa.me/221776064596?text=${encodeURIComponent(`Bonjour Assistance THIES Resto,\nJe suis le restaurant *${r.name}*.\nJ'ai besoin d'un livreur pour la commande N°${o.id} :\n- Client : ${o.customerName || 'Client'}\n- Téléphone : ${o.customerPhone || 'N/A'}\n- Adresse : ${o.address || 'Thiès'}\n- Total à encaisser : ${Number(o.total || 0).toLocaleString()} FCFA`)}" target="_blank" class="btn btn-sm" style="background: rgba(37, 211, 102, 0.12); color: #15803d; border: 1px solid #22c55e; font-weight: 700; font-size: 0.76rem; border-radius: 8px; padding: 0.25rem 0.55rem; display: inline-flex; align-items: center; gap: 0.3rem; text-decoration: none;">
                                            <i class='ri-e-bike-2-line'></i> Demander un livreur (Assistance)
                                        </a>
                                    </div>
                                ` : ''}
                            </div>
                        </div>
                        <div style="background: var(--bg-secondary); padding: 0.65rem 0.85rem; border-radius: 8px; border: 1px solid var(--border); margin-bottom: 0.75rem;">
                            <strong style="display: block; font-size: 0.72rem; text-transform: uppercase; color: var(--text-secondary); margin-bottom: 0.3rem;"><i class='ri-restaurant-line'></i> Plats commandés :</strong>
                            <div style="display: flex; flex-wrap: wrap; gap: 0.35rem;">
                                ${itemsStr}
                            </div>
                        </div>
                        <div class="list-item-actions">
                            ${actionBtns}
                        </div>
                    </div>
                `;
            });
        }

        const filterTypes = [
            { id: 'Tous', label: '<i class="file-list-line"></i> Tous', count: orders.length },
            { id: 'En attente', label: 'En attente', count: pendingOrders.length },
            { id: 'En cuisine', label: '<i class="restaurant-line"></i> En cuisine', count: kitchenOrders.length },
            { id: 'Prêt pour livraison', label: '<i class="inbox-archive-line"></i> Prêt', count: readyOrders.length },
            { id: 'En livraison', label: '<i class="e-bike-2-line"></i> En livraison', count: deliveryOrders.length },
            { id: 'Livrées', label: '<i class="checkbox-circle-line"></i> Livrées', count: deliveredOrders.length }
        ];

        if (delayed10mOrders.length > 0) {
            filterTypes.splice(1, 0, { id: 'Retard (>10 min)', label: `<i class='ri-alarm-warning-line'></i> Retard >10min`, count: delayed10mOrders.length, isUrgent: true });
        }

        const filterBtnsHtml = filterTypes.map(f => {
            const isActive = currentOrderStatusFilter === f.id;
            const isDelayedBtn = f.isUrgent;
            const btnClass = isActive ? (isDelayedBtn ? 'btn-danger pulse-red-alert' : 'btn-primary') : (isDelayedBtn ? 'btn-danger' : 'btn-secondary');
            const style = isDelayedBtn && !isActive ? 'background: rgba(220, 38, 38, 0.15); color: #dc2626; border: 1px solid #dc2626; font-weight: 800;' : '';
            return `
                <button class="btn ${btnClass}" style="padding: 0.4rem 0.85rem; font-size: 0.82rem; font-weight: 700; border-radius: 20px; min-height: 36px; ${style}" onclick="filterOrdersDashboard('${f.id}')">
                    ${f.label} (${f.count})
                </button>
            `;
        }).join(' ');

        let ordersPageBanner = '';
        if (delayed10mOrders.length > 0 && currentOrderStatusFilter !== 'Retard (>10 min)') {
            ordersPageBanner = `
                <div class="delayed-order-banner" style="background: rgba(220, 38, 38, 0.08); border: 1px solid #dc2626; border-radius: 12px; padding: 0.85rem 1rem; margin-bottom: 1.25rem; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 0.75rem;">
                    <div style="display: flex; align-items: center; gap: 0.75rem;">
                        <span style="font-size: 1.5rem;"><i class='ri-alarm-warning-line'></i></span>
                        <div>
                            <strong style="color: #dc2626; font-size: 0.95rem; display: block;">${delayed10mOrders.length} commande(s) non traitée(s) depuis plus de 10 minutes !</strong>
                            <span style="color: var(--text-secondary); font-size: 0.82rem;">Traitez-les d'urgence pour satisfaire vos clients.</span>
                        </div>
                    </div>
                    <button class="btn btn-danger" onclick="filterOrdersDashboard('Retard (>10 min)')" style="font-weight: 800; font-size: 0.82rem; min-height: 40px;">
                        Afficher les retards (${delayed10mOrders.length})
                    </button>
                </div>
            `;
        }

        panel.innerHTML = `
            <!-- Real-time header & controls -->
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1.25rem; flex-wrap: wrap; gap: 0.75rem;">
                <div>
                    <div style="display: flex; align-items: center; gap: 0.5rem;">
                        <h2 style="font-size: 1.25rem; margin: 0; color: var(--text-primary);">Tableau de Bord des Commandes</h2>
                        <span class="badge" style="background: rgba(16, 185, 129, 0.15); color: #059669; border: 1px solid #10b981; font-weight: 700; font-size: 0.75rem; display: inline-flex; align-items: center; gap: 0.35rem;">
                            <span style="width: 7px; height: 7px; border-radius: 50%; background: #10b981; display: inline-block; animation: pulse 2s infinite;"></span>
                            Temps réel actif
                        </span>
                    </div>
                    <p style="margin: 0.25rem 0 0 0; font-size: 0.82rem; color: var(--text-secondary);">Gérez l'état de chaque commande et consultez les fiches clients en 1 clic.</p>
                </div>
                <div style="display: flex; gap: 0.4rem; flex-wrap: wrap; align-items: center;">
                    <button class="btn btn-secondary" onclick="refreshDashboardOrdersNow()" title="Actualiser instantanément les commandes" style="padding: 0.4rem 0.75rem; font-size: 0.82rem; font-weight: 700; border-radius: 20px; min-height: 36px; display: inline-flex; align-items: center; gap: 0.35rem;">
                        <i class='ri-refresh-line'></i> Actualiser
                    </button>
                    <button class="btn btn-secondary" onclick="exportOrdersToCSV()" style="padding: 0.4rem 0.75rem; font-size: 0.82rem; font-weight: 700; border-radius: 20px; min-height: 36px; display: inline-flex; align-items: center; gap: 0.35rem;">
                        <i class='ri-inbox-archive-line'></i> Exporter CSV
                    </button>
                </div>
            </div>

            <!-- Search & Filters -->
            <div style="background: var(--bg-card); border: 1px solid var(--border); border-radius: 14px; padding: 0.85rem; margin-bottom: 1.25rem;">
                <div style="display: flex; gap: 0.75rem; flex-wrap: wrap; align-items: center; margin-bottom: 0.75rem;">
                    <div style="flex: 1; min-width: 220px; position: relative;">
                        <input type="text" id="dashboard-orders-search" class="form-control" placeholder="<i class='ri-search-line'></i> Rechercher par client, téléphone, n° commande, plat..." value="${window.dashboardOrdersSearchQuery || ''}" oninput="searchOrdersDashboard(this.value)" style="padding-left: 0.85rem; font-size: 0.85rem; height: 38px; border-radius: 10px; margin: 0;">
                    </div>
                    ${window.dashboardOrdersSearchQuery ? `
                        <button class="btn btn-sm btn-secondary" onclick="clearOrdersDashboardSearch()" style="height: 38px; font-weight: 600;">
                            <i class='ri-close-line'></i> Effacer recherche
                        </button>
                    ` : ''}
                </div>
                <div style="display: flex; gap: 0.4rem; flex-wrap: wrap; align-items: center;">
                    ${filterBtnsHtml}
                </div>
            </div>
            
            ${ordersPageBanner}

            <div class="stats-grid">
                <div class="stat-card">
                    <span class="stat-card-title"><i class='ri-calendar-line'></i> Commandes du jour</span>
                    <span class="stat-card-value">${todayOrders.length}</span>
                </div>
                <div class="stat-card">
                    <span class="stat-card-title"><i class='ri-money-dollar-circle-line'></i> Chiffre d'affaires (Jour)</span>
                    <span class="stat-card-value" style="color: var(--success);">${todayRevenue.toLocaleString()} FCFA</span>
                </div>
                <div class="stat-card ${delayed10mOrders.length > 0 ? 'stat-card-urgent' : ''}">
                    <span class="stat-card-title"><i class="ri-time-line"></i> Commandes en attente</span>
                    <div style="display: flex; align-items: baseline; gap: 0.5rem; flex-wrap: wrap;">
                        <span class="stat-card-value" style="color: ${delayed10mOrders.length > 0 ? '#dc2626' : 'var(--text-primary)'};">${pendingOrders.length}</span>
                        ${delayed10mOrders.length > 0 ? `<span style="font-size: 0.78rem; font-weight: 700; color: #dc2626; background: rgba(220, 38, 38, 0.12); padding: 2px 6px; border-radius: 6px;">dont ${delayed10mOrders.length} > 10 min</span>` : ''}
                    </div>
                </div>
            </div>

            <div class="dashboard-list">
                ${listHtml}
            </div>
        `;
    } 
    else if (dashboardActiveTab === 'reservations') {
        const reservations = store.getReservationsByRestaurant(r.id);
        
        let listHtml = '';
        if (reservations.length === 0) {
            listHtml = `<div style="text-align: center; color: var(--text-secondary); padding: 3rem 0;">Aucune réservation pour le moment.</div>`;
        } else {
            reservations.forEach(res => {
                let statusBadge = '';
                let actionBtns = '';

                if (res.status === 'En attente') {
                    statusBadge = `<span class="badge badge-warning">En Attente</span>`;
                    actionBtns = `
                        <button class="btn btn-success btn-sm" onclick="changeReservationStatus('${res.id}', 'Confirmée')">
                            Confirmer & Envoyer WA <i class='ri-chat-1-line'></i>
                        </button>
                        <button class="btn btn-danger btn-sm" onclick="changeReservationStatus('${res.id}', 'Annulée')">
                            Annuler & WhatsApp <i class='ri-chat-1-line'></i>
                        </button>
                    `;
                } else if (res.status === 'Confirmée') {
                    statusBadge = `<span class="badge badge-success">Confirmée</span>`;
                    actionBtns = `<span style="font-size: 0.8rem; color: var(--success)">Validée</span>`;
                } else {
                    statusBadge = `<span class="badge badge-danger">Annulée</span>`;
                    actionBtns = `<span style="font-size: 0.8rem; color: var(--danger)">Annulée</span>`;
                }

                const formattedDate = new Date(res.date).toLocaleDateString('fr-FR', { weekday: 'short', day: 'numeric', month: 'short' });

                listHtml += `
                    <div class="dashboard-list-item">
                        <div class="list-item-header">
                            <div>
                                <span class="list-item-title">${res.id} - <strong>${res.customerName}</strong></span>
                                <span style="margin-left: 0.5rem;">${statusBadge}</span>
                            </div>
                            <span class="list-item-time"><i class='ri-calendar-line'></i> Prévu le ${formattedDate} à ${res.time}</span>
                        </div>
                        <div class="list-item-details">
                            <i class='ri-group-line'></i> Personnes : <strong>${res.guests} couverts</strong> <br>
                            <i class='ri-phone-line'></i> Téléphone : <a href="https://wa.me/${res.customerPhone.replace(/\+/g, '')}" target="_blank" class="call-btn"><i class='ri-chat-1-line'></i> WhatsApp (${res.customerPhone})</a>
                            ${res.note ? `<br><i class='ri-edit-line'></i> Note client : <em>"${res.note}"</em>` : ''}
                        </div>
                        <div class="list-item-actions">
                            ${actionBtns}
                        </div>
                    </div>
                `;
            });
        }

        panel.innerHTML = `
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1.5rem; flex-wrap: wrap; gap: 1rem;">
                <h2 style="font-size: 1.25rem; margin: 0;">Réservations de Tables</h2>
                <div style="display: flex; gap: 0.5rem;">
                    <button class="btn btn-secondary btn-sm" onclick="exportReservationsToCSV()">
                        <i class='ri-inbox-archive-line'></i> Exporter CSV
                    </button>
                    <button class="btn btn-primary btn-sm" onclick="toggleManualReservationForm()">
                        <i class='ri-add-line'></i> Prendre une réservation (Appel)
                    </button>
                </div>
            </div>
            
            <!-- Manual Reservation Form -->
            <div id="manual-reservation-card" style="display: none; background: var(--bg-card); border: 1px solid var(--border); padding: 1.5rem; border-radius: 20px; margin-bottom: 2rem;">
                <h3 style="font-size: 1rem; margin-bottom: 1.25rem;"><i class='ri-edit-line'></i> Enregistrer une réservation par téléphone</h3>
                <form onsubmit="saveManualReservation(event, '${r.id}')">
                    <div class="form-row">
                        <div class="form-group">
                            <label class="form-label">Nom du client <span class="required">*</span></label>
                            <input type="text" id="mres-name" class="form-control" placeholder="Modou Diagne" required>
                        </div>
                        <div class="form-group">
                            <label class="form-label">Téléphone <span class="required">*</span></label>
                            <input type="tel" id="mres-phone" class="form-control" placeholder="+221 77 123 45 67" required>
                        </div>
                    </div>
                    
                    <div class="form-row" style="margin-top: 1rem;">
                        <div class="form-group">
                            <label class="form-label">Date <span class="required">*</span></label>
                            <input type="date" id="mres-date" class="form-control" required>
                        </div>
                        <div class="form-group">
                            <label class="form-label">Heure <span class="required">*</span></label>
                            <input type="time" id="mres-time" class="form-control" required>
                        </div>
                        <div class="form-group">
                            <label class="form-label">Nombre de couverts <span class="required">*</span></label>
                            <input type="number" id="mres-guests" class="form-control" placeholder="4" min="1" required>
                        </div>
                    </div>
                    
                    <div class="form-group" style="margin-top: 1rem;">
                        <label class="form-label">Note / Commentaires (ex: table extérieure, anniversaire...)</label>
                        <textarea id="mres-note" class="form-control" placeholder="Demande particulière du client..."></textarea>
                    </div>
                    
                    <div style="display: flex; gap: 0.5rem; margin-top: 1.5rem;">
                        <button type="submit" class="btn btn-primary">Enregistrer la réservation</button>
                        <button type="button" class="btn btn-secondary" onclick="toggleManualReservationForm()">Annuler</button>
                    </div>
                </form>
            </div>

            <div class="dashboard-list">
                ${listHtml}
            </div>
        `;
    } 
    else if (dashboardActiveTab === 'reports' || dashboardActiveTab === 'report') {
        const allOrders = store.getOrdersByRestaurant(r.id) || [];
        const todayStr = new Date().toISOString().split('T')[0];
        const now = new Date();
        const sevenDaysAgo = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
        const thirtyDaysAgo = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);

        const validOrders = allOrders.filter(o => o.status !== 'Annulée');
        const todayOrders = validOrders.filter(o => o.createdAt && o.createdAt.startsWith(todayStr));
        const weekOrders = validOrders.filter(o => o.createdAt && new Date(o.createdAt) >= sevenDaysAgo);
        const monthOrders = validOrders.filter(o => o.createdAt && new Date(o.createdAt) >= thirtyDaysAgo);

        const totalRevenue = validOrders.reduce((acc, o) => acc + (Number(o.total) || 0), 0);
        const todayRevenue = todayOrders.reduce((acc, o) => acc + (Number(o.total) || 0), 0);
        const weekRevenue = weekOrders.reduce((acc, o) => acc + (Number(o.total) || 0), 0);
        const monthRevenue = monthOrders.reduce((acc, o) => acc + (Number(o.total) || 0), 0);

        const deliveredCount = allOrders.filter(o => o.status === 'Livrée' || o.status === 'Terminée' || o.status === 'Prête').length;
        const avgBasket = validOrders.length > 0 ? Math.round(totalRevenue / validOrders.length) : 0;

        // Categories breakdown
        const categoryMap = {};
        allOrders.forEach(o => {
            if (Array.isArray(o.items)) {
                o.items.forEach(item => {
                    const dish = (r.menu || []).find(m => m.id === item.id || m.name === item.name);
                    const cat = dish ? (dish.category || 'Menu du Jour') : 'Spécialités';
                    categoryMap[cat] = (categoryMap[cat] || 0) + ((Number(item.price) || 0) * (Number(item.quantity) || 1));
                });
            }
        });
        const categories = Object.keys(categoryMap).map(k => ({ name: k, total: categoryMap[k] })).sort((a, b) => b.total - a.total);
        const maxCatTotal = categories.length > 0 ? Math.max(...categories.map(c => c.total), 1) : 1;

        // Filtered transactions
        const filterPeriod = window.reportsFilterPeriod || 'all';
        let displayOrders = [...allOrders];
        if (filterPeriod === 'today') displayOrders = todayOrders;
        else if (filterPeriod === 'week') displayOrders = weekOrders;
        else if (filterPeriod === 'month') displayOrders = monthOrders;

        let tableRowsHtml = '';
        if (displayOrders.length === 0) {
            tableRowsHtml = `<tr><td colspan="6" style="text-align: center; padding: 2.5rem; color: var(--text-secondary); font-size: 0.9rem;">Aucune transaction enregistrée pour cette période.</td></tr>`;
        } else {
            displayOrders.slice(0, 50).forEach(o => {
                const dateFormatted = o.createdAt ? new Date(o.createdAt).toLocaleString('fr-FR', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' }) : 'Récemment';
                const itemsSummary = Array.isArray(o.items) ? o.items.map(i => `${i.quantity}x ${i.name}`).join(', ') : 'Articles divers';
                
                let badgeClass = 'badge-secondary';
                if (o.status === 'Livrée' || o.status === 'Terminée') badgeClass = 'badge-success';
                else if (o.status === 'En cuisine' || o.status === 'Prête') badgeClass = 'badge-primary';
                else if (o.status === 'En attente') badgeClass = 'badge-warning';
                else if (o.status === 'Annulée') badgeClass = 'badge-danger';

                tableRowsHtml += `
                    <tr style="border-bottom: 1px solid var(--border);">
                        <td style="padding: 0.85rem 1rem; font-family: monospace; font-size: 0.82rem; font-weight: 700; color: var(--primary);">#${(o.id || '').substring(0, 8)}</td>
                        <td style="padding: 0.85rem 1rem; font-size: 0.82rem; color: var(--text-secondary); white-space: nowrap;">${dateFormatted}</td>
                        <td style="padding: 0.85rem 1rem;">
                            <div style="font-weight: 700; font-size: 0.88rem; color: var(--text-primary);">${o.customerName || 'Client'}</div>
                            <div style="font-size: 0.78rem; color: var(--text-secondary);">${o.customerPhone || 'Direct'}</div>
                        </td>
                        <td style="padding: 0.85rem 1rem; font-size: 0.82rem; color: var(--text-secondary); max-width: 250px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;" title="${itemsSummary}">${itemsSummary}</td>
                        <td style="padding: 0.85rem 1rem; font-weight: 800; font-size: 0.92rem; color: var(--text-primary); text-align: right; white-space: nowrap;">${(Number(o.total) || 0).toLocaleString()} FCFA</td>
                        <td style="padding: 0.85rem 1rem; text-align: center;">
                            <span class="badge ${badgeClass}" style="font-size: 0.75rem; padding: 3px 8px; border-radius: 8px;">${o.status || 'En attente'}</span>
                        </td>
                    </tr>
                `;
            });
        }

        panel.innerHTML = `
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1.5rem; flex-wrap: wrap; gap: 1rem;">
                <div>
                    <h2 style="font-size: 1.4rem; margin: 0; color: var(--text-primary); font-weight: 800; display: flex; align-items: center; gap: 0.5rem;">
                        <i class='ri-file-chart-line' style="color: var(--primary);"></i> Rapports Financiers &amp; Ventes
                    </h2>
                    <p style="color: var(--text-secondary); font-size: 0.85rem; margin: 0.25rem 0 0 0;">Analyse détaillée de vos recettes, commandes complétées et transactions comptables.</p>
                </div>
                <div style="display: flex; gap: 0.5rem; flex-wrap: wrap;">
                    <button class="btn btn-outline btn-sm" onclick="window.print()" style="font-weight: 700; display: inline-flex; align-items: center; gap: 0.35rem;">
                        <i class='ri-printer-line'></i> Imprimer
                    </button>
                    <button class="btn btn-primary btn-sm" onclick="window.exportOrdersCSV('${r.id}')" style="font-weight: 700; display: inline-flex; align-items: center; gap: 0.35rem;">
                        <i class='ri-download-2-line'></i> Télécharger CSV Factures
                    </button>
                </div>
            </div>

            <!-- KPI Cards Grid -->
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 1rem; margin-bottom: 1.5rem;">
                <div style="background: var(--bg-card); border: 1px solid var(--border); padding: 1.15rem; border-radius: 14px; box-shadow: 0 2px 8px rgba(0,0,0,0.02);">
                    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 0.4rem;">
                        <span style="font-size: 0.8rem; font-weight: 700; color: var(--text-secondary); text-transform: uppercase;">Recettes Totales</span>
                        <span style="color: var(--primary); font-size: 1.1rem;"><i class='ri-money-cny-circle-line'></i></span>
                    </div>
                    <div style="font-size: 1.45rem; font-weight: 800; color: var(--text-primary);">${totalRevenue.toLocaleString()} <span style="font-size: 0.85rem; font-weight: 600;">FCFA</span></div>
                    <div style="font-size: 0.78rem; color: var(--success); margin-top: 0.25rem; font-weight: 600;">Sur l'ensemble des commandes</div>
                </div>

                <div style="background: var(--bg-card); border: 1px solid var(--border); padding: 1.15rem; border-radius: 14px; box-shadow: 0 2px 8px rgba(0,0,0,0.02);">
                    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 0.4rem;">
                        <span style="font-size: 0.8rem; font-weight: 700; color: var(--text-secondary); text-transform: uppercase;">Aujourd'hui</span>
                        <span style="color: #0284c7; font-size: 1.1rem;"><i class='ri-calendar-check-line'></i></span>
                    </div>
                    <div style="font-size: 1.45rem; font-weight: 800; color: var(--text-primary);">${todayRevenue.toLocaleString()} <span style="font-size: 0.85rem; font-weight: 600;">FCFA</span></div>
                    <div style="font-size: 0.78rem; color: var(--text-secondary); margin-top: 0.25rem;">${todayOrders.length} commande(s) ce jour</div>
                </div>

                <div style="background: var(--bg-card); border: 1px solid var(--border); padding: 1.15rem; border-radius: 14px; box-shadow: 0 2px 8px rgba(0,0,0,0.02);">
                    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 0.4rem;">
                        <span style="font-size: 0.8rem; font-weight: 700; color: var(--text-secondary); text-transform: uppercase;">7 Derniers Jours</span>
                        <span style="color: #f59e0b; font-size: 1.1rem;"><i class='ri-line-chart-line'></i></span>
                    </div>
                    <div style="font-size: 1.45rem; font-weight: 800; color: var(--text-primary);">${weekRevenue.toLocaleString()} <span style="font-size: 0.85rem; font-weight: 600;">FCFA</span></div>
                    <div style="font-size: 0.78rem; color: var(--text-secondary); margin-top: 0.25rem;">${weekOrders.length} commande(s)</div>
                </div>

                <div style="background: var(--bg-card); border: 1px solid var(--border); padding: 1.15rem; border-radius: 14px; box-shadow: 0 2px 8px rgba(0,0,0,0.02);">
                    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 0.4rem;">
                        <span style="font-size: 0.8rem; font-weight: 700; color: var(--text-secondary); text-transform: uppercase;">Panier Moyen</span>
                        <span style="color: #8b5cf6; font-size: 1.1rem;"><i class='ri-shopping-basket-line'></i></span>
                    </div>
                    <div style="font-size: 1.45rem; font-weight: 800; color: var(--text-primary);">${avgBasket.toLocaleString()} <span style="font-size: 0.85rem; font-weight: 600;">FCFA</span></div>
                    <div style="font-size: 0.78rem; color: var(--text-secondary); margin-top: 0.25rem;">${deliveredCount} commande(s) livrée(s)</div>
                </div>
            </div>

            <!-- Categories Breakdown -->
            ${categories.length > 0 ? `
                <div style="background: var(--bg-card); border: 1px solid var(--border); border-radius: 16px; padding: 1.25rem; margin-bottom: 1.5rem;">
                    <h3 style="font-size: 1.05rem; font-weight: 800; color: var(--text-primary); margin: 0 0 1rem 0; display: flex; align-items: center; gap: 0.4rem;">
                        <i class='ri-pie-chart-2-line' style="color: var(--primary);"></i> Répartition des Ventes par Catégorie
                    </h3>
                    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 1rem;">
                        ${categories.map(cat => {
                            const percent = Math.round((cat.total / (totalRevenue || 1)) * 100);
                            return `
                                <div style="background: var(--bg-main); padding: 0.85rem 1rem; border-radius: 12px; border: 1px solid var(--border);">
                                    <div style="display: flex; justify-content: space-between; font-size: 0.85rem; font-weight: 700; margin-bottom: 0.35rem;">
                                        <span style="color: var(--text-primary);">${cat.name}</span>
                                        <span style="color: var(--primary);">${cat.total.toLocaleString()} F (${percent}%)</span>
                                    </div>
                                    <div style="background: var(--border); height: 6px; border-radius: 3px; overflow: hidden;">
                                        <div style="background: var(--primary); height: 100%; width: ${Math.min(100, Math.max(8, percent))}%; border-radius: 3px;"></div>
                                    </div>
                                </div>
                            `;
                        }).join('')}
                    </div>
                </div>
            ` : ''}

            <!-- Transactions Table -->
            <div style="background: var(--bg-card); border: 1px solid var(--border); border-radius: 16px; overflow: hidden; box-shadow: 0 2px 8px rgba(0,0,0,0.02);">
                <div style="display: flex; justify-content: space-between; align-items: center; padding: 1.25rem 1rem; border-bottom: 1px solid var(--border); flex-wrap: wrap; gap: 0.75rem;">
                    <div>
                        <h3 style="font-size: 1.05rem; font-weight: 800; color: var(--text-primary); margin: 0;">Journal des Transactions</h3>
                        <div style="color: var(--text-secondary); font-size: 0.8rem; margin-top: 0.15rem;">Affichage des 50 dernières commandes enregistrées</div>
                    </div>
                    <div style="display: flex; gap: 0.35rem; background: var(--bg-main); padding: 3px; border-radius: 10px; border: 1px solid var(--border);">
                        <button class="btn btn-sm ${filterPeriod === 'all' ? 'btn-primary' : 'btn-ghost'}" onclick="window.reportsFilterPeriod='all'; renderDashboardTabContent(store.getRestaurantById('${r.id}'));" style="padding: 0.3rem 0.65rem; font-size: 0.78rem; font-weight: 700;">Tout</button>
                        <button class="btn btn-sm ${filterPeriod === 'today' ? 'btn-primary' : 'btn-ghost'}" onclick="window.reportsFilterPeriod='today'; renderDashboardTabContent(store.getRestaurantById('${r.id}'));" style="padding: 0.3rem 0.65rem; font-size: 0.78rem; font-weight: 700;">Aujourd'hui</button>
                        <button class="btn btn-sm ${filterPeriod === 'week' ? 'btn-primary' : 'btn-ghost'}" onclick="window.reportsFilterPeriod='week'; renderDashboardTabContent(store.getRestaurantById('${r.id}'));" style="padding: 0.3rem 0.65rem; font-size: 0.78rem; font-weight: 700;">Semaine</button>
                        <button class="btn btn-sm ${filterPeriod === 'month' ? 'btn-primary' : 'btn-ghost'}" onclick="window.reportsFilterPeriod='month'; renderDashboardTabContent(store.getRestaurantById('${r.id}'));" style="padding: 0.3rem 0.65rem; font-size: 0.78rem; font-weight: 700;">Mois</button>
                    </div>
                </div>

                <div style="overflow-x: auto;">
                    <table style="width: 100%; border-collapse: collapse; text-align: left;">
                        <thead>
                            <tr style="background: var(--bg-main); font-size: 0.78rem; font-weight: 700; color: var(--text-secondary); text-transform: uppercase;">
                                <th style="padding: 0.75rem 1rem;">Réf</th>
                                <th style="padding: 0.75rem 1rem;">Date</th>
                                <th style="padding: 0.75rem 1rem;">Client</th>
                                <th style="padding: 0.75rem 1rem;">Articles</th>
                                <th style="padding: 0.75rem 1rem; text-align: right;">Montant</th>
                                <th style="padding: 0.75rem 1rem; text-align: center;">Statut</th>
                            </tr>
                        </thead>
                        <tbody>
                            ${tableRowsHtml}
                        </tbody>
                    </table>
                </div>
            </div>
        `;
    }
    else if (dashboardActiveTab === 'dishes' || dashboardActiveTab === 'products' || dashboardActiveTab === 'menu' || dashboardActiveTab === 'add-menu' || dashboardActiveTab === 'daily-menu') {
        let menuHtml = '';
        if (r.menu.length === 0) {
            menuHtml = `<div style="grid-column: 1/-1; text-align: center; color: var(--text-secondary); padding: 2rem 0; font-size: 0.9rem;">Aucun plat n'a encore été ajouté. Créez votre premier plat ci-dessous.</div>`;
        } else {
            r.menu.forEach(d => {
                const isDaily = d.isDailySpecial === true || d.is_daily_special === true || (d.tag && String(d.tag).toLowerCase().includes('jour'));
                menuHtml += `
                    <div class="dish-card" style="flex-direction: row; height: auto; align-items: center; padding: 0.75rem; gap: 0.85rem; border-left: ${isDaily ? '4px solid var(--primary)' : '1px solid var(--border)'}; border-radius: 12px;">
                        <img src="${d.image}" style="width: 55px; height: 55px; object-fit: cover; border-radius: 8px;" onerror="this.src='https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=100'">
                        <div style="flex-grow: 1; min-width: 0;">
                            <div style="display: flex; align-items: center; gap: 0.5rem; flex-wrap: wrap;">
                                <h4 style="font-size: 0.92rem; margin: 0; font-weight: 600; color: var(--text-primary);">${d.name}</h4>
                                ${isDaily ? `<span style="background: rgba(242, 107, 33, 0.12); color: var(--primary); font-weight: 700; padding: 2px 7px; border-radius: 6px; font-size: 0.72rem;"><i class='ri-star-fill'></i> ${d.tag || 'Plat du jour'}</span>` : ''}
                            </div>
                            <div style="color: var(--primary); font-weight: 700; font-size: 0.85rem; margin-top: 0.15rem;">${d.price.toLocaleString()} FCFA</div>
                        </div>
                        <div style="display: flex; gap: 0.35rem; flex-wrap: wrap; justify-content: flex-end;">
                            <button class="btn ${isDaily ? 'btn-primary' : 'btn-secondary'} btn-sm" style="padding: 0.3rem 0.55rem; font-size: 0.75rem;" onclick="toggleDishDailySpecial('${d.id}')" title="Mettre en avant sur l'accueil">
                                <i class="${isDaily ? 'ri-star-fill' : 'ri-star-line'}"></i> ${isDaily ? 'Vedette' : 'Plat du jour'}
                            </button>
                            <button class="btn ${d.available === false ? 'btn-danger' : 'btn-success'} btn-sm" style="padding: 0.3rem 0.55rem; font-size: 0.75rem;" onclick="toggleDishAvailability('${d.id}', ${d.available !== false})">
                                <i class="${d.available === false ? 'ri-close-circle-line' : 'ri-check-line'}"></i> ${d.available === false ? 'Rupture' : 'Dispo'}
                            </button>
                            <button class="btn btn-secondary btn-sm" style="padding: 0.3rem 0.55rem; font-size: 0.75rem;" onclick="openEditDishForm('${d.id}')" title="Modifier le plat">
                                <i class='ri-edit-line'></i>
                            </button>
                            <button class="btn btn-outline btn-sm" style="padding: 0.3rem 0.55rem; font-size: 0.75rem; color: var(--danger); border-color: var(--danger);" onclick="deleteDish('${d.id}')" title="Supprimer">
                                <i class='ri-delete-bin-line'></i>
                            </button>
                        </div>
                    </div>
                `;
            });
        }

        panel.innerHTML = `
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1.25rem; flex-wrap: wrap; gap: 0.75rem;">
                <div>
                    <h2 style="font-size: 1.3rem; margin: 0; color: var(--text-primary); font-weight: 700;">Menu &amp; Carte des Plats</h2>
                    <p style="color: var(--text-secondary); font-size: 0.85rem; margin: 0.2rem 0 0 0;">Gérez vos plats et activez l'option Plat du Jour pour une visibilité immédiate.</p>
                </div>
                <button class="btn btn-secondary btn-sm" onclick="switchDashboardTab('daily-menu')" style="font-weight: 600; font-size: 0.82rem;">
                    <i class='ri-star-line'></i> Voir mes Plats du Jour
                </button>
            </div>
            
            <div style="display: grid; grid-template-columns: 1fr; gap: 1.25rem;">
                <!-- Add/Edit Dish Form -->
                <div style="background: var(--bg-card); border: 1px solid var(--border); padding: 1.25rem; border-radius: 16px;" id="dish-form-card">
                    <h3 style="font-size: 1.05rem; margin-bottom: 1rem; color: var(--text-primary); font-weight: 700; display: flex; align-items: center; gap: 0.4rem;" id="dish-form-title">
                        <i class='ri-add-circle-line' style="color: var(--primary);"></i> Ajouter un nouveau plat au menu
                    </h3>
                    <form id="dish-editor-form" onsubmit="saveDish(event)">
                        <input type="hidden" id="dish-edit-id" value="">
                        
                        <div class="form-group">
                            <label class="form-label">Nom du plat <span class="required">*</span></label>
                            <input type="text" id="dish-name" class="form-control" placeholder="ex: Thiéboudienne Penda Mbaye, Yassa Poulet..." required>
                        </div>
                        
                        <div class="form-group">
                            <label class="form-label">Description &amp; Ingrédients <span class="required">*</span></label>
                            <textarea id="dish-desc" class="form-control" placeholder="Riz parfumé, légumes frais du marché, assaisonnement maison..." required rows="2"></textarea>
                        </div>
                        
                        <div class="form-row">
                            <div class="form-group">
                                <label class="form-label">Prix (FCFA) <span class="required">*</span></label>
                                <input type="number" id="dish-price" class="form-control" placeholder="2500" required>
                            </div>
                            <div class="form-group">
                                <label class="form-label">Catégorie / Tag</label>
                                <select id="dish-tag-select" class="form-control">
                                    <option value="Plat du jour">Plat du jour</option>
                                    <option value="Spécialité du Jour">Spécialité du Jour</option>
                                    <option value="Suggestion du Chef">Suggestion du Chef</option>
                                    <option value="Formule Midi">Formule Midi</option>
                                    <option value="Fait Maison">Fait Maison</option>
                                </select>
                            </div>
                        </div>

                        <!-- PLAT DU JOUR PROMOTION CHECKBOX -->
                        <div style="background: rgba(242, 107, 33, 0.06); border: 1px dashed rgba(242, 107, 33, 0.35); border-radius: 12px; padding: 0.85rem 1rem; margin-bottom: 1rem;">
                            <label style="display: flex; align-items: center; gap: 0.65rem; cursor: pointer; font-weight: 600; color: var(--text-primary); font-size: 0.9rem; margin: 0;">
                                <input type="checkbox" id="dish-is-daily-special" style="width: 18px; height: 18px; accent-color: var(--primary); cursor: pointer;" checked>
                                <span>Mettre en avant ce plat dans « Plats du Jour » sur la page d'accueil</span>
                            </label>
                            <p style="font-size: 0.78rem; color: var(--text-secondary); margin: 0.25rem 0 0 1.85rem;">Ce plat apparaîtra immédiatement en vedette sur l'accueil avec commande express.</p>
                        </div>

                        <div class="form-group">
                            <label class="form-label">Photo du plat <span class="required">*</span></label>
                            <div style="display: flex; flex-direction: column; gap: 0.5rem;">
                                <select id="dish-image-select" class="form-control" onchange="document.getElementById('dish-image-custom').value = this.value">
                                    <option value="https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500">Poisson Rouge / Thieb</option>
                                    <option value="https://images.unsplash.com/photo-1604503468506-a8da13d82791?w=500">Poulet / Yassa</option>
                                    <option value="https://images.unsplash.com/photo-1544025162-d76694265947?w=500">Grillades / Viandes / Dibi</option>
                                    <option value="https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=500">Burger / Sandwich</option>
                                    <option value="https://images.unsplash.com/photo-1573080496219-bb080dd4f877?w=500">Frites dorées</option>
                                    <option value="https://images.unsplash.com/photo-1497534446932-c925b458314e?w=500">Boisson / Jus maison</option>
                                </select>
                                <input type="text" id="dish-image-custom" class="form-control" placeholder="https://images.unsplash.com/... (URL d'image optionnelle)">
                            </div>
                        </div>
                        
                        <div class="form-group" style="margin-top: 0.75rem;">
                            <label class="form-label">Ou télécharger une photo depuis votre appareil</label>
                            <input type="file" id="dish-image-file" class="form-control" accept="image/*" onchange="handleDishImageUpload(event)" style="padding: 0.35rem; height: auto;">
                            <div id="dish-image-preview-container" style="display: none; margin-top: 0.5rem; align-items: center; gap: 0.5rem; background: var(--bg-secondary); padding: 0.5rem; border-radius: 8px; border: 1px solid var(--border);">
                                <img id="dish-image-preview" src="" style="width: 45px; height: 45px; object-fit: cover; border-radius: 6px;">
                                <span id="dish-image-upload-status" style="font-size: 0.75rem; color: var(--success); font-weight: 600;">Photo prête</span>
                            </div>
                        </div>
                        
                        <div style="display: flex; gap: 0.5rem; margin-top: 1rem;">
                            <button type="submit" class="btn btn-primary" style="flex:1; font-weight: 600;">
                                <i class='ri-save-line'></i> Enregistrer le Plat
                            </button>
                            <button type="button" class="btn btn-secondary" style="display:none;" id="dish-cancel-edit-btn" onclick="resetDishForm()">Annuler</button>
                        </div>
                    </form>
                </div>

                <!-- Current Dishes List -->
                <div style="background: var(--bg-card); border: 1px solid var(--border); padding: 1.25rem; border-radius: 16px;">
                    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 0.85rem; flex-wrap: wrap; gap: 0.5rem;">
                        <h3 style="font-size: 1.05rem; margin: 0; color: var(--text-primary); font-weight: 700;">Plats enregistrés (${r.menu.length})</h3>
                        <span style="font-size: 0.8rem; color: var(--text-secondary);">Les plats étoilés apparaissent sur l'accueil</span>
                    </div>
                    <div style="display: flex; flex-direction: column; gap: 0.65rem;">
                        ${menuHtml}
                    </div>
                </div>
            </div>
        `;
    }
    else if (dashboardActiveTab === 'daily-menu') {
        const dailyDishes = r.menu.filter(d => d.isDailySpecial === true || d.is_daily_special === true || (d.tag && String(d.tag).toLowerCase().includes('jour')));
        const otherDishes = r.menu.filter(d => !(d.isDailySpecial === true || d.is_daily_special === true || (d.tag && String(d.tag).toLowerCase().includes('jour'))));

        let dailyCardsHtml = '';
        if (dailyDishes.length === 0) {
            dailyCardsHtml = `
                <div style="background: var(--bg-secondary); border: 1px dashed var(--border); padding: 2rem 1.25rem; text-align: center; border-radius: 14px; margin-bottom: 1.5rem;">
                    <i class='ri-star-line' style="font-size: 2rem; color: var(--primary); display: block; margin-bottom: 0.5rem;"></i>
                    <h3 style="font-size: 1.05rem; margin-bottom: 0.35rem; color: var(--text-primary); font-weight: 600;">Aucun plat mis en avant aujourd'hui</h3>
                    <p style="color: var(--text-secondary); font-size: 0.85rem; max-width: 450px; margin: 0 auto 1rem auto;">Activez vos spécialités du jour ci-dessous pour qu'elles s'affichent directement sur la page d'accueil de Thiès.</p>
                    <button class="btn btn-primary btn-sm" onclick="switchDashboardTab('menu')" style="font-weight: 600;">
                        <i class='ri-add-line'></i> Choisir ou créer un Plat du Jour
                    </button>
                </div>
            `;
        } else {
            dailyCardsHtml = `
                <div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(260px, 1fr)); gap: 1rem; margin-bottom: 1.5rem;">
                    ${dailyDishes.map(d => `
                        <div style="background: var(--bg-card); border: 1.5px solid var(--primary); border-radius: 14px; overflow: hidden; box-shadow: var(--shadow-sm); display: flex; flex-direction: column;">
                            <div style="position: relative; height: 140px;">
                                <img src="${d.image}" style="width: 100%; height: 100%; object-fit: cover;" onerror="this.src='https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=400'">
                                <span style="position: absolute; top: 8px; left: 8px; background: var(--primary); color: white; font-weight: 700; font-size: 0.72rem; padding: 3px 8px; border-radius: 12px;">
                                    <i class='ri-star-fill'></i> ${d.tag || 'Plat du jour'}
                                </span>
                                <span style="position: absolute; bottom: 8px; right: 8px; background: rgba(0,0,0,0.75); color: white; font-weight: 700; font-size: 0.8rem; padding: 3px 8px; border-radius: 6px;">
                                    ${d.price.toLocaleString()} FCFA
                                </span>
                            </div>
                            <div style="padding: 0.85rem; flex-grow: 1; display: flex; flex-direction: column; justify-content: space-between;">
                                <div>
                                    <h4 style="font-size: 0.95rem; margin: 0 0 0.25rem 0; color: var(--text-primary); font-weight: 600;">${d.name}</h4>
                                    <p style="font-size: 0.8rem; color: var(--text-secondary); margin: 0 0 0.75rem 0; line-height: 1.4;">${d.description}</p>
                                </div>
                                <div style="display: flex; gap: 0.4rem; justify-content: space-between; border-top: 1px solid var(--border); padding-top: 0.65rem;">
                                    <button class="btn btn-outline btn-sm" onclick="toggleDishDailySpecial('${d.id}')" style="font-size: 0.75rem; color: var(--danger); border-color: var(--danger);">
                                        Retirer
                                    </button>
                                    <button class="btn btn-secondary btn-sm" onclick="openEditDishForm('${d.id}'); switchDashboardTab('menu');" style="font-size: 0.75rem;">
                                        <i class='ri-edit-line'></i> Modifier
                                    </button>
                                </div>
                            </div>
                        </div>
                    `).join('')}
                </div>
            `;
        }

        let otherDishesHtml = '';
        if (otherDishes.length > 0) {
            otherDishesHtml = `
                <div style="background: var(--bg-card); border: 1px solid var(--border); padding: 1.25rem; border-radius: 16px; margin-top: 1.25rem;">
                    <h3 style="font-size: 1rem; margin-bottom: 0.35rem; color: var(--text-primary); font-weight: 700;">Autres plats disponibles sur votre carte</h3>
                    <p style="color: var(--text-secondary); font-size: 0.82rem; margin-bottom: 0.85rem;">Cliquez sur « Mettre en Plat du jour » pour afficher le plat sur l'accueil.</p>
                    <div style="display: flex; flex-direction: column; gap: 0.5rem;">
                        ${otherDishes.map(d => `
                            <div style="display: flex; align-items: center; justify-content: space-between; padding: 0.65rem 0.85rem; background: var(--bg-secondary); border-radius: 10px; gap: 0.75rem; flex-wrap: wrap;">
                                <div style="display: flex; align-items: center; gap: 0.65rem;">
                                    <img src="${d.image}" style="width: 42px; height: 42px; border-radius: 6px; object-fit: cover;" onerror="this.src='https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=100'">
                                    <div>
                                        <strong style="font-size: 0.88rem; display: block; color: var(--text-primary);">${d.name}</strong>
                                        <span style="color: var(--primary); font-weight: 700; font-size: 0.82rem;">${d.price.toLocaleString()} FCFA</span>
                                    </div>
                                </div>
                                <button class="btn btn-primary btn-sm" onclick="toggleDishDailySpecial('${d.id}')" style="font-weight: 600; font-size: 0.78rem; padding: 0.35rem 0.75rem;">
                                    <i class='ri-star-line'></i> Mettre en Plat du jour
                                </button>
                            </div>
                        `).join('')}
                    </div>
                </div>
            `;
        }

        panel.innerHTML = `
            <div style="margin-bottom: 1.25rem; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 0.75rem;">
                <div>
                    <h2 style="font-size: 1.3rem; margin: 0; color: var(--text-primary); font-weight: 700;">Menu du Jour &amp; Spécialités</h2>
                    <p style="color: var(--text-secondary); font-size: 0.85rem; margin: 0.2rem 0 0 0;">Ces plats sont affichés en avant sur la page d'accueil de Thiès.</p>
                </div>
                <button class="btn btn-primary btn-sm" onclick="switchDashboardTab('menu')" style="font-weight: 600;">
                    <i class='ri-add-line'></i> Ajouter un nouveau Plat
                </button>
            </div>

            <div style="background: rgba(242, 107, 33, 0.06); border: 1px solid rgba(242, 107, 33, 0.25); border-radius: 12px; padding: 0.85rem 1rem; margin-bottom: 1.25rem; display: flex; align-items: center; gap: 0.75rem;">
                <i class='ri-lightbulb-line' style="font-size: 1.4rem; color: var(--primary);"></i>
                <div style="font-size: 0.85rem; color: var(--text-primary); line-height: 1.4;">
                    <strong>Conseil du midi :</strong> Les clients choisissent leur déjeuner entre 11h et 13h30. Activez votre plat du jour chaque matin pour maximiser vos commandes !
                </div>
            </div>

            <h3 style="font-size: 1.05rem; margin-bottom: 0.85rem; color: var(--text-primary); font-weight: 700;">Plats du Jour Actifs (${dailyDishes.length})</h3>
            ${dailyCardsHtml}

            ${otherDishesHtml}
        `;
    } 
    else if (dashboardActiveTab === 'reviews') {
        let reviewsHtml = '';
        if (r.reviews.length === 0) {
            reviewsHtml = `<div style="text-align: center; color: var(--text-secondary); padding: 3rem 0;">Aucun avis reçu pour l'instant.</div>`;
        } else {
            r.reviews.forEach(rev => {
                const stars = '<i class="star-fill"></i>'.repeat(rev.rating) + '<i class="star-line"></i>'.repeat(5 - rev.rating);
                
                const replySection = rev.reply
                    ? `
                        <div class="review-reply" style="margin-top: 0.75rem;">
                            <div class="review-reply-author">Votre réponse publique :</div>
                            <p>${rev.reply}</p>
                            <button class="btn btn-secondary btn-sm" style="padding: 0.15rem 0.5rem; font-size: 0.7rem; margin-top: 0.5rem;" onclick="openReplyForm('${rev.id}')">Modifier</button>
                        </div>
                    `
                    : `
                        <div id="reply-form-container-${rev.id}" style="margin-top: 0.75rem;">
                            <button class="btn btn-outline btn-sm" onclick="openReplyForm('${rev.id}')">Répondre publiquement</button>
                        </div>
                    `;

                reviewsHtml += `
                    <div class="review-item">
                        <div class="review-header">
                            <div>
                                <span class="review-author">${rev.author}</span>
                                <span class="stars-rating" style="display: block; font-size: 0.8rem;">${stars}</span>
                            </div>
                            <span class="review-date">${rev.date}</span>
                        </div>
                        <p class="review-comment">${rev.comment}</p>
                        ${replySection}
                        
                        <div id="reply-input-area-${rev.id}" style="display:none; margin-top: 0.75rem; background: var(--bg-secondary); padding: 0.75rem; border-radius: 8px;">
                            <label class="form-label" style="font-size: 0.75rem;">Votre réponse :</label>
                            <textarea id="reply-text-${rev.id}" class="form-control" style="font-size: 0.85rem;" placeholder="Merci pour votre retour...">${rev.reply || ''}</textarea>
                            <div style="display: flex; gap: 0.5rem; margin-top: 0.5rem;">
                                <button class="btn btn-primary btn-sm" style="font-size: 0.75rem;" onclick="submitReply('${rev.id}')">Publier</button>
                                <button class="btn btn-secondary btn-sm" style="font-size: 0.75rem;" onclick="closeReplyForm('${rev.id}')">Annuler</button>
                            </div>
                        </div>
                    </div>
                `;
            });
        }

        panel.innerHTML = `
            <h2 style="font-size: 1.25rem; margin-bottom: 1.5rem;">Avis Clients</h2>
            <div class="reviews-list">
                ${reviewsHtml}
            </div>
        `;
    }
    else if (dashboardActiveTab === 'account' || dashboardActiveTab === 'settings') {
        const baseDomain = (window.location.origin.includes('localhost') || window.location.origin.includes('run.app')) 
            ? window.location.origin 
            : 'https://thies-resto.com';
        const clientLink = `${baseDomain}/#/r/${r.slug}`;
        const localQrUrl = `/api/qr?format=image&size=400&text=${encodeURIComponent(clientLink)}`;

        // Compute unique clients for this specific restaurant
        const restoOrders = (typeof store !== 'undefined' && typeof store.getOrdersByRestaurant === 'function') 
            ? store.getOrdersByRestaurant(r.id) || [] 
            : [];
        const clientsMap = {};
        restoOrders.forEach(o => {
            const phone = (o.customerPhone || o.phone || '').trim();
            if (!phone) return;
            if (!clientsMap[phone]) {
                clientsMap[phone] = {
                    phone: phone,
                    name: o.customerName || o.name || 'Client',
                    address: o.address || o.deliveryAddress || '',
                    ordersCount: 0,
                    totalSpent: 0,
                    lastOrderDate: o.createdAt || o.date || ''
                };
            }
            clientsMap[phone].ordersCount++;
            clientsMap[phone].totalSpent += Number(o.total || 0);
            const thisDate = new Date(o.createdAt || o.date || 0);
            const prevDate = new Date(clientsMap[phone].lastOrderDate || 0);
            if (thisDate > prevDate) {
                clientsMap[phone].lastOrderDate = o.createdAt || o.date || '';
                if (o.customerName) clientsMap[phone].name = o.customerName;
            }
        });
        const restoClients = Object.values(clientsMap).sort((a, b) => b.totalSpent - a.totalSpent);
        const totalClientsRevenue = restoClients.reduce((sum, c) => sum + c.totalSpent, 0);

        // Days checklist
        let daysHtml = '';
        const closedDays = Array.isArray(r.closedDays) ? r.closedDays : [];
        for (let i = 1; i <= 7; i++) {
            const isChecked = closedDays.includes(i);
            daysHtml += `
                <label style="display: flex; align-items: center; gap: 0.5rem; margin-bottom: 0.4rem; cursor: pointer; font-size: 0.85rem; color: var(--text-primary);">
                    <input type="checkbox" name="closed-day-check" value="${i}" ${isChecked ? 'checked' : ''} style="accent-color: var(--primary);">
                    ${getDayName(i)}
                </label>
            `;
        }

        const notifGranted = typeof Notification !== 'undefined' && Notification.permission === 'granted';

        // Build HTML for restaurant clients rows
        let clientsListHtml = '';
        if (restoClients.length === 0) {
            clientsListHtml = `
                <div style="padding: 1.5rem; text-align: center; color: var(--text-secondary); font-size: 0.85rem;">
                    <i class='ri-user-unfollow-line' style="font-size: 2rem; display: block; margin-bottom: 0.5rem; opacity: 0.5;"></i>
                    Aucune commande client enregistrée pour le moment.<br>
                    Partagez votre <strong>fiche client</strong> ou vos <strong>QR Codes</strong> pour recevoir vos premières commandes !
                </div>
            `;
        } else {
            clientsListHtml = `
                <div class="table-responsive" style="max-height: 380px; overflow-y: auto;">
                    <table class="gr-table" style="width: 100%; text-align: left; font-size: 0.83rem; border-collapse: collapse;">
                        <thead>
                            <tr style="border-bottom: 2px solid var(--border); color: var(--text-secondary); font-size: 0.75rem; text-transform: uppercase;">
                                <th style="padding: 0.6rem 0.75rem;">Client</th>
                                <th style="padding: 0.6rem 0.75rem;">Téléphone</th>
                                <th style="padding: 0.6rem 0.75rem; text-align: center;">Commandes</th>
                                <th style="padding: 0.6rem 0.75rem; text-align: right;">Total Ventes</th>
                                <th style="padding: 0.6rem 0.75rem; text-align: right;">Dernier Achat</th>
                                <th style="padding: 0.6rem 0.75rem; text-align: center;">Contact</th>
                            </tr>
                        </thead>
                        <tbody>
                            ${restoClients.map(c => {
                                const cleanPhone = (c.phone || '').replace(/[^0-9]/g, '');
                                const intlPhone = cleanPhone.startsWith('221') ? cleanPhone : '221' + cleanPhone;
                                const dateFormatted = c.lastOrderDate ? new Date(c.lastOrderDate).toLocaleDateString('fr-FR', { day: '2-digit', month: 'short' }) : '-';
                                return `
                                    <tr class="resto-client-row" data-search="${(c.name + ' ' + c.phone).toLowerCase()}" style="border-bottom: 1px solid var(--border);">
                                        <td style="padding: 0.65rem 0.75rem; font-weight: 600; color: var(--text-primary);">
                                            ${c.name}
                                            ${c.address ? `<div style="font-size: 0.72rem; color: var(--text-secondary); font-weight: 400;">${c.address}</div>` : ''}
                                        </td>
                                        <td style="padding: 0.65rem 0.75rem; color: var(--text-primary); font-family: monospace;">
                                            ${c.phone}
                                        </td>
                                        <td style="padding: 0.65rem 0.75rem; text-align: center;">
                                            <span class="badge badge-info" style="font-size: 0.75rem; font-weight: 700; padding: 0.2rem 0.5rem; border-radius: 6px;">
                                                ${c.ordersCount}
                                            </span>
                                        </td>
                                        <td style="padding: 0.65rem 0.75rem; text-align: right; font-weight: 700; color: #0B3B24;">
                                            ${formatPrice(c.totalSpent)}
                                        </td>
                                        <td style="padding: 0.65rem 0.75rem; text-align: right; font-size: 0.78rem; color: var(--text-secondary);">
                                            ${dateFormatted}
                                        </td>
                                        <td style="padding: 0.65rem 0.75rem; text-align: center;">
                                            <div style="display: inline-flex; gap: 0.35rem;">
                                                <a href="https://wa.me/${intlPhone}?text=${encodeURIComponent('Bonjour ' + c.name + ', c\'est le restaurant ' + r.name + ' ! Merci de votre fidélité.')}" target="_blank" class="btn btn-ghost btn-xs" title="Message WhatsApp" style="color: #25D366; padding: 0.25rem 0.4rem; font-size: 1rem;">
                                                    <i class='ri-whatsapp-line'></i>
                                                </a>
                                                <a href="tel:${cleanPhone}" class="btn btn-ghost btn-xs" title="Appeler" style="color: var(--primary); padding: 0.25rem 0.4rem; font-size: 1rem;">
                                                    <i class='ri-phone-line'></i>
                                                </a>
                                            </div>
                                        </td>
                                    </tr>
                                `;
                            }).join('')}
                        </tbody>
                    </table>
                </div>
            `;
        }

        panel.innerHTML = `
            <div style="margin-bottom: 1.25rem; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 0.75rem;">
                <div>
                    <h2 style="font-size: 1.3rem; margin: 0; color: var(--text-primary); font-weight: 700;">Paramètres &amp; Outils</h2>
                    <p style="color: var(--text-secondary); font-size: 0.85rem; margin: 0.2rem 0 0 0;">Accédez à votre fiche client, consultez vos clients, téléchargez vos factures CSV et configurez votre établissement.</p>
                </div>
                <button class="btn btn-secondary btn-sm" onclick="switchDashboardTab('subscription')" style="font-weight: 600; font-size: 0.82rem;">
                    <i class='ri-bank-card-line'></i> Mon Abonnement
                </button>
            </div>
            
            <div style="display: grid; grid-template-columns: 1fr; gap: 1.25rem;">
                
                <!-- GRILLE DES 4 PAGES & OUTILS DÉDIÉS : Ma Fiche, Mes Clients, Factures CSV, Support WhatsApp -->
                <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(240px, 1fr)); gap: 1rem;">
                    
                    <!-- 1. Ma Fiche Client -->
                    <div style="background: var(--bg-card); border: 1.5px solid var(--border); padding: 1.15rem; border-radius: 16px; display: flex; flex-direction: column; justify-content: space-between; box-shadow: 0 2px 10px rgba(0,0,0,0.02);">
                        <div>
                            <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 0.6rem;">
                                <span style="display: inline-flex; align-items: center; justify-content: center; width: 38px; height: 38px; border-radius: 10px; background: rgba(11, 59, 36, 0.08); color: #0B3B24;">
                                    <i class='ri-external-link-line' style="font-size: 1.25rem;"></i>
                                </span>
                                <span class="badge badge-success" style="font-size: 0.7rem; font-weight: 700;">En Ligne</span>
                            </div>
                            <h3 style="font-size: 1rem; font-weight: 700; color: var(--text-primary); margin: 0 0 0.3rem 0;">Ma fiche client</h3>
                            <p style="color: var(--text-secondary); font-size: 0.78rem; margin: 0 0 0.85rem 0; line-height: 1.35;">
                                Votre page vitrine publique pour que vos clients découvrent vos plats et commandent directement.
                            </p>
                        </div>
                        <div style="display: flex; gap: 0.4rem; flex-direction: column;">
                            <a href="${clientLink}" target="_blank" class="btn btn-primary btn-sm" style="font-weight: 600; width: 100%; display: inline-flex; align-items: center; justify-content: center; gap: 0.35rem;">
                                <i class='ri-external-link-line'></i> Ouvrir ma fiche
                            </a>
                            <button type="button" class="btn btn-secondary btn-sm" onclick="navigator.clipboard.writeText('${clientLink}'); if(typeof showToast === 'function') showToast('Lien de votre fiche client copié !', 'success');" style="font-weight: 600; width: 100%; display: inline-flex; align-items: center; justify-content: center; gap: 0.35rem;">
                                <i class='ri-file-copy-line'></i> Copier le lien
                            </button>
                        </div>
                    </div>

                    <!-- 2. Mes Clients -->
                    <div style="background: var(--bg-card); border: 1.5px solid var(--border); padding: 1.15rem; border-radius: 16px; display: flex; flex-direction: column; justify-content: space-between; box-shadow: 0 2px 10px rgba(0,0,0,0.02);">
                        <div>
                            <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 0.6rem;">
                                <span style="display: inline-flex; align-items: center; justify-content: center; width: 38px; height: 38px; border-radius: 10px; background: rgba(242, 107, 33, 0.1); color: var(--primary);">
                                    <i class='ri-group-line' style="font-size: 1.25rem;"></i>
                                </span>
                                <span class="badge badge-info" style="font-size: 0.7rem; font-weight: 700;">${restoClients.length} client(s)</span>
                            </div>
                            <h3 style="font-size: 1rem; font-weight: 700; color: var(--text-primary); margin: 0 0 0.3rem 0;">Mes clients</h3>
                            <p style="color: var(--text-secondary); font-size: 0.78rem; margin: 0 0 0.85rem 0; line-height: 1.35;">
                                Répertoire de vos clients, coordonnées WhatsApp, historique et cumul d'achats (${formatPrice(totalClientsRevenue)}).
                            </p>
                        </div>
                        <div style="display: flex; gap: 0.4rem; flex-direction: column;">
                            <button type="button" class="btn btn-primary btn-sm" onclick="toggleRestoClientsDirectory()" style="font-weight: 600; width: 100%; display: inline-flex; align-items: center; justify-content: center; gap: 0.35rem;">
                                <i class='ri-contacts-book-line'></i> Voir le répertoire
                            </button>
                            <button type="button" class="btn btn-secondary btn-sm" onclick="exportRestoClientsCSV('${r.id}')" style="font-weight: 600; width: 100%; display: inline-flex; align-items: center; justify-content: center; gap: 0.35rem;">
                                <i class='ri-download-2-line'></i> Exporter clients CSV
                            </button>
                        </div>
                    </div>

                    <!-- 3. Factures CSV -->
                    <div style="background: var(--bg-card); border: 1.5px solid var(--border); padding: 1.15rem; border-radius: 16px; display: flex; flex-direction: column; justify-content: space-between; box-shadow: 0 2px 10px rgba(0,0,0,0.02);">
                        <div>
                            <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 0.6rem;">
                                <span style="display: inline-flex; align-items: center; justify-content: center; width: 38px; height: 38px; border-radius: 10px; background: rgba(16, 185, 129, 0.1); color: #10B981;">
                                    <i class='ri-file-excel-2-line' style="font-size: 1.25rem;"></i>
                                </span>
                                <span class="badge" style="background: rgba(16, 185, 129, 0.12); color: #047857; font-size: 0.7rem; font-weight: 700;">${restoOrders.length} facture(s)</span>
                            </div>
                            <h3 style="font-size: 1rem; font-weight: 700; color: var(--text-primary); margin: 0 0 0.3rem 0;">Factures CSV</h3>
                            <p style="color: var(--text-secondary); font-size: 0.78rem; margin: 0 0 0.85rem 0; line-height: 1.35;">
                                Exportez en un clic le registre comptable complet de vos commandes et factures au format Excel / CSV.
                            </p>
                        </div>
                        <button type="button" class="btn btn-secondary btn-sm" onclick="window.exportOrdersCSV('${r.id}')" style="font-weight: 600; width: 100%; display: inline-flex; align-items: center; justify-content: center; gap: 0.35rem;">
                            <i class='ri-download-cloud-2-line'></i> Télécharger factures CSV
                        </button>
                    </div>

                    <!-- 4. Support WhatsApp -->
                    <div style="background: var(--bg-card); border: 1.5px solid var(--border); padding: 1.15rem; border-radius: 16px; display: flex; flex-direction: column; justify-content: space-between; box-shadow: 0 2px 10px rgba(0,0,0,0.02);">
                        <div>
                            <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 0.6rem;">
                                <span style="display: inline-flex; align-items: center; justify-content: center; width: 38px; height: 38px; border-radius: 10px; background: rgba(37, 211, 102, 0.12); color: #25D366;">
                                    <i class='ri-whatsapp-line' style="font-size: 1.25rem;"></i>
                                </span>
                                <span class="badge" style="background: rgba(37, 211, 102, 0.15); color: #15803d; font-size: 0.7rem; font-weight: 700;">7j/7</span>
                            </div>
                            <h3 style="font-size: 1rem; font-weight: 700; color: var(--text-primary); margin: 0 0 0.3rem 0;">Support WhatsApp</h3>
                            <p style="color: var(--text-secondary); font-size: 0.78rem; margin: 0 0 0.85rem 0; line-height: 1.35;">
                                Assistance prioritaire directe avec l'équipe de conciergerie Thiès Resto pour toute question ou aide technique.
                            </p>
                        </div>
                        <a href="https://wa.me/221776064596?text=${encodeURIComponent('Bonjour Thiès Resto, support restaurant : ' + r.name + ' (ID: ' + r.slug + ')')}" target="_blank" class="btn btn-sm" style="background: #25D366; color: white; font-weight: 700; width: 100%; display: inline-flex; align-items: center; justify-content: center; gap: 0.35rem; border-radius: 8px;">
                            <i class='ri-whatsapp-line'></i> Contacter le Support
                        </a>
                    </div>

                </div>

                <!-- SECTION DÉTAILLÉE : RÉPERTOIRE DES CLIENTS (EXPANDABLE) -->
                <div id="resto-clients-panel" style="background: var(--bg-card); border: 1.5px solid var(--border); padding: 1.25rem; border-radius: 16px; box-shadow: 0 2px 10px rgba(0,0,0,0.02);">
                    <div style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 0.75rem; margin-bottom: 1rem;">
                        <div>
                            <h3 style="font-size: 1.05rem; font-weight: 700; color: var(--text-primary); margin: 0; display: flex; align-items: center; gap: 0.4rem;">
                                <i class='ri-contacts-book-line' style="color: var(--primary);"></i> Répertoire de Mes Clients (${restoClients.length})
                            </h3>
                            <p style="color: var(--text-secondary); font-size: 0.8rem; margin: 0.2rem 0 0 0;">
                                Consultez vos acheteurs, relancez vos clients fidèles et téléchargez vos fiches contact.
                            </p>
                        </div>
                        <div style="display: flex; gap: 0.5rem; align-items: center;">
                            <input type="text" placeholder="Rechercher par nom ou tél..." oninput="filterRestoClientsList(this.value)" style="font-size: 0.82rem; padding: 0.4rem 0.75rem; border-radius: 8px; border: 1px solid var(--border); background: var(--bg-primary); color: var(--text-primary); min-width: 210px;">
                            <button type="button" class="btn btn-secondary btn-sm" onclick="exportRestoClientsCSV('${r.id}')" title="Exporter en CSV">
                                <i class='ri-file-download-line'></i> CSV
                            </button>
                        </div>
                    </div>
                    ${clientsListHtml}
                </div>
                
                <!-- Open/Closed Status Switch -->
                <div style="background: var(--bg-card); border: 1px solid var(--border); padding: 1.25rem; border-radius: 16px; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 1rem;">
                    <div>
                        <h3 style="font-size: 1rem; margin-bottom: 0.2rem; font-weight: 700; color: var(--text-primary);">Statut de la Boutique (Temps Réel)</h3>
                        <p style="color: var(--text-secondary); font-size: 0.82rem; margin: 0;">Indiquez en direct si votre cuisine est ouverte pour recevoir des commandes.</p>
                    </div>
                    <div style="display: flex; align-items: center; gap: 0.75rem;">
                        <span id="settings-status-label" class="badge ${r.isOpenManual ? 'badge-success' : 'badge-danger'}" style="font-weight: 700; font-size: 0.8rem; padding: 0.35rem 0.75rem; border-radius: 8px;">
                            ${r.isOpenManual ? 'OUVERT' : 'FERMÉ'}
                        </span>
                        <button class="btn ${r.isOpenManual ? 'btn-outline' : 'btn-primary'} btn-sm" onclick="toggleStoreOpenStatus('${r.id}')" style="font-weight: 600; font-size: 0.82rem; ${r.isOpenManual ? 'color: var(--danger); border-color: var(--danger);' : ''}">
                            <i class="${r.isOpenManual ? 'ri-lock-line' : 'ri-lock-unlock-line'}"></i>
                            ${r.isOpenManual ? 'Fermer Boutique' : 'Ouvrir Boutique'}
                        </button>
                    </div>
                </div>

                <!-- Notifications Push & Alertes Sonores -->
                <div style="background: var(--bg-card); border: 1px solid var(--border); padding: 1.25rem; border-radius: 16px;">
                    <div style="display: flex; justify-content: space-between; align-items: flex-start; flex-wrap: wrap; gap: 1rem;">
                        <div style="flex: 1; min-width: 260px;">
                            <div style="display: flex; align-items: center; gap: 0.5rem; margin-bottom: 0.35rem;">
                                <i class='ri-notification-3-line' style="color: var(--primary); font-size: 1.2rem;"></i>
                                <h3 style="font-size: 1rem; font-weight: 700; color: var(--text-primary); margin: 0;">Notifications Push &amp; Alertes Sonores</h3>
                            </div>
                            <p style="color: var(--text-secondary); font-size: 0.82rem; margin: 0 0 0.75rem 0; line-height: 1.4;">
                                Pour ne manquer aucune commande entrante, activez les notifications navigateur. Cliquez sur le bouton pour tester l'alerte sonore et valider la permission de votre appareil.
                            </p>
                            <div id="notif-status-box" style="margin-top: 0.5rem;">
                                ${notifGranted 
                                    ? `<div style="display: flex; align-items: center; gap: 0.4rem; color: var(--success); font-weight: 600; font-size: 0.82rem;"><i class='ri-checkbox-circle-fill'></i> Notifications activées sur cet appareil</div>`
                                    : `<div style="display: flex; align-items: center; gap: 0.4rem; color: var(--text-secondary); font-size: 0.82rem;"><i class='ri-information-line'></i> Cliquez pour autoriser les alertes push</div>`
                                }
                            </div>
                        </div>
                        <div style="display: flex; flex-direction: column; gap: 0.5rem;">
                            <button type="button" id="btn-test-notif" class="btn btn-primary btn-sm" onclick="testRestaurantPushNotification()" style="font-weight: 600; white-space: nowrap;">
                                <i class='ri-volume-up-line'></i> Activer &amp; Tester la Notification
                            </button>
                        </div>
                    </div>
                </div>

                <!-- Info Modification Form -->
                <div style="background: var(--bg-card); border: 1px solid var(--border); padding: 1.25rem; border-radius: 16px;">
                    <h3 style="font-size: 1.05rem; margin-bottom: 1rem; font-weight: 700; color: var(--text-primary); display: flex; align-items: center; gap: 0.4rem;">
                        <i class='ri-settings-3-line' style="color: var(--primary);"></i> Coordonnées &amp; Informations Restaurant
                    </h3>
                    <form onsubmit="saveProfileSettings(event, '${r.id}')">
                        <div class="form-group" style="margin-bottom: 1.25rem;">
                            <label class="form-label">Logo / Photo de Profil</label>
                            <div style="display: flex; align-items: center; gap: 1rem;">
                                <img id="settings-logo-preview" src="${r.image}" style="width: 55px; height: 55px; border-radius: 50%; object-fit: cover; border: 2px solid var(--primary);" onerror="this.src='https://images.unsplash.com/photo-1555396273-367ea4eb4db5?w=200'">
                                <div style="flex: 1;">
                                    <input type="file" id="settings-logo-file" class="form-control" accept="image/*" onchange="handleRestaurantLogoUpload(event)" style="padding: 0.35rem; height: auto;">
                                    <input type="hidden" id="settings-logo-url" value="${r.image}">
                                    <span id="settings-logo-status" style="font-size: 0.75rem; color: var(--success); display: none; margin-top: 0.25rem;">Upload en cours...</span>
                                </div>
                            </div>
                        </div>

                        <div class="form-group" style="background: rgba(242,107,33,0.04); padding: 0.85rem 1rem; border-radius: 12px; border: 1px dashed var(--primary); margin-bottom: 1.25rem;">
                            <label class="form-label" style="color: var(--primary); font-weight: 600;">Coordonnées GPS de l'établissement <span class="required">*</span></label>
                            <div style="display: flex; gap: 0.5rem; margin-bottom: 0.5rem;">
                                <input type="number" id="settings-lat" class="form-control" step="any" value="${r.lat || ''}" placeholder="Latitude (ex: 14.79)" required style="margin-bottom: 0;">
                                <input type="number" id="settings-lng" class="form-control" step="any" value="${r.lng || ''}" placeholder="Longitude (ex: -16.92)" required style="margin-bottom: 0;">
                            </div>
                            <button type="button" class="btn btn-secondary btn-sm" onclick="captureGPSCoordinates()" style="width: 100%; font-size: 0.8rem; font-weight: 600;">
                                <i class='ri-map-pin-user-line'></i> Capturer ma position GPS actuelle
                            </button>
                        </div>

                        <div class="form-group">
                            <label class="form-label">Numéro WhatsApp de réception des commandes <span class="required">*</span></label>
                            <input type="tel" id="settings-whatsapp" class="form-control" value="${r.whatsapp}" required placeholder="+221 77 123 45 67">
                        </div>
                        
                        <div class="form-group">
                            <label class="form-label">Horaires d'ouverture habituels <span class="required">*</span></label>
                            <input type="text" id="settings-hours" class="form-control" value="${r.openHours}" placeholder="ex: 11:30 - 23:30" required>
                        </div>

                        <div class="form-group">
                            <label class="form-label">Jours de fermeture hebdomadaire</label>
                            <div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(130px, 1fr)); gap: 0.4rem; margin-top: 0.35rem;">
                                ${daysHtml}
                            </div>
                        </div>

                        <div class="form-group">
                            <label class="form-label">Changer le mot de passe (Optionnel)</label>
                            <input type="password" id="settings-password" class="form-control" placeholder="Laisser vide si aucun changement">
                        </div>

                        <div style="display: flex; gap: 0.75rem; align-items: center; margin-top: 1.25rem; flex-wrap: wrap;">
                            <button type="submit" id="settings-submit-btn" class="btn btn-primary" style="font-weight: 600;">
                                <i class='ri-save-line'></i> Enregistrer les modifications
                            </button>
                            <button type="button" class="btn btn-outline btn-sm" onclick="logoutRestaurant()" style="margin-left: auto; color: var(--danger); border-color: var(--danger); font-weight: 600;">
                                <i class='ri-logout-box-r-line'></i> Déconnexion
                            </button>
                        </div>
                    </form>
                </div>

                <!-- QR Code Officiel du Restaurant -->
                <div class="qr-container" style="margin: 0 auto; width: 100%; max-width: 500px; background: var(--bg-card); border: 1.5px solid var(--border); padding: 1.5rem; border-radius: 18px; text-align: center; box-shadow: 0 4px 16px rgba(0,0,0,0.03);">
                    <div style="display: inline-flex; align-items: center; justify-content: center; width: 48px; height: 48px; border-radius: 14px; background: rgba(11, 59, 36, 0.1); color: #0B3B24; margin-bottom: 0.75rem;">
                        <i class='ri-qr-code-line' style="font-size: 1.6rem;"></i>
                    </div>
                    <h3 style="font-size: 1.15rem; margin-bottom: 0.35rem; font-weight: 800; color: var(--text-primary);">QR Code de Table de Votre Restaurant</h3>
                    <p style="color: var(--text-secondary); font-size: 0.83rem; margin-bottom: 1.1rem; line-height: 1.45;">
                        Imprimez et posez ce QR Code sur vos tables. Vos clients le scannent directement avec leur téléphone pour ouvrir votre carte et passer commande sur WhatsApp.
                    </p>
                    
                    <div style="background: white; padding: 1rem; border-radius: 14px; display: inline-block; box-shadow: 0 4px 14px rgba(0,0,0,0.06); margin-bottom: 1rem; border: 1px solid rgba(0,0,0,0.08);">
                        <img src="${localQrUrl}" 
                             class="qr-image" 
                             alt="QR Code ${r.name}" 
                             style="width: 220px; height: 220px; display: block; object-fit: contain; margin: 0 auto; border-radius: 6px;" 
                             onerror="this.onerror=null; this.src='https://api.qrserver.com/v1/create-qr-code/?size=260x260&data=${encodeURIComponent(clientLink)}';">
                    </div>

                    <div style="background: rgba(11, 59, 36, 0.05); padding: 0.6rem 0.85rem; border-radius: 10px; margin-bottom: 1.25rem; font-size: 0.78rem; font-family: monospace; color: #0B3B24; word-break: break-all; border: 1px solid rgba(11, 59, 36, 0.15);">
                        <i class='ri-link' style="margin-right: 0.25rem;"></i>${clientLink}
                    </div>

                    <div style="display: flex; gap: 0.6rem; justify-content: center; flex-wrap: wrap;">
                        <a href="${localQrUrl}" download="qrcode-${r.slug}.png" class="btn btn-primary btn-sm" style="font-weight: 700; display: inline-flex; align-items: center; gap: 0.4rem; padding: 0.6rem 1.1rem; border-radius: 10px;">
                            <i class='ri-download-2-line'></i> Télécharger le QR Code (PNG)
                        </a>
                        <a href="${clientLink}" target="_blank" class="btn btn-secondary btn-sm" style="font-weight: 700; display: inline-flex; align-items: center; gap: 0.4rem; padding: 0.6rem 1.1rem; border-radius: 10px;">
                            <i class='ri-external-link-line'></i> Tester ma Page Vendeur
                        </a>
                    </div>
                </div>
            </div>
        `;
    }

    else if (dashboardActiveTab === 'subscription') {
        const currentDate = new Date();
        const createdAt = new Date(r.createdAt || '2026-06-26T00:00:00Z');
        const diffTime = Math.abs(currentDate - createdAt);
        const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
        const daysLeft = Math.max(0, 7 - diffDays);
        const isPaid = r.subscriptionPack && !r.subscriptionPack.includes('Gratuit') && !r.subscriptionPack.includes('Essai') && !r.subscriptionPack.includes('Aucun');
        
        // WhatsApp admin number for subscription requests
        const adminWhatsApp = '221776064596';
        const buildWhatsAppLink = (pack, price, period = 'mois') => {
            const msg = encodeURIComponent(`Bonjour Thiès Resto \n\nJe souhaite souscrire au *${pack}* (${price} FCFA/${period}) pour mon restaurant.\n\n<i class='ri-store-2-line'></i> Restaurant : ${r.name}\nIdentifiant : ${r.slug}\n<i class="inbox-archive-line"></i> Pack choisi : ${pack}\n\nMerci de procéder à l'activation !`);
            return 'https://wa.me/' + adminWhatsApp + '?text=' + msg;
        };

        const escapeTxt = (str) => {
            if (!str) return '';
            return String(str).replace(/[&<>"']/g, m => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[m]);
        };

        const baseDomain = (window.location.origin.includes('localhost') || window.location.origin.includes('run.app')) 
            ? window.location.origin 
            : 'https://thies-resto.com';
        const publicUrl = baseDomain + '/#/r/' + r.slug;
        const qrCodeApiUrl = `/api/qr?format=image&size=300&text=${encodeURIComponent(publicUrl)}`;
        
        // Ensure valid subscription step ('wow' or 'payment')
        const currentStep = window.subscriptionFlowStep === 'payment' ? 'payment' : 'wow';

        if (currentStep === 'wow') {
            // STEP 1 : PAGE EFFET WAOUH (AHA MOMENT)
            panel.innerHTML = `
                <div style="max-width: 1080px; margin: 0 auto;">
                    
                    <!-- Progress Step Indicator -->
                    <div style="display: flex; align-items: center; justify-content: center; gap: 0.75rem; margin-bottom: 1.5rem; flex-wrap: wrap;">
                        <div style="display: flex; align-items: center; gap: 0.45rem; padding: 0.45rem 1.1rem; border-radius: 20px; background: linear-gradient(135deg, #f59e0b, #d97706); color: white; font-weight: 700; font-size: 0.82rem; box-shadow: 0 4px 12px rgba(245, 158, 11, 0.3);">
                            <span>1</span> <span>Étape 1 : Démonstration de la Valeur (Effet Waouh)</span>
                        </div>
                        <i class='ri-arrow-right-s-line' style="color: var(--text-secondary); font-size: 1.2rem;"></i>
                        <button onclick="window.setSubscriptionStep('payment')" style="background: none; border: 1px dashed var(--border); padding: 0.45rem 1.1rem; border-radius: 20px; color: var(--text-secondary); font-weight: 600; font-size: 0.82rem; cursor: pointer; display: inline-flex; align-items: center; gap: 0.45rem; transition: all 0.2s;">
                            <span>2</span> <span>Étape 2 : Affiche de Paiement <i class='ri-arrow-right-line'></i></span>
                        </button>
                    </div>

                    <!-- Hero Banner Waouh -->
                    <div style="background: linear-gradient(135deg, #0f172a 0%, #1e293b 55%, #0369a1 100%); border-radius: 24px; padding: 2.5rem 2rem; color: white; margin-bottom: 2rem; box-shadow: 0 20px 40px -15px rgba(0,0,0,0.35); border: 1px solid rgba(255,255,255,0.1); position: relative; overflow: hidden;">
                        <div style="position: absolute; right: -15px; bottom: -25px; font-size: 11rem; opacity: 0.04; user-select: none; pointer-events: none;"><i class='ri-rocket-line'></i></div>
                        <div style="display: inline-flex; align-items: center; gap: 0.5rem; background: rgba(245, 158, 11, 0.2); border: 1px solid rgba(245, 158, 11, 0.4); color: #fbbf24; padding: 0.35rem 0.9rem; border-radius: 20px; font-size: 0.82rem; font-weight: 700; margin-bottom: 1rem; backdrop-filter: blur(4px);">
                            <i class='ri-sparkling-fill'></i>
                            <span>L'IMPACT DIGITALE DE VOTRE ÉTABLISSEMENT</span>
                        </div>
                        <h1 style="font-size: 2.1rem; font-weight: 800; margin: 0 0 0.75rem 0; line-height: 1.25; font-family: var(--font-serif); color: white;">
                            C'est Magnifique ! Regardez la puissance de « ${escapeTxt(r.name)} » sur Thiès Resto <i class='ri-star-line'></i>
                        </h1>
                        <p style="margin: 0 0 1.75rem 0; font-size: 1.05rem; opacity: 0.92; max-width: 760px; line-height: 1.6; color: #e2e8f0;">
                            Avant de régler votre abonnement, découvrez concrètement tout ce que votre présence sur le réseau Thiès Resto apporte à votre restaurant pour multiplier vos ventes sans aucune commission.
                        </p>
                        <div style="display: flex; gap: 0.75rem; flex-wrap: wrap; align-items: center;">
                            <button onclick="window.setSubscriptionStep('payment')" class="btn" style="font-weight: 800; font-size: 1rem; padding: 0.85rem 1.85rem; border-radius: 14px; background: linear-gradient(135deg, #f59e0b, #ea580c); color: white; border: none; box-shadow: 0 8px 22px rgba(245, 158, 11, 0.4); display: inline-flex; align-items: center; gap: 0.6rem; cursor: pointer;">
                                <span><i class='ri-rocket-line'></i> C'EST TOP ! JE PASSE À L'AFFICHE DE PAIEMENT</span>
                                <i class='ri-arrow-right-line' style="font-size: 1.2rem;"></i>
                            </button>
                            <a href="#/r/${r.slug}" target="_blank" class="btn" style="font-weight: 700; font-size: 0.9rem; padding: 0.85rem 1.4rem; border-radius: 14px; background: rgba(255,255,255,0.12); color: white; border: 1px solid rgba(255,255,255,0.25); backdrop-filter: blur(6px); display: inline-flex; align-items: center; gap: 0.4rem; text-decoration: none;">
                                <i class='ri-external-link-line'></i> Tester ma vue client en direct
                            </a>
                        </div>
                    </div>

                    <!-- 4 Cartes d'Impact Réel -->
                    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(240px, 1fr)); gap: 1.25rem; margin-bottom: 2rem;">
                        <!-- Carte 1 -->
                        <div style="background: var(--bg-card); border: 1px solid var(--border); padding: 1.5rem; border-radius: 20px; box-shadow: var(--shadow); display: flex; flex-direction: column;">
                            <div style="width: 48px; height: 48px; border-radius: 14px; background: rgba(59, 130, 246, 0.1); color: #2563eb; display: flex; align-items: center; justify-content: center; font-size: 1.5rem; margin-bottom: 1rem;">
                                <i class='ri-smartphone-line'></i>
                            </div>
                            <h3 style="margin: 0 0 0.5rem 0; font-size: 1.15rem; font-weight: 800; color: var(--text-primary);">1. Vitrine & Menu HD</h3>
                            <p style="margin: 0 0 1rem 0; font-size: 0.88rem; color: var(--text-secondary); line-height: 1.5; flex-grow: 1;">
                                Plats avec photos appétissantes, descriptions, filtres par catégorie et panier intelligent instantané 24h/24.
                            </p>
                            <div style="background: var(--bg-secondary); padding: 0.6rem 0.85rem; border-radius: 10px; font-size: 0.78rem; font-family: monospace; color: var(--text-secondary); word-break: break-all;">
                                thiesresto.sn/#/r/${r.slug}
                            </div>
                        </div>

                        <!-- Carte 2 -->
                        <div style="background: var(--bg-card); border: 1px solid var(--border); padding: 1.5rem; border-radius: 20px; box-shadow: var(--shadow); display: flex; flex-direction: column;">
                            <div style="width: 48px; height: 48px; border-radius: 14px; background: rgba(16, 185, 129, 0.1); color: #10b981; display: flex; align-items: center; justify-content: center; font-size: 1.5rem; margin-bottom: 1rem;">
                                <i class='ri-qr-code-line'></i>
                            </div>
                            <h3 style="margin: 0 0 0.5rem 0; font-size: 1.15rem; font-weight: 800; color: var(--text-primary);">2. QR Code de Table HD</h3>
                            <p style="margin: 0 0 1rem 0; font-size: 0.88rem; color: var(--text-secondary); line-height: 1.5; flex-grow: 1;">
                                Vos clients scannent sur place pour commander sans attendre les serveurs. Prêt à imprimer dès aujourd'hui.
                            </p>
                            <div style="display: flex; align-items: center; gap: 0.75rem;">
                                <img src="${qrCodeApiUrl}" alt="QR" style="width: 44px; height: 44px; border-radius: 8px; border: 1px solid var(--border); background: white; padding: 2px;" />
                                <a href="${qrCodeApiUrl}" download="QRCode_${r.slug}.png" target="_blank" class="btn btn-secondary btn-sm" style="font-weight: 700; font-size: 0.75rem; padding: 0.4rem 0.6rem;">
                                    Télécharger
                                </a>
                            </div>
                        </div>

                        <!-- Carte 3 -->
                        <div style="background: var(--bg-card); border: 1px solid var(--border); padding: 1.5rem; border-radius: 20px; box-shadow: var(--shadow); display: flex; flex-direction: column;">
                            <div style="width: 48px; height: 48px; border-radius: 14px; background: rgba(245, 158, 11, 0.1); color: #d97706; display: flex; align-items: center; justify-content: center; font-size: 1.5rem; margin-bottom: 1rem;">
                                <i class='ri-money-dollar-circle-line'></i>
                            </div>
                            <h3 style="margin: 0 0 0.5rem 0; font-size: 1.15rem; font-weight: 800; color: var(--text-primary);">3. 0% de Commission</h3>
                            <p style="margin: 0 0 1rem 0; font-size: 0.88rem; color: var(--text-secondary); line-height: 1.5; flex-grow: 1;">
                                Vous gardez 100% du montant de vos commandes. Pas de ponction de 20% à 30% sur votre travail.
                            </p>
                            <span class="badge badge-success" style="font-size: 0.75rem; align-self: flex-start; font-weight: 700;">100% de vos gains pour vous</span>
                        </div>

                        <!-- Carte 4 -->
                        <div style="background: var(--bg-card); border: 1px solid var(--border); padding: 1.5rem; border-radius: 20px; box-shadow: var(--shadow); display: flex; flex-direction: column;">
                            <div style="width: 48px; height: 48px; border-radius: 14px; background: rgba(37, 211, 102, 0.1); color: #25D366; display: flex; align-items: center; justify-content: center; font-size: 1.5rem; margin-bottom: 1rem;">
                                <i class='ri-whatsapp-line'></i>
                            </div>
                            <h3 style="margin: 0 0 0.5rem 0; font-size: 1.15rem; font-weight: 800; color: var(--text-primary);">4. WhatsApp & Alertes</h3>
                            <p style="margin: 0 0 1rem 0; font-size: 0.88rem; color: var(--text-secondary); line-height: 1.5; flex-grow: 1;">
                                Les commandes arrivent formatées, détaillées avec choix de cuisson, adresse et numéro du client en direct.
                            </p>
                            <span class="badge" style="background: rgba(37,211,102,0.15); color: #16a34a; font-size: 0.75rem; align-self: flex-start; font-weight: 700;">Zéro friction client</span>
                        </div>
                    </div>

                    <!-- Comparatif Visuel : Sans vs Avec -->
                    <div style="background: var(--bg-card); border: 1px solid var(--border); border-radius: 24px; padding: 2rem; margin-bottom: 2rem; box-shadow: var(--shadow);">
                        <h2 style="font-size: 1.35rem; font-weight: 800; color: var(--text-primary); margin: 0 0 0.5rem 0; text-align: center;">
                            Pourquoi les Meilleurs Établissements de Thiès choisissent le Mode Pro :
                        </h2>
                        <p style="text-align: center; color: var(--text-secondary); font-size: 0.88rem; margin: 0 0 1.75rem 0;">
                            Un outil puissant, sans engagement, rentabilisé dès vos premières commandes de la semaine.
                        </p>

                        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 1.5rem;">
                            <!-- Colonne Sans -->
                            <div style="border: 1px solid var(--border); border-radius: 16px; padding: 1.5rem; background: var(--bg-secondary);">
                                <div style="display: flex; align-items: center; gap: 0.5rem; margin-bottom: 1rem;">
                                    <span style="font-size: 1.25rem;"><i class='ri-close-circle-line'></i></span>
                                    <h3 style="margin: 0; font-size: 1.05rem; font-weight: 700; color: var(--text-secondary);">Sans Thiès Resto</h3>
                                </div>
                                <ul style="list-style: none; padding: 0; margin: 0; font-size: 0.85rem; color: var(--text-secondary); line-height: 1.8;">
                                    <li>• Menus papier coûteux à imprimer et réimprimer</li>
                                    <li>• 0 visibilité sur internet quand un client cherche à manger</li>
                                    <li>• 20% à 30% de commission perdue sur d'autres plateformes</li>
                                    <li>• Commandes prises au téléphone avec erreurs fréquentes</li>
                                    <li>• Clients qui attendent les serveurs pour avoir la carte</li>
                                </ul>
                            </div>

                            <!-- Colonne Pro -->
                            <div style="border: 2px solid var(--primary); border-radius: 16px; padding: 1.5rem; background: rgba(var(--primary-rgb), 0.04);">
                                <div style="display: flex; align-items: center; gap: 0.5rem; margin-bottom: 1rem;">
                                    <span style="font-size: 1.25rem;"><i class='ri-star-fill'></i></span>
                                    <h3 style="margin: 0; font-size: 1.05rem; font-weight: 800; color: var(--primary);">Avec Thiès Resto Pro</h3>
                                </div>
                                <ul style="list-style: none; padding: 0; margin: 0; font-size: 0.88rem; color: var(--text-primary); line-height: 1.8; font-weight: 600;">
                                    <li><i class='ri-checkbox-circle-line'></i> <strong>Menu digital permanent & illimité</strong> modifiable en 1 clic</li>
                                    <li><i class='ri-checkbox-circle-line'></i> <strong>QR Code HD sur vos tables</strong> pour commander en 5 secondes</li>
                                    <li><i class='ri-checkbox-circle-line'></i> <strong>0% de commission</strong> : Vous gardez 100% de vos recettes</li>
                                    <li><i class='ri-checkbox-circle-line'></i> <strong>Commandes WhatsApp formatées</strong> prêtes à cuisiner</li>
                                    <li><i class='ri-checkbox-circle-line'></i> <strong>Positionnement prioritaire</strong> pour les clients de Thiès</li>
                                </ul>
                            </div>
                        </div>
                    </div>

                    <!-- Grand CTA Déclencheur vers l'Affiche de Paiement -->
                    <div style="background: linear-gradient(135deg, #f59e0b 0%, #ea580c 50%, #e11d48 100%); border-radius: 24px; padding: 2.25rem 2rem; color: white; text-align: center; box-shadow: 0 20px 40px -10px rgba(234, 88, 12, 0.4);">
                        <div style="font-size: 2.5rem; margin-bottom: 0.5rem;"><i class='ri-award-line'></i></div>
                        <h2 style="font-size: 1.85rem; font-weight: 800; margin: 0 0 0.5rem 0; line-height: 1.2;">
                            Convaincu par l'Effet Waouh ?
                        </h2>
                        <p style="font-size: 1rem; opacity: 0.95; max-width: 580px; margin: 0 auto 1.5rem auto; line-height: 1.5;">
                            Passez dès maintenant à la page suivante pour choisir votre formule d'abonnement et activer votre compte sans interruption.
                        </p>
                        <button onclick="window.setSubscriptionStep('payment')" class="btn" style="background: white; color: #ea580c; font-weight: 800; font-size: 1.05rem; padding: 0.95rem 2.25rem; border-radius: 16px; border: none; box-shadow: 0 10px 25px rgba(0,0,0,0.2); cursor: pointer; display: inline-flex; align-items: center; gap: 0.6rem; transition: transform 0.2s;">
                            <span><i class='ri-bank-card-line'></i> VOIR LES FORMULES & L'AFFICHE DE PAIEMENT</span>
                            <i class='ri-arrow-right-line' style="font-size: 1.2rem;"></i>
                        </button>
                    </div>

                </div>
            `;
        } else {
            // STEP 2 : PAGE AFFICHE DE PAIEMENT & FORMULES
            let freePeriodHtml = '';
            if (daysLeft > 0) {
                freePeriodHtml = `
                    <div style="background: linear-gradient(135deg, rgba(16, 185, 129, 0.12), rgba(245, 158, 11, 0.12)); border: 1px solid rgba(16, 185, 129, 0.3); color: var(--text-primary); padding: 1.5rem; border-radius: 16px; margin-bottom: 2rem; display: flex; align-items: center; justify-content: space-between; gap: 1rem; flex-wrap: wrap;">
                        <div>
                            <div style="display: flex; align-items: center; gap: 0.5rem; margin-bottom: 0.35rem;">
                                <span class="badge badge-success" style="font-size: 0.75rem;">Essai Gratuit Actif</span>
                                <span style="font-size: 0.85rem; color: var(--text-secondary); font-weight: 600;">7 jours offerts</span>
                            </div>
                            <h3 style="margin: 0 0 0.35rem 0; font-size: 1.35rem; font-weight: 800; color: var(--text-primary);">Il vous reste ${daysLeft} jour(s) d'accès offert <i class='ri-award-line'></i></h3>
                            <p style="margin: 0; font-size: 0.88rem; color: var(--text-secondary);">Choisissez votre formule à l'avance pour continuer à recevoir vos commandes sans interruption à l'issue de l'essai.</p>
                        </div>
                        <button class="btn btn-secondary btn-sm" onclick="window.setSubscriptionStep('wow')" style="font-weight: 700; font-size: 0.82rem;">
                            <i class='ri-arrow-left-line'></i> Revoir l'Effet Waouh
                        </button>
                    </div>
                `;
            } else {
                const reactivateMsg = encodeURIComponent(`Bonjour Thiès Resto \n\nMa période d'essai gratuit de 7 jours est terminée et je souhaite activer un pack pour réactiver mon restaurant.\n\n<i class="store-2-line"></i> Restaurant : ${r.name}\nIdentifiant : ${r.slug}\n\nMerci de m'indiquer la marche à suivre !`);
                freePeriodHtml = `
                    <div style="background: rgba(239, 68, 68, 0.08); border: 1px solid rgba(239, 68, 68, 0.25); color: var(--text-primary); padding: 1.5rem; border-radius: 16px; margin-bottom: 2rem;">
                        <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 0.75rem; flex-wrap: wrap; gap: 1rem;">
                            <div>
                                <div style="display: flex; align-items: center; gap: 0.5rem; margin-bottom: 0.35rem;">
                                    <span class="badge badge-danger" style="font-size: 0.75rem;">Compte Désactivé</span>
                                    <span style="font-size: 0.85rem; color: var(--danger); font-weight: 700;">Essai 7 Jours Expiré</span>
                                </div>
                                <h3 style="margin: 0 0 0.35rem 0; font-size: 1.35rem; font-weight: 800; color: var(--danger);">Période d'essai terminée <i class='ri-lock-line'></i></h3>
                                <p style="margin: 0; font-size: 0.88rem; color: var(--text-secondary);">Vos 7 jours gratuits sont écoulés. Choisissez un abonnement ci-dessous pour réactiver immédiatement votre établissement.</p>
                            </div>
                            <div style="display: flex; gap: 0.5rem; flex-wrap: wrap;">
                                <button class="btn btn-secondary btn-sm" onclick="window.setSubscriptionStep('wow')" style="font-weight: 700; font-size: 0.82rem;">
                                    <i class='ri-sparkling-fill' style="color: #f59e0b;"></i> Revoir les Avantages
                                </button>
                                <a href="https://wa.me/${adminWhatsApp}?text=${reactivateMsg}" target="_blank" class="btn btn-success btn-sm" style="font-weight: 700; background: #25D366; border-color: #25D366; display: inline-flex; align-items: center; gap: 0.4rem; text-decoration: none; font-size: 0.82rem;">
                                    <i class='ri-chat-1-line'></i> Support WhatsApp
                                </a>
                            </div>
                        </div>
                    </div>
                `;
            }

            panel.innerHTML = `
                <div style="max-width: 1080px; margin: 0 auto;">
                    
                    <!-- Progress Step Indicator -->
                    <div style="display: flex; align-items: center; justify-content: center; gap: 0.75rem; margin-bottom: 1.5rem; flex-wrap: wrap;">
                        <button onclick="window.setSubscriptionStep('wow')" style="background: none; border: 1px dashed var(--border); padding: 0.45rem 1.1rem; border-radius: 20px; color: var(--text-secondary); font-weight: 600; font-size: 0.82rem; cursor: pointer; display: inline-flex; align-items: center; gap: 0.45rem; transition: all 0.2s;">
                            <span>1</span> <span>Étape 1 : Démonstration de la Valeur (Effet Waouh)</span>
                        </button>
                        <i class='ri-arrow-right-s-line' style="color: var(--text-secondary); font-size: 1.2rem;"></i>
                        <div style="display: flex; align-items: center; gap: 0.45rem; padding: 0.45rem 1.1rem; border-radius: 20px; background: linear-gradient(135deg, #0284c7, #2563eb); color: white; font-weight: 700; font-size: 0.82rem; box-shadow: 0 4px 12px rgba(37, 99, 235, 0.3);">
                            <span>2</span> <span>Étape 2 : Affiche de Paiement & Formules Pro</span>
                        </div>
                    </div>

                    <div style="background: var(--bg-card); padding: 2.25rem 2rem; border-radius: 24px; box-shadow: var(--shadow); border: 1px solid var(--border);">
                        
                        <!-- Header with return button -->
                        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1.5rem; border-bottom: 2px solid var(--border); padding-bottom: 1rem; flex-wrap: wrap; gap: 0.75rem;">
                            <div>
                                <div style="display: flex; align-items: center; gap: 0.5rem; margin-bottom: 0.25rem;">
                                    <span class="badge badge-primary" style="font-size: 0.75rem;">Affiche de Paiement</span>
                                    <span style="font-size: 0.85rem; color: var(--text-secondary); font-weight: 600;">Thiès Resto Pro</span>
                                </div>
                                <h1 style="margin: 0; color: var(--text-primary); font-size: 1.75rem; font-weight: 800;"><i class='ri-bank-card-line'></i> Choisissez Votre Formule & Activez Votre Compte</h1>
                            </div>
                            <button class="btn btn-secondary btn-sm" onclick="window.setSubscriptionStep('wow')" style="font-weight: 700; font-size: 0.82rem; display: inline-flex; align-items: center; gap: 0.4rem; border-radius: 10px;">
                                <i class='ri-arrow-left-line'></i> Revoir l'Effet Waouh
                            </button>
                        </div>
                        
                        ${freePeriodHtml}

                        <!-- En-tête Moyens de Paiement Officiels Wave & Orange Money -->
                        <div style="background: var(--bg-card); border: 1.5px solid var(--border); border-radius: 20px; padding: 1.5rem; margin-bottom: 2rem; display: flex; align-items: center; justify-content: space-between; gap: 1.5rem; flex-wrap: wrap; box-shadow: var(--shadow);">
                            <div style="display: flex; align-items: center; gap: 1rem;">
                                <div style="width: 50px; height: 50px; border-radius: 14px; background: rgba(16, 185, 129, 0.1); color: #10b981; display: flex; align-items: center; justify-content: center; font-size: 1.75rem; flex-shrink: 0;">
                                    <i class='ri-secure-payment-line'></i>
                                </div>
                                <div>
                                    <h3 style="margin: 0 0 0.25rem 0; color: var(--text-primary); font-size: 1.25rem; font-weight: 800;">
                                        Moyens de Paiement 100% Sénégalais Acceptés
                                    </h3>
                                    <p style="margin: 0; color: var(--text-secondary); font-size: 0.88rem; line-height: 1.4;">
                                        Réglez votre abonnement mensuel en direct avec <strong>Wave Sénégal</strong> ou <strong>Orange Money Sénégal</strong> sans aucuns frais cachés.
                                    </p>
                                </div>
                            </div>
                            
                            <!-- Badges avec vrais logos officiels -->
                            <div style="display: flex; align-items: center; gap: 0.85rem; flex-wrap: wrap;">
                                <!-- Badge Wave Sénégal -->
                                <div style="display: inline-flex; align-items: center; gap: 0.6rem; background: #E0F7FE; border: 1.5px solid #00B4D8; padding: 0.5rem 1rem; border-radius: 14px; box-shadow: 0 3px 8px rgba(0, 180, 216, 0.18);">
                                    <img src="/images/wave_senegal.png" alt="Wave Sénégal" style="width: 26px; height: 26px; border-radius: 6px; object-fit: contain;">
                                    <div>
                                        <div style="font-weight: 800; color: #0077B6; font-size: 0.88rem; line-height: 1.2;">Wave Sénégal</div>
                                        <div style="font-size: 0.7rem; color: #0284c7; font-weight: 600;">0% de commission</div>
                                    </div>
                                </div>
                                <!-- Badge Orange Money Sénégal -->
                                <div style="display: inline-flex; align-items: center; gap: 0.6rem; background: #FFF4EB; border: 1.5px solid #FF7900; padding: 0.5rem 1rem; border-radius: 14px; box-shadow: 0 3px 8px rgba(255, 121, 0, 0.18);">
                                    <img src="/images/orange_money_senegal.png" alt="Orange Money Sénégal" style="width: 26px; height: 26px; border-radius: 6px; object-fit: contain;">
                                    <div>
                                        <div style="font-weight: 800; color: #D46000; font-size: 0.88rem; line-height: 1.2;">Orange Money</div>
                                        <div style="font-size: 0.7rem; color: #ea580c; font-weight: 600;">Sénégal (#144#)</div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div style="text-align: center; margin-bottom: 2rem;">
                            <h3 style="margin-bottom: 0.35rem; color: var(--text-primary); font-size: 1.35rem; font-weight: 800;">Choisissez Votre Formule d'Abonnement</h3>
                            <p style="color: var(--text-secondary); margin: 0; font-size: 0.92rem;">Activation immédiate après validation du règlement Wave ou Orange Money.</p>
                        </div>
                        
                        <!-- Pricing Grid -->
                        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 1.5rem; margin-bottom: 2rem;">
                            <!-- 1. Pack Standard -->
                            <div style="border: 2px solid var(--border); border-radius: 18px; padding: 1.75rem 1.5rem; display: flex; flex-direction: column; transition: transform 0.3s ease; background: var(--bg-secondary);">
                                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 0.5rem;">
                                    <h4 style="margin: 0; font-size: 1.3rem; color: var(--text-primary);">Pack Standard</h4>
                                    <span class="badge" style="background: rgba(148,163,184,0.15); color: var(--text-primary); font-size: 0.75rem;">Essentiel</span>
                                </div>
                                <div style="font-size: 1.85rem; font-weight: 800; color: var(--primary); margin-bottom: 0.5rem;">9 000 <span style="font-size: 1rem; color: var(--text-secondary); font-weight: 600;">FCFA / mois</span></div>
                                <p style="font-size: 0.85rem; color: var(--text-secondary); margin-bottom: 1rem;">L'autonomie complète pour exister en ligne et recevoir des commandes.</p>
                                
                                <!-- Acceptation Mobile Money Sénégal -->
                                <div style="background: rgba(0,0,0,0.03); border: 1px dashed var(--border); border-radius: 10px; padding: 0.45rem 0.75rem; margin-bottom: 1.25rem; display: flex; align-items: center; justify-content: space-between;">
                                    <span style="font-size: 0.76rem; font-weight: 700; color: var(--text-secondary);">Règlement par :</span>
                                    <div style="display: flex; align-items: center; gap: 0.5rem;">
                                        <span style="display: inline-flex; align-items: center; gap: 4px; font-size: 0.75rem; font-weight: 700; color: #0284c7;">
                                            <img src="/images/wave_senegal.png" alt="Wave" style="width: 17px; height: 17px; border-radius: 4px; object-fit: contain;"> Wave
                                        </span>
                                        <span style="color: var(--border);">|</span>
                                        <span style="display: inline-flex; align-items: center; gap: 4px; font-size: 0.75rem; font-weight: 700; color: #ea580c;">
                                            <img src="/images/orange_money_senegal.png" alt="Orange Money" style="width: 17px; height: 17px; border-radius: 4px; object-fit: contain;"> OM
                                        </span>
                                    </div>
                                </div>

                                <ul style="list-style: none; padding: 0; margin: 0 0 1.5rem 0; flex-grow: 1; color: var(--text-secondary); font-size: 0.92rem; line-height: 1.6;">
                                    <li style="margin-bottom: 0.5rem;"><i class='ri-checkbox-circle-line'></i> <strong>Menu digital complet & illimité</strong> 24/7</li>
                                    <li style="margin-bottom: 0.5rem;"><i class='ri-checkbox-circle-line'></i> Réception illimitée de commandes & WhatsApp</li>
                                    <li style="margin-bottom: 0.5rem;"><i class='ri-checkbox-circle-line'></i> Tableau de bord de gestion & réservations</li>
                                    <li style="margin-bottom: 0.5rem;"><i class='ri-checkbox-circle-line'></i> QR Code de table HD pour vos clients</li>
                                    <li style="margin-bottom: 0.5rem;"><i class='ri-checkbox-circle-line'></i> Historique des ventes & Suivi comptable</li>
                                </ul>

                                <div style="display: flex; flex-direction: column; gap: 0.55rem; margin-top: auto;">
                                    <!-- Bouton Principal avec Vrais Logos Wave & Orange Money -->
                                    <button onclick="window.openSubscriptionPaymentModal('${r.id}', 'Pack Standard', 9000)" class="btn btn-primary" style="width: 100%; display: flex; align-items: center; justify-content: center; gap: 0.6rem; font-weight: 800; font-size: 0.92rem; background: linear-gradient(135deg, #4f46e5, #4338ca); border: none; padding: 0.8rem 1rem; border-radius: 12px; box-shadow: 0 4px 14px rgba(79,70,229,0.3);">
                                        <span style="display: inline-flex; align-items: center; gap: 4px;">
                                            <img src="/images/wave_senegal.png" alt="Wave" style="width: 20px; height: 20px; border-radius: 4px; background: white; padding: 1px;">
                                            <img src="/images/orange_money_senegal.png" alt="Orange Money" style="width: 20px; height: 20px; border-radius: 4px; background: white; padding: 1px;">
                                        </span>
                                        <span><i class="ri-bank-card-line"></i> Payer Ici (9 000 F - SASPAY)</span>
                                    </button>

                                    <!-- Actions Directes Wave & Orange Money -->
                                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 0.4rem;">
                                        <button onclick="window.openSubscriptionPaymentModal('${r.id}', 'Pack Standard', 9000, 'wave')" class="btn btn-sm" style="background: #E0F7FE; border: 1px solid #00B4D8; color: #0077B6; font-weight: 700; font-size: 0.78rem; padding: 0.45rem; border-radius: 8px; display: inline-flex; align-items: center; justify-content: center; gap: 0.35rem;">
                                            <img src="/images/wave_senegal.png" alt="Wave" style="width: 15px; height: 15px; border-radius: 3px;">
                                            <span>Wave</span>
                                        </button>
                                        <button onclick="window.openSubscriptionPaymentModal('${r.id}', 'Pack Standard', 9000, 'orange')" class="btn btn-sm" style="background: #FFF4EB; border: 1px solid #FF7900; color: #D46000; font-weight: 700; font-size: 0.78rem; padding: 0.45rem; border-radius: 8px; display: inline-flex; align-items: center; justify-content: center; gap: 0.35rem;">
                                            <img src="/images/orange_money_senegal.png" alt="Orange Money" style="width: 15px; height: 15px; border-radius: 3px;">
                                            <span>Orange Money</span>
                                        </button>
                                    </div>

                                    <a href="${buildWhatsAppLink('Pack Standard', '9 000')}" target="_blank" class="btn btn-outline btn-sm" style="width: 100%; display: flex; align-items: center; justify-content: center; gap: 0.4rem; text-decoration: none; font-weight: 600; font-size: 0.8rem; padding: 0.5rem; border-radius: 8px;">
                                        <span><i class='ri-chat-1-line'></i></span> Demander par WhatsApp
                                    </a>
                                </div>
                            </div>

                            <!-- 2. Pack Entreprise -->
                            <div style="border: 2px solid var(--primary); border-radius: 18px; padding: 1.75rem 1.5rem; display: flex; flex-direction: column; position: relative; background: rgba(var(--primary-rgb), 0.03); box-shadow: 0 10px 25px rgba(var(--primary-rgb), 0.1);">
                                <div style="position: absolute; top: -12px; right: 20px; background: var(--primary); color: white; padding: 0.2rem 0.8rem; border-radius: 20px; font-size: 0.8rem; font-weight: 700;"><i class='ri-star-fill'></i> Recommandé</div>
                                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 0.5rem;">
                                    <h4 style="margin: 0; font-size: 1.3rem; color: var(--text-primary);">Pack Entreprise</h4>
                                    <span class="badge" style="background: rgba(242,107,33,0.15); color: var(--primary); font-size: 0.75rem;">Visibilité & Accompagnement</span>
                                </div>
                                <div style="font-size: 1.85rem; font-weight: 800; color: var(--primary); margin-bottom: 0.5rem;">15 000 <span style="font-size: 1rem; color: var(--text-secondary); font-weight: 600;">FCFA / mois</span></div>
                                <p style="font-size: 0.85rem; color: var(--text-secondary); margin-bottom: 1rem;">Accélération des ventes avec promotion réseaux sociaux et accompagnement.</p>
                                
                                <!-- Acceptation Mobile Money Sénégal -->
                                <div style="background: rgba(0,0,0,0.03); border: 1px dashed var(--border); border-radius: 10px; padding: 0.45rem 0.75rem; margin-bottom: 1.25rem; display: flex; align-items: center; justify-content: space-between;">
                                    <span style="font-size: 0.76rem; font-weight: 700; color: var(--text-secondary);">Règlement par :</span>
                                    <div style="display: flex; align-items: center; gap: 0.5rem;">
                                        <span style="display: inline-flex; align-items: center; gap: 4px; font-size: 0.75rem; font-weight: 700; color: #0284c7;">
                                            <img src="/images/wave_senegal.png" alt="Wave" style="width: 17px; height: 17px; border-radius: 4px; object-fit: contain;"> Wave
                                        </span>
                                        <span style="color: var(--border);">|</span>
                                        <span style="display: inline-flex; align-items: center; gap: 4px; font-size: 0.75rem; font-weight: 700; color: #ea580c;">
                                            <img src="/images/orange_money_senegal.png" alt="Orange Money" style="width: 17px; height: 17px; border-radius: 4px; object-fit: contain;"> OM
                                        </span>
                                    </div>
                                </div>

                                <ul style="list-style: none; padding: 0; margin: 0 0 1.5rem 0; flex-grow: 1; color: var(--text-primary); font-size: 0.92rem; line-height: 1.6; font-weight: 500;">
                                    <li style="margin-bottom: 0.5rem;"><i class='ri-checkbox-circle-line'></i> <strong>Tout du Pack Standard inclus</strong></li>
                                    <li style="margin-bottom: 0.5rem;"><i class='ri-notification-3-line'></i> <strong>Publicités & visibilité</strong> sur les réseaux Thiès Resto</li>
                                    <li style="margin-bottom: 0.5rem;"><i class='ri-rocket-line'></i> <strong>Apparition prioritaire</strong> dans le catalogue</li>
                                    <li style="margin-bottom: 0.5rem;"><i class='ri-group-line'></i> <strong>Accompagnement mensuel dédié</strong> de l'équipe</li>
                                    <li style="margin-bottom: 0.5rem;"><i class='ri-bar-chart-2-line'></i> <strong>Rapport mensuel détaillé</strong> d'activité & ventes</li>
                                </ul>

                                <div style="display: flex; flex-direction: column; gap: 0.55rem; margin-top: auto;">
                                    <!-- Bouton Principal avec Vrais Logos Wave & Orange Money -->
                                    <button onclick="window.openSubscriptionPaymentModal('${r.id}', 'Pack Entreprise', 15000)" class="btn btn-primary" style="width: 100%; display: flex; align-items: center; justify-content: center; gap: 0.6rem; font-weight: 800; font-size: 0.92rem; background: linear-gradient(135deg, #4f46e5, #4338ca); border: none; box-shadow: 0 4px 14px rgba(79,70,229,0.35); padding: 0.8rem 1rem; border-radius: 12px;">
                                        <span style="display: inline-flex; align-items: center; gap: 4px;">
                                            <img src="/images/wave_senegal.png" alt="Wave" style="width: 20px; height: 20px; border-radius: 4px; background: white; padding: 1px;">
                                            <img src="/images/orange_money_senegal.png" alt="Orange Money" style="width: 20px; height: 20px; border-radius: 4px; background: white; padding: 1px;">
                                        </span>
                                        <span><i class="ri-bank-card-line"></i> Payer Ici (15 000 F - SASPAY)</span>
                                    </button>

                                    <!-- Actions Directes Wave & Orange Money -->
                                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 0.4rem;">
                                        <button onclick="window.openSubscriptionPaymentModal('${r.id}', 'Pack Entreprise', 15000, 'wave')" class="btn btn-sm" style="background: #E0F7FE; border: 1px solid #00B4D8; color: #0077B6; font-weight: 700; font-size: 0.78rem; padding: 0.45rem; border-radius: 8px; display: inline-flex; align-items: center; justify-content: center; gap: 0.35rem;">
                                            <img src="/images/wave_senegal.png" alt="Wave" style="width: 15px; height: 15px; border-radius: 3px;">
                                            <span>Wave</span>
                                        </button>
                                        <button onclick="window.openSubscriptionPaymentModal('${r.id}', 'Pack Entreprise', 15000, 'orange')" class="btn btn-sm" style="background: #FFF4EB; border: 1px solid #FF7900; color: #D46000; font-weight: 700; font-size: 0.78rem; padding: 0.45rem; border-radius: 8px; display: inline-flex; align-items: center; justify-content: center; gap: 0.35rem;">
                                            <img src="/images/orange_money_senegal.png" alt="Orange Money" style="width: 15px; height: 15px; border-radius: 3px;">
                                            <span>Orange Money</span>
                                        </button>
                                    </div>

                                    <a href="${buildWhatsAppLink('Pack Entreprise', '15 000')}" target="_blank" class="btn btn-outline btn-sm" style="width: 100%; display: flex; align-items: center; justify-content: center; gap: 0.4rem; text-decoration: none; font-weight: 600; font-size: 0.8rem; padding: 0.5rem; border-radius: 8px;">
                                        <span><i class='ri-chat-1-line'></i></span> Demander par WhatsApp
                                    </a>
                                </div>
                            </div>

                            <!-- 3. Pack Annuel VIP -->
                            <div style="border: 2px solid #8b5cf6; border-radius: 18px; padding: 1.75rem 1.5rem; display: flex; flex-direction: column; background: rgba(139, 92, 246, 0.04); position: relative; box-shadow: 0 10px 25px rgba(139, 92, 246, 0.08);">
                                <div style="position: absolute; top: -12px; right: 20px; background: #8b5cf6; color: white; padding: 0.2rem 0.8rem; border-radius: 20px; font-size: 0.8rem; font-weight: 700;"><i class='ri-vip-crown-line'></i> Offre VIP (2 Mois Offerts)</div>
                                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 0.5rem;">
                                    <h4 style="margin: 0; font-size: 1.3rem; color: var(--text-primary);">Pack Annuel VIP</h4>
                                    <span class="badge" style="background: rgba(139, 92, 246, 0.15); color: #8b5cf6; font-size: 0.75rem;">12 Mois</span>
                                </div>
                                <div style="font-size: 1.85rem; font-weight: 800; color: #8b5cf6; margin-bottom: 0.5rem;">100 000 <span style="font-size: 1rem; color: var(--text-secondary); font-weight: 600;">FCFA / an</span></div>
                                <p style="font-size: 0.85rem; color: var(--text-secondary); margin-bottom: 1rem;"><span style="text-decoration: line-through; opacity: 0.6;">180 000 F</span> • Économisez 80 000 FCFA et profitez du service tout-inclus.</p>
                                
                                <!-- Acceptation Mobile Money Sénégal -->
                                <div style="background: rgba(0,0,0,0.03); border: 1px dashed var(--border); border-radius: 10px; padding: 0.45rem 0.75rem; margin-bottom: 1.25rem; display: flex; align-items: center; justify-content: space-between;">
                                    <span style="font-size: 0.76rem; font-weight: 700; color: var(--text-secondary);">Règlement par :</span>
                                    <div style="display: flex; align-items: center; gap: 0.5rem;">
                                        <span style="display: inline-flex; align-items: center; gap: 4px; font-size: 0.75rem; font-weight: 700; color: #0284c7;">
                                            <img src="/images/wave_senegal.png" alt="Wave" style="width: 17px; height: 17px; border-radius: 4px; object-fit: contain;"> Wave
                                        </span>
                                        <span style="color: var(--border);">|</span>
                                        <span style="display: inline-flex; align-items: center; gap: 4px; font-size: 0.75rem; font-weight: 700; color: #ea580c;">
                                            <img src="/images/orange_money_senegal.png" alt="Orange Money" style="width: 17px; height: 17px; border-radius: 4px; object-fit: contain;"> OM
                                        </span>
                                    </div>
                                </div>

                                <ul style="list-style: none; padding: 0; margin: 0 0 1.5rem 0; flex-grow: 1; color: var(--text-secondary); font-size: 0.92rem; line-height: 1.6;">
                                    <li style="margin-bottom: 0.5rem;"><i class='ri-checkbox-circle-line'></i> <strong>Tout du Pack Entreprise pendant 1 an</strong></li>
                                    <li style="margin-bottom: 0.5rem;"><i class='ri-camera-line'></i> <strong>Shooting photo & valorisation pro</strong> de vos plats</li>
                                    <li style="margin-bottom: 0.5rem;"><i class='ri-trophy-line'></i> <strong>Badge "Partenaire d'Honneur VIP"</strong> en tête de liste</li>
                                    <li style="margin-bottom: 0.5rem;"><i class='ri-gift-line'></i> <strong>Bonus exclusifs</strong> : Campagnes sponsorisées dédiées</li>
                                    <li style="margin-bottom: 0.5rem;"><i class='ri-flashlight-line'></i> <strong>Support technique & commercial 7j/7 dédié</strong></li>
                                </ul>

                                <div style="display: flex; flex-direction: column; gap: 0.55rem; margin-top: auto;">
                                    <!-- Bouton Principal avec Vrais Logos Wave & Orange Money -->
                                    <button onclick="window.openSubscriptionPaymentModal('${r.id}', 'Pack Annuel VIP', 100000)" class="btn btn-primary" style="width: 100%; display: flex; align-items: center; justify-content: center; gap: 0.6rem; font-weight: 800; font-size: 0.92rem; background: linear-gradient(135deg, #4f46e5, #4338ca); border: none; box-shadow: 0 4px 14px rgba(79,70,229,0.35); padding: 0.8rem 1rem; border-radius: 12px;">
                                        <span style="display: inline-flex; align-items: center; gap: 4px;">
                                            <img src="/images/wave_senegal.png" alt="Wave" style="width: 20px; height: 20px; border-radius: 4px; background: white; padding: 1px;">
                                            <img src="/images/orange_money_senegal.png" alt="Orange Money" style="width: 20px; height: 20px; border-radius: 4px; background: white; padding: 1px;">
                                        </span>
                                        <span><i class="ri-bank-card-line"></i> Payer Ici (100 000 F - SASPAY)</span>
                                    </button>

                                    <!-- Actions Directes Wave & Orange Money -->
                                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 0.4rem;">
                                        <button onclick="window.openSubscriptionPaymentModal('${r.id}', 'Pack Annuel VIP', 100000, 'wave')" class="btn btn-sm" style="background: #E0F7FE; border: 1px solid #00B4D8; color: #0077B6; font-weight: 700; font-size: 0.78rem; padding: 0.45rem; border-radius: 8px; display: inline-flex; align-items: center; justify-content: center; gap: 0.35rem;">
                                            <img src="/images/wave_senegal.png" alt="Wave" style="width: 15px; height: 15px; border-radius: 3px;">
                                            <span>Wave</span>
                                        </button>
                                        <button onclick="window.openSubscriptionPaymentModal('${r.id}', 'Pack Annuel VIP', 100000, 'orange')" class="btn btn-sm" style="background: #FFF4EB; border: 1px solid #FF7900; color: #D46000; font-weight: 700; font-size: 0.78rem; padding: 0.45rem; border-radius: 8px; display: inline-flex; align-items: center; justify-content: center; gap: 0.35rem;">
                                            <img src="/images/orange_money_senegal.png" alt="Orange Money" style="width: 15px; height: 15px; border-radius: 3px;">
                                            <span>Orange Money</span>
                                        </button>
                                    </div>

                                    <a href="${buildWhatsAppLink('Pack Annuel VIP', '100 000', 'an')}" target="_blank" class="btn btn-outline btn-sm" style="width: 100%; border-color: #8b5cf6; color: #8b5cf6; display: flex; align-items: center; justify-content: center; gap: 0.4rem; text-decoration: none; font-weight: 600; font-size: 0.8rem; padding: 0.5rem; border-radius: 8px;">
                                        <span><i class='ri-chat-1-line'></i></span> Demander par WhatsApp
                                    </a>
                                </div>
                            </div>
                        </div>

                        <!-- Security & Guarantee Badge avec Logos Officiels Wave Sénégal & Orange Money -->
                        <div style="background: var(--bg-card); border: 1.5px solid var(--border); border-radius: 18px; padding: 1.5rem; display: flex; align-items: center; justify-content: space-between; gap: 1.25rem; flex-wrap: wrap; box-shadow: var(--shadow);">
                            <div style="display: flex; align-items: center; gap: 1rem;">
                                <i class='ri-shield-check-fill' style="color: #10b981; font-size: 2.2rem; flex-shrink: 0;"></i>
                                <div>
                                    <div style="font-weight: 800; font-size: 0.98rem; color: var(--text-primary); display: flex; align-items: center; gap: 0.6rem; flex-wrap: wrap;">
                                        <span>Paiement Sécurisé & Activation Instantanée</span>
                                        <div style="display: inline-flex; align-items: center; gap: 6px;">
                                            <img src="/images/wave_senegal.png" alt="Wave Sénégal" style="width: 22px; height: 22px; border-radius: 5px; object-fit: contain;" title="Wave Sénégal">
                                            <img src="/images/orange_money_senegal.png" alt="Orange Money Sénégal" style="width: 22px; height: 22px; border-radius: 5px; object-fit: contain;" title="Orange Money Sénégal">
                                        </div>
                                    </div>
                                    <div style="font-size: 0.84rem; color: var(--text-secondary); margin-top: 0.2rem; line-height: 1.4;">
                                        Transactions officielles certifiées par <strong>Wave Sénégal</strong> et <strong>Orange Money Sénégal</strong> via passerelle PayTech. Facture & quitus d'abonnement immédiats.
                                    </div>
                                </div>
                            </div>
                            <button onclick="window.setSubscriptionStep('wow')" class="btn btn-secondary btn-sm" style="font-weight: 700; font-size: 0.84rem; border-radius: 10px;">
                                ⬅️ Revoir l'Effet Waouh
                            </button>
                        </div>

                    </div>
                </div>
            `;
        }
    }
}

/**
 * Guichet Officiel de Paiement d'Abonnement (SASPAY, Wave Sénégal & Orange Money Sénégal)
 */
window.openSubscriptionPaymentModal = function(restaurantId, packName, amount, initialMethod = 'saspay') {
    const r = store.getRestaurantById(restaurantId);
    if (!r) {
        if (typeof showToast === 'function') showToast("Établissement non trouvé.", 'danger');
        return;
    }

    const existing = document.getElementById('subscription-payment-modal');
    if (existing) existing.remove();

    const escapeTxt = (str) => {
        if (!str) return '';
        return String(str).replace(/[&<>"']/g, m => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[m]);
    };

    const formattedAmount = Number(amount).toLocaleString('fr-FR') + ' FCFA';
    const period = packName.includes('VIP') || packName.includes('Annuel') ? 'an' : 'mois';
    const adminWhatsApp = '221776064596';
    const waHelpMsg = encodeURIComponent(`Bonjour Thiès Resto \n\nJe souhaite régler mon abonnement *${packName}* (${formattedAmount}/${period}) pour *${r.name}* via SASPAY.\n\nPouvez-vous m'assister ?`);
    const waLink = `https://wa.me/${adminWhatsApp}?text=${waHelpMsg}`;

    const modal = document.createElement('div');
    modal.id = 'subscription-payment-modal';
    modal.className = 'modal-backdrop';
    modal.style.cssText = 'position: fixed; inset: 0; background: rgba(15, 23, 42, 0.75); backdrop-filter: blur(5px); z-index: 10000; display: flex; align-items: center; justify-content: center; padding: 1rem; overflow-y: auto;';

    modal.innerHTML = `
        <div class="modal-card" style="background: var(--bg-card); border: 1px solid var(--border); border-radius: 24px; width: 100%; max-width: 590px; box-shadow: 0 25px 50px -12px rgba(0,0,0,0.35); overflow: hidden; position: relative;">
            
            <!-- Modal Header -->
            <div style="background: linear-gradient(135deg, #0f172a, #1e293b); color: white; padding: 1.5rem 1.75rem; position: relative;">
                <div style="display: flex; align-items: center; justify-content: space-between; gap: 1rem; margin-bottom: 0.75rem;">
                    <div style="display: inline-flex; align-items: center; gap: 0.5rem; background: rgba(255,255,255,0.12); padding: 0.3rem 0.8rem; border-radius: 20px; font-size: 0.75rem; font-weight: 700;">
                        <span><i class='ri-lock-password-line'></i></span> PAIEMENT SÉCURISÉ SASPAY SÉNÉGAL
                    </div>
                    <button type="button" onclick="document.getElementById('subscription-payment-modal').remove()" style="background: rgba(255,255,255,0.15); border: none; color: white; width: 32px; height: 32px; border-radius: 50%; display: flex; align-items: center; justify-content: center; cursor: pointer; font-size: 1.1rem; transition: background 0.2s;">
                        <i class='ri-close-line'></i>
                    </button>
                </div>
                <h3 style="margin: 0 0 0.35rem 0; font-size: 1.35rem; font-weight: 800; color: white;">Règlement de l'Abonnement</h3>
                <div style="display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 0.5rem; margin-top: 0.5rem;">
                    <span style="font-size: 0.95rem; opacity: 0.9;"><i class='ri-store-2-line'></i> <strong>${escapeTxt(r.name)}</strong> • ${packName}</span>
                    <span style="background: #10b981; color: white; font-weight: 800; font-size: 1rem; padding: 0.25rem 0.85rem; border-radius: 12px; box-shadow: 0 2px 8px rgba(16,185,129,0.3);">
                        ${formattedAmount} / ${period}
                    </span>
                </div>
            </div>

            <!-- Tab Switcher: SASPAY, Wave, Orange Money -->
            <div style="padding: 1.25rem 1.75rem 0 1.75rem;">
                <div style="font-size: 0.82rem; font-weight: 700; color: var(--text-secondary); margin-bottom: 0.6rem; text-transform: uppercase; letter-spacing: 0.5px;">
                    Sélectionnez votre moyen de paiement :
                </div>
                <div style="display: grid; grid-template-columns: 1.2fr 1fr 1fr; gap: 0.5rem;">
                    <!-- Bouton SASPAY En Ligne -->
                    <button type="button" id="sub-tab-btn-saspay" onclick="window.switchSubPaymentTab('saspay')" style="display: flex; flex-direction: column; align-items: center; justify-content: center; padding: 0.65rem 0.5rem; border-radius: 12px; border: 2px solid ${initialMethod === 'saspay' ? '#4f46e5' : 'var(--border)'}; background: ${initialMethod === 'saspay' ? 'rgba(79, 70, 229, 0.08)' : 'var(--bg-secondary)'}; cursor: pointer; transition: all 0.2s;">
                        <span style="font-weight: 800; font-size: 0.85rem; color: #4f46e5; display: flex; align-items: center; gap: 4px;">
                            SASPAY
                        </span>
                        <span style="font-size: 0.68rem; color: #4338ca; font-weight: 600;">En Ligne Direct</span>
                    </button>

                    <!-- Bouton Wave Direct -->
                    <button type="button" id="sub-tab-btn-wave" onclick="window.switchSubPaymentTab('wave')" style="display: flex; flex-direction: column; align-items: center; justify-content: center; padding: 0.65rem 0.5rem; border-radius: 12px; border: 2px solid ${initialMethod === 'wave' ? '#00B4D8' : 'var(--border)'}; background: ${initialMethod === 'wave' ? '#E0F7FE' : 'var(--bg-secondary)'}; cursor: pointer; transition: all 0.2s;">
                        <div style="display: flex; align-items: center; gap: 4px;">
                            <img src="/images/wave_senegal.png" alt="Wave" style="width: 16px; height: 16px; border-radius: 4px;">
                            <span style="font-weight: 800; font-size: 0.85rem; color: #0077B6;">Wave</span>
                        </div>
                        <span style="font-size: 0.68rem; color: #0284c7;">Direct 0%</span>
                    </button>

                    <!-- Bouton Orange Money Direct -->
                    <button type="button" id="sub-tab-btn-orange" onclick="window.switchSubPaymentTab('orange')" style="display: flex; flex-direction: column; align-items: center; justify-content: center; padding: 0.65rem 0.5rem; border-radius: 12px; border: 2px solid ${initialMethod === 'orange' ? '#FF7900' : 'var(--border)'}; background: ${initialMethod === 'orange' ? '#FFF4EB' : 'var(--bg-secondary)'}; cursor: pointer; transition: all 0.2s;">
                        <div style="display: flex; align-items: center; gap: 4px;">
                            <img src="/images/orange_money_senegal.png" alt="OM" style="width: 16px; height: 16px; border-radius: 4px;">
                            <span style="font-weight: 800; font-size: 0.85rem; color: #D46000;">OM</span>
                        </div>
                        <span style="font-size: 0.68rem; color: #ea580c;">#144# Max It</span>
                    </button>
                </div>
            </div>

            <!-- Modal Body Content -->
            <div style="padding: 1.25rem 1.75rem 1.75rem 1.75rem;">
                
                <!-- PANNEAU 0 : SASPAY OFFICIEL (RECOMMANDÉ) -->
                <div id="sub-tab-content-saspay" style="display: ${initialMethod === 'saspay' ? 'block' : 'none'};">
                    <div style="background: linear-gradient(135deg, rgba(79, 70, 229, 0.06), rgba(99, 102, 241, 0.12)); border: 1.5px solid rgba(79, 70, 229, 0.3); border-radius: 16px; padding: 1.25rem; margin-bottom: 1.25rem;">
                        <div style="display: flex; align-items: center; gap: 0.85rem; margin-bottom: 0.9rem;">
                            <div style="width: 46px; height: 46px; border-radius: 12px; background: #4f46e5; color: white; display: flex; align-items: center; justify-content: center; font-size: 1.4rem; font-weight: 900; box-shadow: 0 4px 12px rgba(79, 70, 229, 0.35);">
                                
                            </div>
                            <div>
                                <div style="font-weight: 800; font-size: 1.08rem; color: #3730a3;">Passerelle SASPAY Officielle</div>
                                <div style="font-size: 0.8rem; color: #4338ca;">Paiement instantané Wave, Orange Money et Carte Bancaire</div>
                            </div>
                        </div>

                        <div style="background: white; border: 1px solid rgba(79, 70, 229, 0.2); border-radius: 12px; padding: 1rem; margin-bottom: 0.85rem;">
                            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 0.4rem;">
                                <span style="font-size: 0.82rem; color: #64748B; font-weight: 600;">Abonnement :</span>
                                <strong style="color: #0F172A; font-size: 0.92rem;">${packName}</strong>
                            </div>
                            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 0.4rem;">
                                <span style="font-size: 0.82rem; color: #64748B; font-weight: 600;">Montant total :</span>
                                <strong style="color: #4f46e5; font-size: 1.15rem; font-weight: 800;">${formattedAmount}</strong>
                            </div>
                            <div style="display: flex; justify-content: space-between; align-items: center;">
                                <span style="font-size: 0.82rem; color: #64748B; font-weight: 600;">Activation :</span>
                                <span class="badge badge-success" style="font-size: 0.76rem; font-weight: 700; background: #ecfdf5; color: #047857; padding: 0.2rem 0.5rem; border-radius: 6px;">Instantanée & Automatique</span>
                            </div>
                        </div>

                        <p style="font-size: 0.82rem; color: #4338ca; margin: 0; line-height: 1.4;">
                            ℹ️ Vous serez redirigé en toute sécurité vers l'interface de paiement SASPAY pour valider la transaction.
                        </p>
                    </div>

                    <button type="button" id="btn-sub-saspay-pay" onclick="window.paySubscriptionWithSaspay('${r.id}', '${packName}', ${amount})" class="btn" style="width: 100%; background: linear-gradient(135deg, #4f46e5, #4338ca); color: white; font-weight: 800; font-size: 1.05rem; padding: 0.95rem; border-radius: 14px; border: none; box-shadow: 0 4px 16px rgba(79, 70, 229, 0.4); cursor: pointer; display: flex; align-items: center; justify-content: center; gap: 0.6rem;">
                        <span><i class="ri-bank-card-line"></i> Payer Ici (${formattedAmount})</span>
                    </button>
                </div>

                <!-- PANNEAU 1 : WAVE SÉNÉGAL -->
                <div id="sub-tab-content-wave" style="display: ${initialMethod === 'wave' ? 'block' : 'none'};">
                    <div style="background: #F0F9FF; border: 1.5px solid #BAE6FD; border-radius: 16px; padding: 1.25rem; margin-bottom: 1.25rem;">
                        <div style="display: flex; align-items: center; gap: 0.85rem; margin-bottom: 1rem;">
                            <img src="/images/wave_senegal.png" alt="Wave Sénégal" style="width: 48px; height: 48px; border-radius: 12px; object-fit: contain; box-shadow: 0 4px 10px rgba(0, 180, 216, 0.25);">
                            <div>
                                <div style="font-weight: 800; font-size: 1.08rem; color: #0369A1;">Paiement officiel Wave Sénégal</div>
                                <div style="font-size: 0.8rem; color: #0284c7;">Transfert direct sans frais vers le compte Thiès Resto</div>
                            </div>
                        </div>

                        <div style="background: white; border: 1px solid #E0F2FE; border-radius: 12px; padding: 1rem; margin-bottom: 1rem;">
                            <div style="display: flex; align-items: center; justify-content: space-between; gap: 0.5rem; flex-wrap: wrap;">
                                <div>
                                    <span style="font-size: 0.75rem; color: #64748B; font-weight: 700; text-transform: uppercase;">Numéro Wave officiel :</span>
                                    <div style="font-size: 1.35rem; font-weight: 900; color: #0F172A; letter-spacing: 0.5px;">+221 77 606 45 96</div>
                                </div>
                                <button type="button" onclick="navigator.clipboard.writeText('776064596'); if(typeof showToast==='function') showToast(&quot;Numéro Wave copié : 776064596&quot;, 'success')" class="btn btn-sm" style="background: #E0F2FE; color: #0369A1; font-weight: 700; border: 1px solid #BAE6FD; border-radius: 8px; padding: 0.45rem 0.8rem; cursor: pointer; display: inline-flex; align-items: gap: 0.4rem;">
                                    <i class='ri-file-copy-line'></i> Copier le numéro
                                </button>
                            </div>
                            <div style="margin-top: 0.6rem; padding-top: 0.6rem; border-top: 1px dashed #E2E8F0; font-size: 0.82rem; color: #475569;">
                                <i class='ri-lightbulb-line'></i> Note / Référence à renseigner : <strong>Abonnement ${escapeTxt(r.name)}</strong>
                            </div>
                        </div>

                        <div style="font-size: 0.84rem; color: #0369A1; line-height: 1.5; margin-bottom: 0.5rem;">
                            <strong>Étapes de règlement :</strong>
                            <ol style="margin: 0.35rem 0 0 1.25rem; padding: 0;">
                                <li>Ouvrez votre application <strong>Wave</strong> sur smartphone.</li>
                                <li>Effectuez le transfert de <strong>${formattedAmount}</strong> vers le <strong>77 606 45 96</strong>.</li>
                                <li>Cliquez sur le bouton bleu ci-dessous pour valider immédiatement l'abonnement.</li>
                            </ol>
                        </div>
                    </div>

                    <div style="display: flex; flex-direction: column; gap: 0.6rem;">
                        <button type="button" onclick="window.confirmSubscriptionPayment('${r.id}', '${packName}', ${amount}, 'Wave Sénégal')" class="btn" style="width: 100%; background: linear-gradient(135deg, #00B4D8, #0077B6); color: white; font-weight: 800; font-size: 0.98rem; padding: 0.85rem; border-radius: 12px; border: none; box-shadow: 0 4px 14px rgba(0, 180, 216, 0.4); cursor: pointer; display: flex; align-items: center; justify-content: center; gap: 0.6rem;">
                            <img src="/images/wave_senegal.png" alt="Wave" style="width: 22px; height: 22px; border-radius: 4px; background: white; padding: 1px;">
                            <span>J'AI ENVOYÉ LE TRANSFERT WAVE (${formattedAmount})</span>
                        </button>
                        
                        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 0.5rem;">
                            <a href="https://wave.com/send" target="_blank" class="btn btn-outline btn-sm" style="border-color: #00B4D8; color: #0077B6; font-weight: 700; display: flex; align-items: center; justify-content: center; gap: 0.4rem; text-decoration: none; padding: 0.6rem; border-radius: 10px;">
                                <i class='ri-external-link-line'></i> Ouvrir Wave Web
                            </a>
                            <button type="button" onclick="window.switchSubPaymentTab('saspay')" class="btn btn-secondary btn-sm" style="font-weight: 700; padding: 0.6rem; border-radius: 10px; display: inline-flex; align-items: center; justify-content: center; gap: 0.4rem;">
                                <span><i class="ri-bank-card-line"></i> Payer Ici (SASPAY)</span>
                            </button>
                        </div>
                    </div>
                </div>

                <!-- PANNEAU 2 : ORANGE MONEY SÉNÉGAL -->
                <div id="sub-tab-content-orange" style="display: ${initialMethod === 'orange' ? 'block' : 'none'};">
                    <div style="background: #FFF7ED; border: 1.5px solid #FED7AA; border-radius: 16px; padding: 1.25rem; margin-bottom: 1.25rem;">
                        <div style="display: flex; align-items: center; gap: 0.85rem; margin-bottom: 1rem;">
                            <img src="/images/orange_money_senegal.png" alt="Orange Money Sénégal" style="width: 48px; height: 48px; border-radius: 12px; object-fit: contain; box-shadow: 0 4px 10px rgba(255, 121, 0, 0.25);">
                            <div>
                                <div style="font-weight: 800; font-size: 1.08rem; color: #C2410C;">Paiement officiel Orange Money Sénégal</div>
                                <div style="font-size: 0.8rem; color: #ea580c;">Paiement via syntaxe USSD #144# ou l'application Orange Money (Max It)</div>
                            </div>
                        </div>

                        <div style="background: white; border: 1px solid #FFEDD5; border-radius: 12px; padding: 1rem; margin-bottom: 1rem;">
                            <div style="display: flex; align-items: center; justify-content: space-between; gap: 0.5rem; flex-wrap: wrap;">
                                <div>
                                    <span style="font-size: 0.75rem; color: #64748B; font-weight: 700; text-transform: uppercase;">Numéro Orange Money :</span>
                                    <div style="font-size: 1.35rem; font-weight: 900; color: #0F172A; letter-spacing: 0.5px;">+221 77 606 45 96</div>
                                </div>
                                <button type="button" onclick="navigator.clipboard.writeText('776064596'); if(typeof showToast==='function') showToast(&quot;Numéro Orange Money copié : 776064596&quot;, 'success')" class="btn btn-sm" style="background: #FFEDD5; color: #C2410C; font-weight: 700; border: 1px solid #FED7AA; border-radius: 8px; padding: 0.45rem 0.8rem; cursor: pointer; display: inline-flex; align-items: center; gap: 0.4rem;">
                                    <i class='ri-file-copy-line'></i> Copier le numéro
                                </button>
                            </div>
                            <div style="margin-top: 0.6rem; padding-top: 0.6rem; border-top: 1px dashed #E2E8F0; font-size: 0.82rem; color: #475569;">
                                <i class='ri-lightbulb-line'></i> Note / Référence OM : <strong>Abonnement ${escapeTxt(r.name)}</strong>
                            </div>
                        </div>

                        <div style="font-size: 0.84rem; color: #C2410C; line-height: 1.5; margin-bottom: 0.5rem;">
                            <strong>Étapes de règlement :</strong>
                            <ol style="margin: 0.35rem 0 0 1.25rem; padding: 0;">
                                <li>Composez le <strong>#144#</strong> ou ouvrez l'application <strong>Max It</strong>.</li>
                                <li>Envoyez le montant de <strong>${formattedAmount}</strong> vers le <strong>77 606 45 96</strong>.</li>
                                <li>Cliquez sur le bouton orange ci-dessous pour confirmer immédiatement votre abonnement.</li>
                            </ol>
                        </div>
                    </div>

                    <div style="display: flex; flex-direction: column; gap: 0.6rem;">
                        <button type="button" onclick="window.confirmSubscriptionPayment('${r.id}', '${packName}', ${amount}, 'Orange Money Sénégal')" class="btn" style="width: 100%; background: linear-gradient(135deg, #FF7900, #EA580C); color: white; font-weight: 800; font-size: 0.98rem; padding: 0.85rem; border-radius: 12px; border: none; box-shadow: 0 4px 14px rgba(255, 121, 0, 0.4); cursor: pointer; display: flex; align-items: center; justify-content: center; gap: 0.6rem;">
                            <img src="/images/orange_money_senegal.png" alt="OM" style="width: 22px; height: 22px; border-radius: 4px; background: white; padding: 1px;">
                            <span>J'AI ENVOYÉ LE TRANSFERT ORANGE MONEY (${formattedAmount})</span>
                        </button>
                        
                        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 0.5rem;">
                            <a href="tel:*144#" class="btn btn-outline btn-sm" style="border-color: #FF7900; color: #EA580C; font-weight: 700; display: flex; align-items: center; justify-content: center; gap: 0.4rem; text-decoration: none; padding: 0.6rem; border-radius: 10px;">
                                <i class='ri-phone-line'></i> Composer #144#
                            </a>
                            <button type="button" onclick="window.switchSubPaymentTab('saspay')" class="btn btn-secondary btn-sm" style="font-weight: 700; padding: 0.6rem; border-radius: 10px; display: inline-flex; align-items: center; justify-content: center; gap: 0.4rem;">
                                <span><i class="ri-bank-card-line"></i> Payer Ici (SASPAY)</span>
                            </button>
                        </div>
                    </div>
                </div>

            </div>

            <!-- Footer WhatsApp Support -->
            <div style="background: var(--bg-secondary); border-top: 1px solid var(--border); padding: 0.85rem 1.75rem; display: flex; align-items: center; justify-content: space-between; font-size: 0.82rem; color: var(--text-secondary);">
                <span>Besoin d'un accompagnement direct ?</span>
                <a href="${waLink}" target="_blank" style="color: #16a34a; font-weight: 700; text-decoration: none; display: inline-flex; align-items: center; gap: 0.35rem;">
                    <i class='ri-whatsapp-line'></i> Assistance WhatsApp Thiès Resto
                </a>
            </div>

        </div>
    `;

    document.body.appendChild(modal);
};

window.switchSubPaymentTab = function(method) {
    const tabSaspay = document.getElementById('sub-tab-btn-saspay');
    const tabWave = document.getElementById('sub-tab-btn-wave');
    const tabOrange = document.getElementById('sub-tab-btn-orange');
    const contentSaspay = document.getElementById('sub-tab-content-saspay');
    const contentWave = document.getElementById('sub-tab-content-wave');
    const contentOrange = document.getElementById('sub-tab-content-orange');

    // Reset all tabs
    if (tabSaspay) {
        tabSaspay.style.borderColor = 'var(--border)';
        tabSaspay.style.background = 'var(--bg-secondary)';
    }
    if (tabWave) {
        tabWave.style.borderColor = 'var(--border)';
        tabWave.style.background = 'var(--bg-secondary)';
    }
    if (tabOrange) {
        tabOrange.style.borderColor = 'var(--border)';
        tabOrange.style.background = 'var(--bg-secondary)';
    }

    if (contentSaspay) contentSaspay.style.display = 'none';
    if (contentWave) contentWave.style.display = 'none';
    if (contentOrange) contentOrange.style.display = 'none';

    if (method === 'saspay') {
        if (tabSaspay) {
            tabSaspay.style.borderColor = '#4f46e5';
            tabSaspay.style.background = 'rgba(79, 70, 229, 0.08)';
        }
        if (contentSaspay) contentSaspay.style.display = 'block';
    } else if (method === 'wave') {
        if (tabWave) {
            tabWave.style.borderColor = '#00B4D8';
            tabWave.style.background = '#E0F7FE';
        }
        if (contentWave) contentWave.style.display = 'block';
    } else if (method === 'orange') {
        if (tabOrange) {
            tabOrange.style.borderColor = '#FF7900';
            tabOrange.style.background = '#FFF4EB';
        }
        if (contentOrange) contentOrange.style.display = 'block';
    }
};

window.playOrderAlertSound = function() {
    try {
        const AudioCtx = window.AudioContext || window.webkitAudioContext;
        if (!AudioCtx) return;
        const ctx = new AudioCtx();
        if (ctx.state === 'suspended') {
            ctx.resume();
        }
        const now = ctx.currentTime;
        
        // Bell chime tone 1 (880 Hz - note A5)
        const osc1 = ctx.createOscillator();
        const gain1 = ctx.createGain();
        osc1.type = 'sine';
        osc1.frequency.setValueAtTime(880, now);
        gain1.gain.setValueAtTime(0.25, now);
        gain1.gain.exponentialRampToValueAtTime(0.001, now + 0.4);
        osc1.connect(gain1);
        gain1.connect(ctx.destination);
        osc1.start(now);
        osc1.stop(now + 0.4);

        // Bell chime tone 2 (1320 Hz - note E6)
        const osc2 = ctx.createOscillator();
        const gain2 = ctx.createGain();
        osc2.type = 'sine';
        osc2.frequency.setValueAtTime(1320, now + 0.12);
        gain2.gain.setValueAtTime(0.3, now + 0.12);
        gain2.gain.exponentialRampToValueAtTime(0.001, now + 0.7);
        osc2.connect(gain2);
        gain2.connect(ctx.destination);
        osc2.start(now + 0.12);
        osc2.stop(now + 0.7);
    } catch(e) {
        console.warn("Order audio chime notice:", e);
    }
};

window.toggleRestoClientsDirectory = function() {
    const el = document.getElementById('resto-clients-panel');
    if (!el) return;
    if (el.style.display === 'none') {
        el.style.display = 'block';
        el.scrollIntoView({ behavior: 'smooth', block: 'start' });
    } else {
        el.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
};

window.filterRestoClientsList = function(query) {
    const q = (query || '').toLowerCase().trim();
    const rows = document.querySelectorAll('.resto-client-row');
    rows.forEach(row => {
        const text = row.getAttribute('data-search') || '';
        if (!q || text.includes(q)) {
            row.style.display = '';
        } else {
            row.style.display = 'none';
        }
    });
};

window.exportRestoClientsCSV = function(restoId) {
    const id = restoId || (typeof currentRestaurantSession !== 'undefined' && currentRestaurantSession ? currentRestaurantSession.id : null);
    if (!id || typeof store === 'undefined' || typeof store.getRestaurantById !== 'function') return;
    const r = store.getRestaurantById(id);
    if (!r) return;
    const orders = (typeof store.getOrdersByRestaurant === 'function') ? store.getOrdersByRestaurant(r.id) || [] : [];
    const clientsMap = {};
    orders.forEach(o => {
        const phone = (o.customerPhone || o.phone || '').trim();
        if (!phone) return;
        if (!clientsMap[phone]) {
            clientsMap[phone] = {
                phone: phone,
                name: o.customerName || o.name || 'Client',
                ordersCount: 0,
                totalSpent: 0,
                lastOrderDate: o.createdAt || o.date || ''
            };
        }
        clientsMap[phone].ordersCount++;
        clientsMap[phone].totalSpent += Number(o.total || 0);
        const thisDate = new Date(o.createdAt || o.date || 0);
        const prevDate = new Date(clientsMap[phone].lastOrderDate || 0);
        if (thisDate > prevDate) {
            clientsMap[phone].lastOrderDate = o.createdAt || o.date || '';
            if (o.customerName) clientsMap[phone].name = o.customerName;
        }
    });
    const clients = Object.values(clientsMap).sort((a, b) => b.totalSpent - a.totalSpent);
    if (clients.length === 0) {
        if (typeof showToast === 'function') {
            showToast("Aucun client à exporter pour le moment", "warning");
        }
        return;
    }

    let csvContent = "\ufeff";
    csvContent += "Nom Client;Telephone;Nombre de Commandes;Total Depense (FCFA);Derniere Commande\n";
    clients.forEach(c => {
        const name = (c.name || '').replace(/"/g, '""');
        const phone = (c.phone || '').replace(/"/g, '""');
        const row = [
            `"${name}"`,
            `"${phone}"`,
            c.ordersCount,
            c.totalSpent,
            `"${c.lastOrderDate}"`
        ].join(';');
        csvContent += row + "\n";
    });

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const encodedUrl = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUrl);
    link.setAttribute("download", `clients_${r.slug || r.id}_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    if (typeof showToast === 'function') {
        showToast("Répertoire clients exporté en CSV avec succès !", "success");
    }
};

window.confirmSubscriptionPayment = async function(restaurantId, packName, amount, paymentMethod) {
    const modal = document.getElementById('subscription-payment-modal');
    const r = store.getRestaurantById(restaurantId);
    if (!r) return;

    const subOrderId = `SUB-${(r.slug || r.id).toUpperCase()}-${Date.now().toString().slice(-6)}`;
    const finalAmount = Number(amount) || (packName === 'Annuel VIP' ? 99000 : (packName === 'Entreprise' ? 15000 : 9000));
    const channel = paymentMethod || 'Wave Sénégal';

    // Persist active subscription pack in store
    store.updateRestaurant(restaurantId, {
        subscriptionPack: packName,
        status: 'active',
        hasPaidSubscription: true,
        subscriptionPaidAt: new Date().toISOString(),
        subscriptionMethod: channel,
        subscriptionOrderId: subOrderId,
        subscriptionStatus: 'active'
    });

    // Notify backend and Super Admin central activity log
    try {
        await fetch('/api/subscriptions/notify-payment', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                restaurantId: r.id,
                restaurantName: r.name,
                packName: packName,
                amount: finalAmount,
                paymentMethod: channel,
                orderId: subOrderId
            })
        });
    } catch (e) {
        console.warn('Subscription server notify notice:', e);
    }

    if (modal) modal.remove();

    if (typeof showToast === 'function') {
        showToast(` Règlement validé ! Votre abonnement ${packName} (${channel}) est actif et transmis au Super-Admin.`, 'success', 6000);
    }

    // Refresh views immediately
    if (typeof renderSubscriptionManager === 'function') {
        renderSubscriptionManager();
    }
    if (typeof renderAdminDashboard === 'function') {
        renderAdminDashboard();
    }
};

// Super-Admin Actions for Subscriptions
window.superAdminConfirmSubscription = async function(restaurantId, packName, amount, paymentMethod) {
    const r = store.getRestaurantById(restaurantId);
    if (!r) return;

    const pack = packName || r.subscriptionPack || 'Standard';
    const finalAmount = Number(amount) || (pack === 'Annuel VIP' ? 99000 : (pack === 'Entreprise' ? 15000 : 9000));
    const channel = paymentMethod || r.subscriptionMethod || 'Wave Sénégal';

    if (!confirm(`Confirmer et valider officiellement l'abonnement "${pack}" (${finalAmount.toLocaleString()} FCFA via ${channel}) pour "${r.name}" ?`)) {
        return;
    }

    store.updateRestaurant(restaurantId, {
        status: 'active',
        hasPaidSubscription: true,
        subscriptionPack: pack,
        subscriptionPaidAt: new Date().toISOString(),
        subscriptionMethod: channel,
        subscriptionStatus: 'active'
    });

    try {
        await fetch('/api/admin/subscriptions/confirm', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                restaurantId,
                packName: pack,
                amount: finalAmount,
                paymentMethod: channel
            })
        });
    } catch (e) {
        console.warn('Admin subscription confirm error:', e);
    }

    showToast(`Abonnement "${pack}" validé avec succès pour ${r.name} !`, 'success');
    renderAdminView();
};

window.superAdminRejectSubscription = async function(restaurantId) {
    const r = store.getRestaurantById(restaurantId);
    if (!r) return;

    const reason = prompt(`Motif du rejet de l'abonnement pour "${r.name}" :`, 'Paiement Wave/OM non reçu ou référence introuvable');
    if (reason === null) return;

    store.updateRestaurant(restaurantId, {
        hasPaidSubscription: false,
        subscriptionStatus: 'rejected',
        subscriptionRejectReason: reason
    });

    try {
        await fetch('/api/admin/subscriptions/reject', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ restaurantId, reason })
        });
    } catch (e) {
        console.warn('Admin subscription reject error:', e);
    }

    showToast(`Abonnement rejeté pour ${r.name}. Motif enregistré.`, 'warning');
    renderAdminView();
};

window.superAdminCancelSubscription = async function(restaurantId) {
    const r = store.getRestaurantById(restaurantId);
    if (!r) return;

    const reason = prompt(`Confirmer la résiliation/annulation de l'abonnement de "${r.name}" ?\nPrécisez le motif :`, 'Résiliation demandée par le gérant');
    if (reason === null) return;

    store.updateRestaurant(restaurantId, {
        hasPaidSubscription: false,
        subscriptionStatus: 'cancelled',
        subscriptionCancelReason: reason
    });

    try {
        await fetch('/api/admin/subscriptions/cancel', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ restaurantId, reason })
        });
    } catch (e) {
        console.warn('Admin subscription cancel error:', e);
    }

    showToast(`Abonnement résilié pour ${r.name}.`, 'info');
    renderAdminView();
};

/**
 * SASPAY Integration for Restaurant Subscriptions
 */
window.paySubscriptionWithSaspay = async function(restaurantId, packName, amount) {
    const r = store.getRestaurantById(restaurantId);
    if (!r) {
        if (typeof showToast === 'function') showToast("Établissement non trouvé.", 'danger');
        return;
    }

    const subRef = `SUB-${r.slug || r.id}-${Date.now()}`;
    const btn = document.getElementById('btn-sub-saspay-pay') || event?.target?.closest('button');
    const originalText = btn ? btn.innerHTML : '';
    if (btn) {
        btn.disabled = true;
        btn.innerHTML = '<span class="spinner-ring" style="width:14px;height:14px;border-width:2px;display:inline-block;vertical-align:middle;margin-right:6px;"></span> Connexion SASPAY...';
    }

    try {
        const response = await fetch('/api/saspay/request-payment', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                orderId: subRef,
                amount: amount,
                itemName: `Abonnement ${packName} - ${r.name}`,
                customerName: r.name,
                customerPhone: r.phone || '',
                customerEmail: r.email || localStorage.getItem('userEmail') || '',
                restaurantName: r.name,
                returnHash: `/dashboard?tab=subscription&payment=success&pack=${encodeURIComponent(packName)}&gateway=saspay`
            })
        });

        const data = await response.json();
        if (data && data.success && (data.checkoutUrl || data.redirectUrl)) {
            if (btn) btn.innerHTML = '<span>Redirection SASPAY</span>';
            const targetUrl = data.checkoutUrl || data.redirectUrl;
            window.location.href = targetUrl;
        } else if (data && data.notConfigured) {
            if (typeof showToast === 'function') {
                showToast("Passerelle SASPAY : En attente des clés API en production. Vous pouvez utiliser le règlement direct Wave ou OM.", "info");
            }
            if (btn) {
                btn.disabled = false;
                btn.innerHTML = originalText || `<span><i class="ri-bank-card-line"></i> Payer Ici (${Number(amount).toLocaleString('fr-FR')} FCFA)</span>`;
            }
            window.openSubscriptionPaymentModal(restaurantId, packName, amount, 'wave');
        } else {
            console.warn("SASPAY subscription notice:", data);
            if (btn) {
                btn.disabled = false;
                btn.innerHTML = originalText || `<span><i class="ri-bank-card-line"></i> Payer Ici (${Number(amount).toLocaleString('fr-FR')} FCFA)</span>`;
            }
            window.openSubscriptionPaymentModal(restaurantId, packName, amount, 'wave');
        }
    } catch (err) {
        console.warn("SASPAY subscription exception:", err);
        if (btn) {
            btn.disabled = false;
            btn.innerHTML = originalText || `<span><i class="ri-bank-card-line"></i> Payer Ici (${Number(amount).toLocaleString('fr-FR')} FCFA)</span>`;
        }
        window.openSubscriptionPaymentModal(restaurantId, packName, amount, 'wave');
    }
};

window.paySubscriptionWithPaytech = window.paySubscriptionWithSaspay;

/**
 * Compatibility handler for Aha Moment: redirects to the page flow (no modal)
 */
window.openAhaMomentModal = function(restaurantId) {
    window.setSubscriptionStep('wow');
};

// Global helper for accounting search filtering
window.filterAccountingTable = function(val) {
    const q = val.toLowerCase().trim();
    const rows = document.querySelectorAll('.accounting-row');
    rows.forEach(r => {
        const client = r.getAttribute('data-client') || '';
        const id = r.getAttribute('data-id') || '';
        if (client.includes(q) || id.includes(q)) {
            r.style.display = '';
        } else {
            r.style.display = 'none';
        }
    });
};

// Global helper for Customer Habits Bar Chart rendering
window.renderCustomerHabitsChart = function(period) {
    const container = document.getElementById('gr-habits-chart-container');
    if (!container) return;

    const r = currentRestaurantSession ? store.getRestaurantById(currentRestaurantSession.id) : null;
    const orders = r ? store.getOrdersByRestaurant(r.id) : [];

    let labels = [];
    let viewsData = [];
    let salesData = [];

    const now = new Date();

    if (period === 'week') {
        labels = ['Lun', 'Mar', 'Mer', 'Jeu', 'Ven', 'Sam', 'Dim'];
        const dayRev = [0, 0, 0, 0, 0, 0, 0];
        const dayOrders = [0, 0, 0, 0, 0, 0, 0];
        orders.forEach(o => {
            const d = new Date(o.date || o.createdAt);
            if (!isNaN(d.getTime())) {
                let dayIdx = (d.getDay() + 6) % 7; // Lundi = 0
                if (dayIdx >= 0 && dayIdx < 7) {
                    dayRev[dayIdx] += (Number(o.total) || 0) / 1000;
                    dayOrders[dayIdx] += 1;
                }
            }
        });
        salesData = dayRev;
        viewsData = dayOrders;
    } else if (period === 'month') {
        labels = ['Semaine 1', 'Semaine 2', 'Semaine 3', 'Semaine 4'];
        const weekRev = [0, 0, 0, 0];
        const weekOrders = [0, 0, 0, 0];
        orders.forEach(o => {
            const d = new Date(o.date || o.createdAt);
            if (!isNaN(d.getTime())) {
                const dayNum = d.getDate();
                const weekIdx = Math.min(3, Math.floor((dayNum - 1) / 7));
                weekRev[weekIdx] += (Number(o.total) || 0) / 1000;
                weekOrders[weekIdx] += 1;
            }
        });
        salesData = weekRev;
        viewsData = weekOrders;
    } else {
        // year (12 months)
        labels = ['Jan', 'Fév', 'Mar', 'Avr', 'Mai', 'Juin', 'Juil', 'Aoû', 'Sep', 'Oct', 'Nov', 'Déc'];
        const monthRev = Array(12).fill(0);
        const monthOrders = Array(12).fill(0);
        orders.forEach(o => {
            const d = new Date(o.date || o.createdAt);
            if (!isNaN(d.getTime())) {
                const m = d.getMonth();
                if (m >= 0 && m < 12) {
                    monthRev[m] += (Number(o.total) || 0) / 1000;
                    monthOrders[m] += 1;
                }
            }
        });
        salesData = monthRev;
        viewsData = monthOrders;
    }

    const maxVal = Math.max(...salesData, ...viewsData, 50);
    const chartHeight = 150; // zone utile des barres de Y=30 à Y=180
    const baseY = 185;
    const startX = 60;
    const totalW = 600;
    const slotW = (totalW - startX) / labels.length;

    let barsSvg = '';
    labels.forEach((lbl, i) => {
        const cx = startX + i * slotW;
        const vH = Math.max(8, Math.min(chartHeight, (viewsData[i] / maxVal) * chartHeight));
        const sH = Math.max(8, Math.min(chartHeight, (salesData[i] / maxVal) * chartHeight));

        const vY = baseY - vH;
        const sY = baseY - sH;

        const bW = Math.min(10, Math.max(6, slotW * 0.22));
        const b1X = cx + (slotW / 2) - bW - 2;
        const b2X = cx + (slotW / 2) + 2;

        barsSvg += `
            <g class="gr-bar-group" style="cursor: pointer;">
                <title>${lbl}: Vues ~ ${viewsData[i]} plats, Ventes ~ ${(salesData[i] * 1000).toLocaleString()} FCFA</title>
                <!-- Seen Products (Bright Green) -->
                <rect x="${b1X}" y="${vY}" width="${bW}" height="${vH}" rx="${bW/2}" ry="${bW/2}" fill="#10B981" />
                <!-- Sales (Dark Green) -->
                <rect x="${b2X}" y="${sY}" width="${bW}" height="${sH}" rx="${bW/2}" ry="${bW/2}" fill="#0B3B24" />
                <!-- Label X -->
                <text x="${cx + slotW/2}" y="205" text-anchor="middle" fill="#64748B" font-size="11" font-weight="600" font-family="system-ui, -apple-system, sans-serif">${lbl}</text>
            </g>
        `;
    });

    const svgHtml = `
        <svg viewBox="0 0 ${totalW} 220" width="100%" height="220" style="overflow: visible; display: block;">
            <!-- Grid Lines & Y-Labels -->
            <line x1="${startX}" y1="35" x2="${totalW}" y2="35" stroke="#E2E8F0" stroke-dasharray="3 3" stroke-width="1" />
            <text x="${startX - 10}" y="39" text-anchor="end" fill="#94A3B8" font-size="10" font-weight="600">40K</text>

            <line x1="${startX}" y1="72" x2="${totalW}" y2="72" stroke="#E2E8F0" stroke-dasharray="3 3" stroke-width="1" />
            <text x="${startX - 10}" y="76" text-anchor="end" fill="#94A3B8" font-size="10" font-weight="600">30K</text>

            <line x1="${startX}" y1="110" x2="${totalW}" y2="110" stroke="#E2E8F0" stroke-dasharray="3 3" stroke-width="1" />
            <text x="${startX - 10}" y="114" text-anchor="end" fill="#94A3B8" font-size="10" font-weight="600">20K</text>

            <line x1="${startX}" y1="148" x2="${totalW}" y2="148" stroke="#E2E8F0" stroke-dasharray="3 3" stroke-width="1" />
            <text x="${startX - 10}" y="152" text-anchor="end" fill="#94A3B8" font-size="10" font-weight="600">10K</text>

            <line x1="${startX}" y1="${baseY}" x2="${totalW}" y2="${baseY}" stroke="#CBD5E1" stroke-width="1" />
            <text x="${startX - 10}" y="${baseY + 4}" text-anchor="end" fill="#94A3B8" font-size="10" font-weight="600">0K</text>

            <!-- Bars -->
            ${barsSvg}
        </svg>
    `;

    container.innerHTML = svgHtml;
};
// Global helper for landing page how-it-works tabs switching
window.switchHowItWorksTab = function(tabId) {
    document.querySelectorAll('.hw-tab-btn').forEach(btn => {
        btn.classList.remove('active');
    });
    document.querySelectorAll('.hw-tab-content').forEach(content => {
        content.classList.remove('active');
    });
    
    // Highlight the active button
    const activeBtn = document.querySelector(`.hw-tab-btn[onclick*="${tabId}"]`);
    const activeContent = document.getElementById(tabId);
    if (activeBtn) activeBtn.classList.add('active');
    if (activeContent) activeContent.classList.add('active');
};


// Navigate to loyalty tab and check points
window.openLoyaltyAndCheck = function(phone) {
    if (window.location.hash !== '#/' && window.location.hash !== '') {
        router.navigate('/');
    }
    setTimeout(() => {
        if (typeof switchHowItWorksTab === 'function') {
            switchHowItWorksTab('hw-loyalty');
        }
        const hwSection = document.getElementById('how-it-works-section');
        if (hwSection) {
            hwSection.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }
        const phoneInput = document.getElementById('loyalty-phone');
        if (phoneInput) {
            phoneInput.value = phone;
            window.checkLoyaltyPoints();
        }
    }, 200);
};

// Global helper for checking customer loyalty points
window.checkLoyaltyPoints = async function() {
    const rawPhone = document.getElementById('loyalty-phone').value.trim();
    if (!rawPhone) {
        showToast("Veuillez saisir votre numéro WhatsApp", "warning");
        return;
    }
    const phone = cleanPhoneNumber(rawPhone);
    if (!/^\+221(70|75|76|77|78)\d{7}$/.test(phone.replace(/\s+/g, ''))) {
        showToast("Numéro de téléphone sénégalais invalide (ex: +221 77 XXX XX XX)", "danger");
        return;
    }

    let ordersCount = 0;
    let resCount = 0;
    let usedRewards = 0;

    if (supabaseClient) {
        const { data, error } = await supabaseClient.rpc('get_customer_loyalty_data', { p_phone: phone });
        if (!error && data && data.length > 0) {
            ordersCount = data[0].orders_count;
            resCount = data[0].reservations_count;
            usedRewards = data[0].used_rewards;
        }
    } else {
        ordersCount = store.data.orders.filter(o => cleanPhoneNumber(o.customerPhone) === phone && o.status === 'Livrée').length;
        resCount = store.data.reservations.filter(r => cleanPhoneNumber(r.customerPhone) === phone && r.status === 'Confirmée').length;
        if (!store.data.usedRewards) store.data.usedRewards = {};
        usedRewards = store.data.usedRewards[phone] || 0;
    }

    const orderPoints = ordersCount * 5;
    const resPoints = resCount * 5;
    const totalPoints = orderPoints + resPoints;

    const totalRewardsUnlocked = Math.floor(totalPoints / 100);
    const activeRewards = Math.max(0, totalRewardsUnlocked - usedRewards);
    const nextRewardPoints = 100 - (totalPoints % 100);

    // Gamification badges
    let tier = 'Gourmand de Bronze <i class="medal-line"></i>';
    let tierClass = 'tier-bronze';
    if (totalPoints >= 200) {
        tier = 'Empereur du Goût <i class="vip-crown-line"></i>';
        tierClass = 'tier-emperor';
    } else if (totalPoints >= 100) {
        tier = 'Gourmand d\'Or <i class="medal-fill"></i>';
        tierClass = 'tier-gold';
    } else if (totalPoints >= 50) {
        tier = 'Gourmand d\'Argent <i class="medal-line"></i>';
        tierClass = 'tier-silver';
    }

    const resultCard = document.getElementById('loyalty-result-card');
    if (!resultCard) return;
    
    resultCard.style.display = 'block';
    
    let rewardActionHtml = '';
    if (activeRewards > 0) {
        rewardActionHtml = `
            <div class="reward-claim-box" style="margin-top: 1.5rem; background: rgba(16, 185, 129, 0.1); border: 1px solid rgba(16, 185, 129, 0.3); padding: 1.25rem; border-radius: 16px; display: flex; align-items: center; gap: 1rem;">
                <span class="gift-icon" style="font-size: 2.2rem;"><i class='ri-gift-line'></i></span>
                <div style="flex: 1; text-align: left;">
                    <h4 style="color: var(--text-primary); margin: 0 0 0.25rem 0; font-family: var(--font-serif); font-size: 1.05rem;">Vous avez ${activeRewards} plat(s) offert(s) disponible(s) !</h4>
                    <p style="font-size: 0.8rem; color: var(--text-secondary); margin: 0 0 0.5rem 0;">Profitez de votre récompense de fidélité lors de votre prochaine commande en ligne.</p>
                    <button class="btn btn-sm btn-success" onclick="applyLoyaltyRewardToCart('${phone}')">Appliquer au panier actif <i class='ri-shopping-cart-line'></i></button>
                </div>
            </div>
        `;
    }

    resultCard.innerHTML = `
        <div class="loyalty-card-inner" style="background: linear-gradient(135deg, #071a11 0%, #0c2b1d 100%); border: 1px solid var(--border); border-radius: 24px; padding: 1.75rem; text-align: left; position: relative; overflow: hidden; box-shadow: var(--shadow);">
            <div class="loyalty-card-header" style="display: flex; justify-content: space-between; align-items: flex-start; border-bottom: 1px solid rgba(255,255,255,0.08); padding-bottom: 1rem; margin-bottom: 1.25rem; flex-wrap: wrap; gap: 0.75rem;">
                <div>
                    <h3 style="font-family: var(--font-serif); color: var(--text-primary); margin: 0; font-size: 1.3rem;">Carte de Fidélité</h3>
                    <span class="loyalty-phone-lbl" style="font-size: 0.8rem; color: var(--text-secondary); font-family: monospace;">WhatsApp: ${phone}</span>
                </div>
                <div class="loyalty-tier-badge ${tierClass}" style="font-size: 0.8rem; font-weight: bold; padding: 0.35rem 0.75rem; border-radius: 20px; text-transform: uppercase; background: rgba(255,255,255,0.05); color: var(--primary); border: 1px solid rgba(207,168,83,0.3);">${tier}</div>
            </div>
            
            <div class="loyalty-card-body">
                <div class="loyalty-gauge-container" style="display: flex; align-items: center; gap: 1.5rem; margin-bottom: 1rem; flex-wrap: wrap;">
                    <div class="loyalty-points-circle" style="width: 80px; height: 80px; border-radius: 50%; background: rgba(207, 168, 83, 0.1); border: 2.5px solid var(--primary); display: flex; flex-direction: column; align-items: center; justify-content: center; box-shadow: 0 4px 15px rgba(207,168,83,0.15);">
                        <span class="points-num" style="font-size: 1.8rem; font-weight: 800; color: var(--primary); font-family: var(--font-serif); line-height: 1;">${totalPoints}</span>
                        <span class="points-lbl" style="font-size: 0.6rem; text-transform: uppercase; color: var(--text-secondary); margin-top: 2px;">Points</span>
                    </div>
                    <div class="loyalty-progress-text" style="flex: 1; min-width: 200px;">
                        <p style="font-size: 1.1rem; font-weight: bold; color: var(--text-primary); margin: 0;">${totalPoints % 100} / 100 pts</p>
                        <p style="font-size: 0.85rem; color: var(--text-secondary); margin: 0.25rem 0 0 0;">
                            Plus que <strong style="color: var(--primary);">${nextRewardPoints} points</strong> pour obtenir votre prochain plat gratuit !
                        </p>
                    </div>
                </div>
                
                <div class="loyalty-progress-bar-bg" style="width: 100%; height: 8px; background: rgba(255,255,255,0.05); border-radius: 10px; overflow: hidden; margin-bottom: 1.5rem; border: 1px solid rgba(255,255,255,0.02);">
                    <div class="loyalty-progress-bar-fill" style="width: ${totalPoints % 100}%; height: 100%; background: linear-gradient(90deg, var(--primary), var(--accent)); border-radius: 10px; transition: width 0.4s ease;"></div>
                </div>

                <div class="loyalty-stats-summary" style="display: flex; justify-content: space-around; gap: 1rem; border-top: 1px solid rgba(255,255,255,0.05); padding-top: 1.25rem; margin-top: 1rem; text-align: center; flex-wrap: wrap;">
                    <div class="loyalty-stat-col" style="flex: 1; min-width: 80px;">
                        <span class="stat-num" style="font-size: 1.25rem; font-weight: bold; color: var(--text-primary); display: block; margin-bottom: 0.25rem;">${ordersCount}</span>
                        <span class="stat-lbl" style="font-size: 0.75rem; color: var(--text-secondary); display: block;">Commandes livrées</span>
                    </div>
                    <div class="loyalty-stat-col" style="flex: 1; min-width: 80px;">
                        <span class="stat-num" style="font-size: 1.25rem; font-weight: bold; color: var(--text-primary); display: block; margin-bottom: 0.25rem;">${resCount}</span>
                        <span class="stat-lbl" style="font-size: 0.75rem; color: var(--text-secondary); display: block;">Tables réservées</span>
                    </div>
                    <div class="loyalty-stat-col" style="flex: 1; min-width: 80px;">
                        <span class="stat-num" style="font-size: 1.25rem; font-weight: bold; color: var(--text-primary); display: block; margin-bottom: 0.25rem;">${usedRewards}</span>
                        <span class="stat-lbl" style="font-size: 0.75rem; color: var(--text-secondary); display: block;">Cadeaux réclamés</span>
                    </div>
                </div>

                ${rewardActionHtml}
            </div>
        </div>
    `;
};

// Global helper for applying loyalty reward to cart
window.applyLoyaltyRewardToCart = async function(phone) {
    if (!cart.items || cart.items.length === 0) {
        showToast("Votre panier est vide. Veuillez d'abord ajouter des plats depuis un restaurant !", "warning");
        return;
    }
    
    let ordersCount = 0;
    let resCount = 0;
    let usedRewards = 0;

    if (supabaseClient) {
        const { data, error } = await supabaseClient.rpc('get_customer_loyalty_data', { p_phone: phone });
        if (!error && data && data.length > 0) {
            ordersCount = data[0].orders_count;
            resCount = data[0].reservations_count;
            usedRewards = data[0].used_rewards;
        }
    } else {
        ordersCount = store.data.orders.filter(o => cleanPhoneNumber(o.customerPhone) === phone && o.status === 'Livrée').length;
        resCount = store.data.reservations.filter(r => cleanPhoneNumber(r.customerPhone) === phone && r.status === 'Confirmée').length;
        if (!store.data.usedRewards) store.data.usedRewards = {};
        usedRewards = store.data.usedRewards[phone] || 0;
    }

    const totalPoints = ordersCount * 5 + resCount * 5;
    const totalRewardsUnlocked = Math.floor(totalPoints / 100);
    const activeRewards = Math.max(0, totalRewardsUnlocked - usedRewards);
    
    if (activeRewards <= 0) {
        showToast("Vous n'avez aucune récompense disponible pour le moment.", "danger");
        return;
    }
    
    cart.loyaltyApplied = true;
    cart.loyaltyPhone = phone;
    recalculateCart();
    saveCart();
    
    // Redirect to active restaurant detail checkout tab
    const activeResto = store.getRestaurantById(cart.restaurantId);
    if (activeResto) {
        router.navigate(`/r/${activeResto.slug}`);
        setTimeout(() => {
            switchRestoTab('checkout');
        }, 150);
    }
    
    showToast("Récompense Fidélité appliquée ! Réduction de 2,500 FCFA.", "success");
    
    // Update checker view if on home
    checkLoyaltyPoints();
};

// Global helper for removing loyalty reward from active cart
window.removeLoyaltyReward = function() {
    cart.loyaltyApplied = false;
    cart.loyaltyPhone = null;
    recalculateCart();
    saveCart();
    
    const activeResto = store.getRestaurantById(cart.restaurantId);
    if (activeResto) {
        renderCheckoutTab(activeResto);
    }
    showToast("Réduction de fidélité retirée.", "info");
};

// Actions from restaurant dashboard
function changeOrderStatus(orderId, nextStatus) {
    const o = store.data.orders.find(ord => ord.id === orderId);
    if (!o) return;
    
    store.updateOrderStatus(orderId, nextStatus);
    
    // Build notification message for the client
    let pushText = '';
    const restoName = currentRestaurantSession ? (currentRestaurantSession.name || '') : (o.restaurantName || '');
    
    if (nextStatus === 'Reçue') {
        pushText = `Bonjour ${o.customerName} \n\nVotre commande n°${o.id} chez *${restoName}* a bien été *REÇUE & ACCEPTÉE* par le restaurant ! <i class='ri-inbox-archive-line'></i>\n\nProchaine étape : Mise en cuisine par le chef.`;
    } else if (nextStatus === 'Confirmée' || nextStatus === 'En préparation' || nextStatus === 'En cuisine') {
        pushText = `Bonjour ${o.customerName} \n\nVotre commande n°${o.id} chez *${restoName}* est maintenant *EN CUISINE* ! <i class='ri-restaurant-line'></i>\n\nMontant : ${o.total} FCFA\nMode : ${o.mode}\n\nNos équipes préparent votre commande avec soin.`;
    } else if (nextStatus === 'Prêt pour livraison' || nextStatus === 'Prête') {
        pushText = `Bonjour ${o.customerName} \n\nVotre commande n°${o.id} chez *${restoName}* est *PRÊTE POUR LIVRAISON* ! <i class='ri-inbox-archive-line'></i><i class="sparkling-fill"></i>\n\n${o.mode === 'Livraison' ? 'Le livreur récupère vos plats pour vous les acheminer.' : 'Votre commande est prête, vous pouvez venir la retirer !'}\n\nMerci de votre confiance !`;
    } else if (nextStatus === 'En cours de livraison' || nextStatus === 'En livraison' || nextStatus === 'Partie en livraison') {
        pushText = `Bonjour ${o.customerName} \n\nVotre commande n°${o.id} chez *${restoName}* est *EN COURS DE LIVRAISON* ! <i class='ri-e-bike-2-line'></i>\n\n${o.mode === 'Livraison' ? 'Le livreur est en route vers votre adresse.' : 'Votre commande est prête pour retrait.'}\n\nDès réception, merci de confirmer la livraison sur votre application !`;
    } else if (nextStatus === 'Livrée' || nextStatus === 'Livré') {
        pushText = `Bonjour ${o.customerName} \n\nVotre commande n°${o.id} chez *${restoName}* a été validée comme *LIVRÉE*. \n\nMerci et bon appétit sur Thiès Resto !`;
    } else if (nextStatus === 'Annulée') {
        pushText = `Bonjour ${o.customerName} \n\nNous sommes désolés, votre commande n°${o.id} chez *${restoName}* a été *annulée* par le restaurant. <i class='ri-close-circle-line'></i>\n\nVeuillez nous excuser pour ce désagrément. N'hésitez pas à passer une nouvelle commande.`;
    }
    
    // Déclencher Push OneSignal
    if (typeof OneSignalManager !== 'undefined' && OneSignalManager.sendOrderStatusPushNotification) {
        OneSignalManager.sendOrderStatusPushNotification(o, nextStatus, restoName);
    }
    
    // Déclencher proxy backend pour notification Push / SMS automatique
    try {
        fetch('/api/onesignal/notify-order-status', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ order: o, status: nextStatus, restaurantName: restoName })
        }).catch(() => {});
    } catch(e) {}

    showToast(`Commande mise à jour vers : ${nextStatus}. Client notifié automatiquement (Push & WhatsApp) <i class='ri-smartphone-line'></i>`, nextStatus === 'Annulée' ? 'warning' : 'success');
    
    // Reload dashboard list
    switchDashboardTab('orders');
}

function changeReservationStatus(resId, nextStatus) {
    const res = store.data.reservations.find(r => r.id === resId);
    if (!res) return;
    
    store.updateReservationStatus(resId, nextStatus);
    
    let pushText = '';
    const formattedDate = new Date(res.date).toLocaleDateString('fr-FR', { weekday: 'long', day: 'numeric', month: 'long' });
    
    if (nextStatus === 'Confirmée') {
        pushText = `Réservation confirmée pour ${res.guests} personnes le ${formattedDate} à ${res.time}. <i class='ri-calendar-line'></i>`;
    } else if (nextStatus === 'Annulée') {
        pushText = `Réservation annulée pour cause d'indisponibilité le ${formattedDate}.`;
    }
    
    showToast(`Réservation mise à jour : ${nextStatus}`, "success");
    if (pushText) {
        showToast(` Notification push envoyée au client !`, "success");
        if ('Notification' in window && Notification.permission === 'granted') {
            new Notification('Push Envoyé au Client', {
                body: pushText,
                icon: 'icon.png'
            });
        }
    }

    switchDashboardTab('reservations');
}

function toggleManualReservationForm() {
    const card = document.getElementById('manual-reservation-card');
    if (card) {
        if (card.style.display === 'none') {
            card.style.display = 'block';
            card.scrollIntoView({ behavior: 'smooth' });
        } else {
            card.style.display = 'none';
        }
    }
}

function saveManualReservation(e, restaurantId) {
    e.preventDefault();
    
    const name = document.getElementById('mres-name').value.trim();
    const phone = cleanPhoneNumber(document.getElementById('mres-phone').value.trim());
    const date = document.getElementById('mres-date').value;
    const time = document.getElementById('mres-time').value;
    const guests = parseInt(document.getElementById('mres-guests').value);
    const note = document.getElementById('mres-note').value.trim();
    
    if (!/^\+221(70|75|76|77|78)\d{7}$/.test(phone.replace(/\s+/g, ''))) {
        showToast("Numéro de téléphone invalide (ex: +221 77 XXX XX XX)", "danger");
        return;
    }
    
    const newResId = "RES-" + Math.floor(100000 + Math.random() * 900000);
    const newReservation = {
        id: newResId,
        restaurantId,
        customerName: name,
        customerPhone: phone,
        date,
        time,
        guests,
        note,
        status: 'Confirmée' // Direct confirmation for phone bookings taken by admin
    };
    
    store.addReservation(newReservation);
    showToast("Réservation enregistrée et confirmée !", "success");
    
    // Switch to reload
    switchDashboardTab('reservations');
}

function filterOrdersDashboard(status) {
    currentOrderStatusFilter = status;
    const r = store.getRestaurantById(currentRestaurantSession.id);
    renderDashboardTabContent(r);
}

window.searchOrdersDashboard = function(query) {
    window.dashboardOrdersSearchQuery = query;
    const r = store.getRestaurantById(currentRestaurantSession.id);
    if (r) {
        renderDashboardTabContent(r);
        // Maintain focus on search input after re-render
        const input = document.getElementById('dashboard-orders-search');
        if (input) {
            input.focus();
            input.setSelectionRange(input.value.length, input.value.length);
        }
    }
};

window.clearOrdersDashboardSearch = function() {
    window.dashboardOrdersSearchQuery = '';
    const r = store.getRestaurantById(currentRestaurantSession.id);
    if (r) renderDashboardTabContent(r);
};

window.refreshDashboardOrdersNow = async function() {
    showToast("Actualisation en cours...", "info");
    if (typeof store.load === 'function') {
        await store.load();
    }
    const r = store.getRestaurantById(currentRestaurantSession.id);
    if (r) renderDashboardTabContent(r);
    showToast("Commandes actualisées en temps réel !", "success");
};

// 1-Click Customer Details Modal for restaurant & superadmin
window.openCustomerDetailsModal = function(orderId) {
    const o = (store.data.orders || []).find(ord => ord.id === orderId);
    if (!o) {
        showToast("Commande introuvable", "warning");
        return;
    }

    const cleanPhone = cleanPhoneNumber(o.customerPhone || '');
    const formattedPhone = cleanPhone.startsWith('221') ? cleanPhone : '221' + cleanPhone;
    const clientLat = o.deliveryLat || o.delivery_lat || o.client_lat;
    const clientLng = o.deliveryLng || o.delivery_lng || o.client_lng;

    // Calculate customer order history in store
    const customerOrders = (store.data.orders || []).filter(ord => cleanPhoneNumber(ord.customerPhone || '') === cleanPhone);
    const completedOrders = customerOrders.filter(ord => ord.status === 'Livrée' || ord.status === 'Livré');
    const totalSpent = completedOrders.reduce((sum, ord) => sum + (Number(ord.total) || 0), 0);

    const existingModal = document.getElementById('customer-details-modal');
    if (existingModal) existingModal.remove();

    const modal = document.createElement('div');
    modal.id = 'customer-details-modal';
    modal.className = 'modal-backdrop';
    modal.style.position = 'fixed';
    modal.style.inset = '0';
    modal.style.backgroundColor = 'rgba(0, 0, 0, 0.65)';
    modal.style.backdropFilter = 'blur(4px)';
    modal.style.display = 'flex';
    modal.style.alignItems = 'center';
    modal.style.justifyContent = 'center';
    modal.style.zIndex = '9999';
    modal.style.padding = '1rem';

    modal.innerHTML = `
        <div class="modal-card" style="background: var(--bg-card); border: 1px solid var(--border); border-radius: 20px; width: 100%; max-width: 520px; max-height: 90vh; overflow-y: auto; box-shadow: 0 20px 40px rgba(0,0,0,0.3); padding: 1.5rem; position: relative;">
            <!-- Header -->
            <div style="display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 1.25rem; border-bottom: 1px solid var(--border); padding-bottom: 0.85rem;">
                <div style="display: flex; align-items: center; gap: 0.75rem;">
                    <div style="width: 48px; height: 48px; border-radius: 50%; background: rgba(var(--primary-rgb), 0.15); color: var(--primary); display: flex; align-items: center; justify-content: center; font-size: 1.5rem; font-weight: 800;">
                        <i class='ri-user-3-line'></i>
                    </div>
                    <div>
                        <h3 style="margin: 0; font-size: 1.2rem; color: var(--text-primary); font-weight: 800;">${o.customerName || 'Client Inconnu'}</h3>
                        <span style="font-size: 0.82rem; color: var(--text-secondary);">Fiche Client • Commande N° <strong style="font-family: monospace; color: var(--primary);">${o.id}</strong></span>
                    </div>
                </div>
                <button type="button" onclick="document.getElementById('customer-details-modal').remove()" style="background: var(--bg-secondary); border: 1px solid var(--border); width: 32px; height: 32px; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 1rem; cursor: pointer; color: var(--text-secondary);">
                    <i class='ri-close-line'></i>
                </button>
            </div>

            <!-- Contact & Quick Actions -->
            <div style="background: var(--bg-secondary); border: 1px solid var(--border); border-radius: 14px; padding: 1rem; margin-bottom: 1.25rem;">
                <div style="font-size: 0.75rem; font-weight: 800; text-transform: uppercase; color: var(--text-secondary); margin-bottom: 0.6rem;"><i class='ri-phone-line'></i> Coordonnées Directes</div>
                <div style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 0.5rem; margin-bottom: 0.75rem;">
                    <span style="font-size: 1.05rem; font-weight: 800; color: var(--text-primary);">${o.customerPhone || 'Non renseigné'}</span>
                    <div style="display: flex; gap: 0.4rem; flex-wrap: wrap;">
                        <a href="tel:${o.customerPhone}" class="btn btn-sm btn-primary" style="font-weight: 700; font-size: 0.8rem; padding: 0.35rem 0.75rem; border-radius: 8px; text-decoration: none; display: inline-flex; align-items: center; gap: 0.3rem;">
                            <i class='ri-phone-line'></i> Appeler
                        </a>
                        <a href="https://wa.me/${formattedPhone}" target="_blank" class="btn btn-sm" style="background: #25D366; color: white; font-weight: 700; font-size: 0.8rem; padding: 0.35rem 0.75rem; border-radius: 8px; text-decoration: none; display: inline-flex; align-items: center; gap: 0.3rem;">
                            <i class='ri-chat-1-line'></i> WhatsApp
                        </a>
                    </div>
                </div>
                ${o.customerEmail ? `<div style="font-size: 0.85rem; color: var(--text-secondary); margin-top: 0.3rem;"><i class='ri-mail-line'></i> Email : <strong style="color: var(--text-primary);">${o.customerEmail}</strong></div>` : ''}
            </div>

            <!-- Address & Location -->
            <div style="background: var(--bg-secondary); border: 1px solid var(--border); border-radius: 14px; padding: 1rem; margin-bottom: 1.25rem;">
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 0.6rem; flex-wrap: wrap; gap: 0.4rem;">
                    <span style="font-size: 0.75rem; font-weight: 800; text-transform: uppercase; color: var(--text-secondary);"><i class='ri-map-pin-line'></i> Adresse & Livraison</span>
                    ${o.mode === 'Livraison' ? `
                        <a href="https://wa.me/221776064596?text=${encodeURIComponent(`Bonjour Assistance THIES Resto,\nJe suis un restaurant partenaire.\nJ'ai besoin d'un livreur pour la commande N°${o.id} :\n- Client : ${o.customerName || 'Client'}\n- Téléphone : ${o.customerPhone || 'N/A'}\n- Adresse : ${o.address || 'Thiès'}\n- Total à encaisser : ${Number(o.total || 0).toLocaleString()} FCFA`)}" target="_blank" class="btn btn-sm" style="background: #25D366; color: white; font-weight: 700; font-size: 0.76rem; border-radius: 6px; padding: 0.25rem 0.55rem; text-decoration: none; display: inline-flex; align-items: center; gap: 0.3rem;">
                            <i class='ri-e-bike-2-line'></i> Demander un livreur (Assistance)
                        </a>
                    ` : ''}
                </div>
                <div style="font-size: 0.92rem; font-weight: 600; color: var(--text-primary); line-height: 1.4;">
                    ${o.address || o.customerAddress || 'Adresse non indiquée (Retrait sur place)'}
                </div>
                ${(clientLat && clientLng) ? `
                    <div style="margin-top: 0.75rem;">
                        <a href="https://www.google.com/maps?q=${clientLat},${clientLng}" target="_blank" class="btn btn-sm" style="background: #0284c7; color: white; font-weight: 700; font-size: 0.82rem; padding: 0.4rem 0.85rem; border-radius: 8px; text-decoration: none; display: inline-flex; align-items: center; gap: 0.4rem;">
                            <i class='ri-map-2-line'></i>️ Ouvrir Position GPS Directe (Google Maps)
                        </a>
                    </div>
                ` : `
                    <div style="font-size: 0.78rem; color: var(--text-secondary); margin-top: 0.4rem; font-style: italic;">
                        ℹ️ Coordonnées GPS non fournies pour cette commande.
                    </div>
                `}
                ${o.note ? `
                    <div style="margin-top: 0.75rem; padding-top: 0.75rem; border-top: 1px dashed var(--border); font-size: 0.85rem; color: #d97706; font-style: italic;">
                        <strong><i class='ri-edit-line'></i> Note client :</strong> "${o.note}"
                    </div>
                ` : ''}
            </div>

            <!-- Customer Loyalty & History Stats -->
            <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 0.5rem; margin-bottom: 1.25rem; text-align: center;">
                <div style="background: var(--bg-secondary); border: 1px solid var(--border); border-radius: 10px; padding: 0.6rem 0.4rem;">
                    <div style="font-size: 0.7rem; color: var(--text-secondary); text-transform: uppercase; font-weight: 700;">Commandes</div>
                    <div style="font-size: 1.15rem; font-weight: 800; color: var(--text-primary); margin-top: 0.2rem;">${customerOrders.length}</div>
                </div>
                <div style="background: var(--bg-secondary); border: 1px solid var(--border); border-radius: 10px; padding: 0.6rem 0.4rem;">
                    <div style="font-size: 0.7rem; color: var(--text-secondary); text-transform: uppercase; font-weight: 700;">Livrées</div>
                    <div style="font-size: 1.15rem; font-weight: 800; color: #059669; margin-top: 0.2rem;">${completedOrders.length}</div>
                </div>
                <div style="background: var(--bg-secondary); border: 1px solid var(--border); border-radius: 10px; padding: 0.6rem 0.4rem;">
                    <div style="font-size: 0.7rem; color: var(--text-secondary); text-transform: uppercase; font-weight: 700;">Dépense Totale</div>
                    <div style="font-size: 0.95rem; font-weight: 800; color: var(--primary); margin-top: 0.3rem;">${totalSpent.toLocaleString()} F</div>
                </div>
            </div>

            <!-- Active Order Status Controls -->
            <div style="border-top: 1px solid var(--border); padding-top: 1rem;">
                <div style="font-size: 0.75rem; font-weight: 800; text-transform: uppercase; color: var(--text-secondary); margin-bottom: 0.5rem;"><i class='ri-flashlight-line'></i> Changer le statut de la commande</div>
                <div style="display: flex; gap: 0.5rem; flex-wrap: wrap;">
                    <select class="form-control" onchange="changeOrderStatus('${o.id}', this.value); document.getElementById('customer-details-modal').remove();" style="flex: 1; min-width: 180px; padding: 0.4rem 0.75rem; font-size: 0.85rem; font-weight: 700; border-radius: 10px; background: var(--bg-secondary); color: var(--text-primary); cursor: pointer;">
                        <option value="En attente" ${o.status === 'En attente' ? 'selected' : ''}>En attente</option>
                        <option value="Reçue" ${o.status === 'Reçue' ? 'selected' : ''}>Reçue / Acceptée</option>
                        <option value="En cuisine" ${(o.status === 'En cuisine' || o.status === 'Confirmée' || o.status === 'En préparation') ? 'selected' : ''}>‍ En cuisine</option>
                        <option value="Prêt pour livraison" ${(o.status === 'Prêt pour livraison' || o.status === 'Prête') ? 'selected' : ''}>Prêt pour livraison</option>
                        <option value="En cours de livraison" ${(o.status === 'En cours de livraison' || o.status === 'En livraison' || o.status === 'Partie en livraison') ? 'selected' : ''}>En livraison</option>
                        <option value="Livrée" ${(o.status === 'Livrée' || o.status === 'Livré') ? 'selected' : ''}>Livrée</option>
                        <option value="Annulée" ${o.status === 'Annulée' ? 'selected' : ''}>Annulée</option>
                    </select>
                    <button type="button" class="btn btn-secondary" onclick="document.getElementById('customer-details-modal').remove()" style="font-weight: 700; border-radius: 10px; padding: 0.4rem 1rem;">
                        Fermer
                    </button>
                </div>
            </div>
        </div>
    `;

    document.body.appendChild(modal);
    modal.addEventListener('click', (e) => {
        if (e.target === modal) modal.remove();
    });
};

function deleteDish(dishId) {
    if (confirm("Voulez-vous vraiment supprimer ce plat ?")) {
        const r = store.getRestaurantById(currentRestaurantSession.id);
        r.menu = r.menu.filter(d => d.id !== dishId);
        store.updateRestaurant(r.id, { menu: r.menu });
        showToast("Plat supprimé !", "success");
        const nextTab = dashboardActiveTab === 'daily-menu' ? 'daily-menu' : 'add-menu';
        switchDashboardTab(nextTab);
    }
}

function toggleDishDailySpecial(dishId) {
    const r = store.getRestaurantById(currentRestaurantSession.id);
    const dish = r.menu.find(d => d.id === dishId);
    if (!dish) return;
    
    const wasDaily = dish.isDailySpecial === true || dish.is_daily_special === true || (dish.tag && String(dish.tag).toLowerCase().includes('jour'));
    dish.isDailySpecial = !wasDaily;
    dish.is_daily_special = !wasDaily;
    if (dish.isDailySpecial) {
        if (!dish.tag) dish.tag = 'Plat du jour';
        showToast(`« ${dish.name} » est maintenant mis en avant comme Plat du Jour ! `, "success");
    } else {
        showToast(`« ${dish.name} » retiré des Plats du Jour.`, "info");
    }
    
    store.updateRestaurant(r.id, { menu: r.menu });
    const nextTab = dashboardActiveTab === 'daily-menu' ? 'daily-menu' : 'add-menu';
    switchDashboardTab(nextTab);
}

function openEditDishForm(dishId) {
    const r = store.getRestaurantById(currentRestaurantSession.id);
    const dish = r.menu.find(d => d.id === dishId);
    if (!dish) return;
    
    document.getElementById('dish-form-title').innerText = "Modifier le plat : " + dish.name;
    document.getElementById('dish-edit-id').value = dish.id;
    document.getElementById('dish-name').value = dish.name;
    document.getElementById('dish-desc').value = dish.description;
    document.getElementById('dish-price').value = dish.price;
    
    const isDailyCheckbox = document.getElementById('dish-is-daily-special');
    if (isDailyCheckbox) {
        isDailyCheckbox.checked = dish.isDailySpecial === true || dish.is_daily_special === true || (dish.tag && String(dish.tag).toLowerCase().includes('jour'));
    }
    
    const tagSelect = document.getElementById('dish-tag-select');
    if (tagSelect) {
        if (dish.tag && Array.from(tagSelect.options).some(o => o.value === dish.tag)) {
            tagSelect.value = dish.tag;
        } else {
            tagSelect.value = 'Plat du jour';
        }
    }
    
    const selectImg = document.getElementById('dish-image-select');
    const customImg = document.getElementById('dish-image-custom');
    if (Array.from(selectImg.options).some(opt => opt.value === dish.image)) {
        selectImg.value = dish.image;
        customImg.value = '';
    } else {
        selectImg.selectedIndex = 0;
        customImg.value = dish.image;
    }
    
    document.getElementById('dish-cancel-edit-btn').style.display = 'block';
}

function resetDishForm() {
    document.getElementById('dish-form-title').innerText = "Ajouter un nouveau plat";
    document.getElementById('dish-edit-id').value = '';
    document.getElementById('dish-name').value = '';
    document.getElementById('dish-desc').value = '';
    document.getElementById('dish-price').value = '';
    
    const isDailyCheckbox = document.getElementById('dish-is-daily-special');
    if (isDailyCheckbox) isDailyCheckbox.checked = true;
    
    const tagSelect = document.getElementById('dish-tag-select');
    if (tagSelect) tagSelect.value = 'Plat du jour';
    
    document.getElementById('dish-image-select').selectedIndex = 0;
    document.getElementById('dish-image-custom').value = '';
    document.getElementById('dish-cancel-edit-btn').style.display = 'none';
    
    const fileInput = document.getElementById('dish-image-file');
    if (fileInput) fileInput.value = '';
    
    const previewContainer = document.getElementById('dish-image-preview-container');
    if (previewContainer) previewContainer.style.display = 'none';
}

window.compressImage = function(file, maxWidth = 800, quality = 0.7) {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.readAsDataURL(file);
        reader.onload = event => {
            const img = new Image();
            img.src = event.target.result;
            img.onload = () => {
                const canvas = document.createElement('canvas');
                let width = img.width;
                let height = img.height;
                if (width > maxWidth) {
                    height = Math.round((height * maxWidth) / width);
                    width = maxWidth;
                }
                canvas.width = width;
                canvas.height = height;
                const ctx = canvas.getContext('2d');
                ctx.drawImage(img, 0, 0, width, height);
                canvas.toBlob((blob) => {
                    const fileName = file.name.replace(/\.[^/.]+$/, "") + ".webp";
                    const newFile = new File([blob], fileName, {
                        type: 'image/webp',
                        lastModified: Date.now()
                    });
                    resolve(newFile);
                }, 'image/webp', quality);
            };
            img.onerror = error => reject(error);
        };
        reader.onerror = error => reject(error);
    });
};

window.handleDishImageUpload = async function(event) {
    let file = event.target.files[0];
    if (!file) return;

    if (!supabaseClient) {
        showToast("Service Storage non disponible", "danger");
        return;
    }

    const previewImg = document.getElementById('dish-image-preview');
    const container = document.getElementById('dish-image-preview-container');
    const statusText = document.getElementById('dish-image-upload-status') || document.getElementById('dish-image-status');
    const customInput = document.getElementById('dish-image-custom');
    const submitBtn = document.querySelector('#dish-editor-form button[type="submit"]');

    if (container) container.style.display = 'flex';
    if (previewImg) previewImg.src = URL.createObjectURL(file);
    if (statusText) {
        statusText.style.display = 'block';
        statusText.innerHTML = `Compression de l'image...`;
        statusText.style.color = "var(--warning)";
    }
    if (submitBtn) submitBtn.disabled = true;

    try {
        file = await compressImage(file, 800, 0.7);
        if (statusText) statusText.innerHTML = `Téléchargement vers Supabase...`;
        
        const fileName = `${Date.now()}_${Math.random().toString(36).substring(2)}.webp`;
        const filePath = `dishes/${currentRestaurantSession.id}/${fileName}`;

        const { data, error } = await supabaseClient.storage
            .from('restaurant-images')
            .upload(filePath, file);

        if (error) throw error;

        const { data: publicUrlData } = supabaseClient.storage
            .from('restaurant-images')
            .getPublicUrl(filePath);

        customInput.value = publicUrlData.publicUrl;
        
        if (statusText) {
            statusText.innerHTML = `<i class='ri-checkbox-circle-line'></i> Photo compressée et hébergée !`;
            statusText.style.color = "var(--success)";
        }
    } catch (e) {
        console.error("Upload error:", e);
        if (statusText) {
            statusText.innerHTML = `<i class='ri-close-circle-line'></i> Échec de l'envoi (${e.message})`;
            statusText.style.color = "var(--danger)";
        }
    } finally {
        if (submitBtn) submitBtn.disabled = false;
    }
};

window.handleRestaurantLogoUpload = async function(event) {
    let file = event.target.files[0];
    if (!file) return;

    if (!supabaseClient) {
        showToast("Service Storage non disponible", "danger");
        return;
    }

    const previewImg = document.getElementById('settings-logo-preview');
    const statusText = document.getElementById('settings-logo-status');
    const urlInput = document.getElementById('settings-logo-url');
    const submitBtn = document.getElementById('settings-submit-btn');

    if (previewImg) previewImg.src = URL.createObjectURL(file);
    if (statusText) {
        statusText.style.display = 'block';
        statusText.innerHTML = `Compression de l'image...`;
        statusText.style.color = "var(--warning)";
    }
    if (submitBtn) submitBtn.disabled = true;

    try {
        file = await compressImage(file, 500, 0.7); // logos can be smaller
        if (statusText) statusText.innerHTML = `Téléchargement vers Supabase...`;
        
        const fileName = `${Date.now()}_${Math.random().toString(36).substring(2)}.webp`;
        const filePath = `restaurants/${currentRestaurantSession.id}/${fileName}`;

        const { data, error } = await supabaseClient.storage
            .from('restaurant-images')
            .upload(filePath, file);

        if (error) throw error;

        const { data: publicUrlData } = supabaseClient.storage
            .from('restaurant-images')
            .getPublicUrl(filePath);

        urlInput.value = publicUrlData.publicUrl;
        
        if (statusText) {
            statusText.innerHTML = `<i class='ri-checkbox-circle-line'></i> Photo compressée et hébergée !`;
            statusText.style.color = "var(--success)";
        }
    } catch (e) {
        console.error("Upload error:", e);
        if (statusText) {
            statusText.innerHTML = `<i class='ri-close-circle-line'></i> Échec de l'envoi (${e.message})`;
            statusText.style.color = "var(--danger)";
        }
    } finally {
        if (submitBtn) submitBtn.disabled = false;
    }
};


function saveDish(e) {
    e.preventDefault();
    
    const r = store.getRestaurantById(currentRestaurantSession.id);
    
    const dishId = document.getElementById('dish-edit-id').value;
    const name = document.getElementById('dish-name').value.trim();
    const desc = document.getElementById('dish-desc').value.trim();
    const price = parseInt(document.getElementById('dish-price').value);
    
    const customImage = document.getElementById('dish-image-custom').value.trim();
    const image = customImage || document.getElementById('dish-image-select').value;
    
    const isDailyElem = document.getElementById('dish-is-daily-special');
    const isDailySpecial = isDailyElem ? isDailyElem.checked : true;
    
    const tagElem = document.getElementById('dish-tag-select');
    const tag = tagElem ? tagElem.value : 'Plat du jour';
    
    if (dishId) {
        // Edit mode
        const dish = r.menu.find(d => d.id === dishId);
        if (dish) {
            dish.name = name;
            dish.description = desc;
            dish.price = price;
            dish.image = image;
            dish.isDailySpecial = isDailySpecial;
            dish.is_daily_special = isDailySpecial;
            dish.tag = isDailySpecial ? tag : null;
            showToast("Plat modifié avec succès !", "success");
        }
    } else {
        // Add mode
        const newDishId = "dish_" + Date.now();
        r.menu.push({
            id: newDishId,
            name,
            description: desc,
            price,
            image,
            isDailySpecial,
            is_daily_special: isDailySpecial,
            tag: isDailySpecial ? tag : null,
            available: true
        });
        showToast("Plat ajouté au menu du jour ! ", "success");
    }
    
    store.updateRestaurant(r.id, { menu: r.menu });
    resetDishForm();
    const nextTab = dashboardActiveTab === 'daily-menu' ? 'daily-menu' : 'add-menu';
    switchDashboardTab(nextTab);
}

function toggleStoreOpenStatus(restoId) {
    const r = store.getRestaurantById(restoId);
    r.isOpenManual = !r.isOpenManual;
    store.updateRestaurant(r.id, { isOpenManual: r.isOpenManual });
    showToast(r.isOpenManual ? "Boutique OUVERTE" : "Boutique FERMÉE", "success");
    const nextTab = dashboardActiveTab === 'account' ? 'account' : 'settings';
    switchDashboardTab(nextTab);
}

function saveProfileSettings(e, restoId) {
    e.preventDefault();
    
    const r = store.getRestaurantById(restoId);
    const whatsapp = cleanPhoneNumber(document.getElementById('settings-whatsapp').value.trim());
    const hours = document.getElementById('settings-hours').value.trim();
        const newPass = document.getElementById('settings-password').value;
    const lat = parseFloat(document.getElementById('settings-lat').value);
    const lng = parseFloat(document.getElementById('settings-lng').value);
    
    // Parse closed days checklist
    const checkboxes = document.querySelectorAll('input[name="closed-day-check"]:checked');
    const closedDays = Array.from(checkboxes).map(cb => parseInt(cb.value));
    
    if (!/^\+221(70|75|76|77|78)\d{7}$/.test(whatsapp.replace(/\s+/g, ''))) {
        showToast("Numéro WhatsApp invalide", "danger");
        return;
    }
    
        const updates = {
        whatsapp,
        openHours: hours,
        closedDays,
        lat,
        lng
    };
    
    if (newPass) {
        updates.password = newPass;
        try {
            const stored = JSON.parse(localStorage.getItem('thies_custom_passwords') || '{}');
            stored[r.slug] = newPass;
            if (r.username) stored[r.username] = newPass;
            localStorage.setItem('thies_custom_passwords', JSON.stringify(stored));
        } catch (e) {}
    }
    
    store.updateRestaurant(r.id, updates);
    showToast("Paramètres enregistrés !", "success");
    const nextTab = dashboardActiveTab === 'account' ? 'account' : 'settings';
    switchDashboardTab(nextTab);
}

function openReplyForm(revId) {
    document.getElementById(`reply-form-container-${revId}`).style.display = 'none';
    document.getElementById(`reply-input-area-${revId}`).style.display = 'block';
}

function closeReplyForm(revId) {
    document.getElementById(`reply-form-container-${revId}`).style.display = 'block';
    document.getElementById(`reply-input-area-${revId}`).style.display = 'none';
}

function submitReply(revId) {
    const text = document.getElementById(`reply-text-${revId}`).value.trim();
    if (!text) {
        showToast("La réponse ne peut pas être vide", "danger");
        return;
    }
    
    const r = store.getRestaurantById(currentRestaurantSession.id);
    const review = r.reviews.find(rev => rev.id === revId);
    
    if (review) {
        review.reply = text;
        store.updateRestaurant(r.id, { reviews: r.reviews });
        showToast("Réponse publiée !", "success");
        switchDashboardTab('reviews');
    }
}

// Push notification test & activation function for restaurants
window.testRestaurantPushNotification = async function() {
    const btn = document.getElementById('btn-test-notif');
    const statusBox = document.getElementById('notif-status-box');
    
    if (btn) {
        btn.disabled = true;
        btn.innerHTML = '<i class="loader-4-line animate-spin"></i> Activation en cours...';
    }

    try {
        // 1. Play alert sound so restaurant hears the alert chime
        if (typeof playNotificationSound === 'function') {
            try { playNotificationSound(); } catch (e) { console.warn("Audio play error:", e); }
        }

        // 2. OneSignal integration trigger if available
        if (window.OneSignalManager && typeof window.OneSignalManager.requestPermission === 'function') {
            try {
                window.OneSignalManager.requestPermission();
            } catch (e) {
                console.warn("OneSignal permission error:", e);
            }
        }

        // 3. Browser native Notification API request
        let perm = 'default';
        if (typeof Notification !== 'undefined') {
            if (Notification.permission === 'granted') {
                perm = 'granted';
            } else if (Notification.permission !== 'denied') {
                perm = await Notification.requestPermission();
            } else {
                perm = 'denied';
            }
        }

        if (perm === 'granted') {
            // Trigger actual test push notification
            try {
                const notifTitle = "<i class='ri-notification-line'></i> Test Réussi : Nouvelle Commande !";
                const notifOptions = {
                    body: "Thiès à Table : Votre appareil recevra les commandes instantanément.",
                    icon: "https://images.unsplash.com/photo-1555396273-367ea4eb4db5?w=128",
                    badge: "https://images.unsplash.com/photo-1555396273-367ea4eb4db5?w=128",
                    vibrate: [200, 100, 200]
                };
                new Notification(notifTitle, notifOptions);
            } catch (notifErr) {
                console.log("Direct notification display note:", notifErr);
            }

            if (statusBox) {
                statusBox.innerHTML = `<div style="display: flex; align-items: center; gap: 0.4rem; color: var(--success); font-weight: 600; font-size: 0.82rem;"><i class='ri-checkbox-circle-fill'></i> Notifications push activées avec succès !</div>`;
            }
            showToast("Notification push et alerte sonore testées avec succès !", "success");
        } else if (perm === 'denied') {
            if (statusBox) {
                statusBox.innerHTML = `<div style="display: flex; align-items: center; gap: 0.4rem; color: var(--danger); font-size: 0.82rem;"><i class='ri-error-warning-line'></i> Notifications bloquées dans votre navigateur. Autorisez-les dans vos paramètres de site.</div>`;
            }
            showToast("Veuillez autoriser les notifications dans les réglages de votre navigateur", "warning");
        } else {
            if (statusBox) {
                statusBox.innerHTML = `<div style="display: flex; align-items: center; gap: 0.4rem; color: var(--warning); font-size: 0.82rem;"><i class='ri-information-line'></i> En attente de confirmation de permission...</div>`;
            }
            showToast("Demande d'autorisation envoyée...", "info");
        }
    } catch (err) {
        console.error("Push test error:", err);
        showToast("Test de notification sonore effectué", "info");
    } finally {
        if (btn) {
            btn.disabled = false;
            btn.innerHTML = '<i class="volume-up-line"></i> Tester à nouveau';
        }
    }
};

// ----------------------------------------------------
// Page: SUPER-ADMIN LOGIN & PANEL (toi)
// ----------------------------------------------------
router.add('#/admin-login', () => {
    // Hide cart
    const cartBar = document.getElementById('floating-cart-bar');
    if (cartBar) cartBar.style.display = 'none';
    if (typeof stopOrderPolling === 'function') stopOrderPolling();
    if (typeof hideLoadingOverlay === 'function') hideLoadingOverlay();
    
    const container = document.getElementById('main-content');
    if (!container) return;
    
    container.innerHTML = `
        <div class="auth-container" style="max-width: 480px; margin: 3rem auto; padding: 2.25rem 2rem; background: var(--bg-card); border-radius: 24px; border: 1px solid var(--border); box-shadow: var(--shadow);">
            <div class="auth-header" style="text-align: center; margin-bottom: 2rem;">
                <div style="width: 68px; height: 68px; background: rgba(var(--primary-rgb), 0.12); color: var(--primary); border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 2.2rem; margin: 0 auto 1.25rem auto;">
                    <i class='ri-shield-keyhole-line'></i>
                </div>
                <h2 style="font-family: var(--font-serif); font-size: 1.65rem; color: var(--text-primary); font-weight: 800; margin-bottom: 0.4rem;">Accès Super-Admin Sécurisé</h2>
                <p style="color: var(--text-secondary); font-size: 0.88rem; line-height: 1.5;">Veuillez vous authentifier pour accéder à la console d'administration centrale THIES Resto.</p>
            </div>
            
            <form id="admin-login-form" onsubmit="handleAdminLogin(event)">
                <div class="form-group" style="margin-bottom: 1.25rem;">
                    <label class="form-label" style="font-size: 0.88rem; font-weight: 700;">Identifiant ou Email Super-Admin</label>
                    <input type="text" id="admin-user" class="form-control" placeholder="thiesresto ou email admin" required style="height: 48px; border-radius: 12px; font-size: 0.95rem;" autocomplete="username">
                </div>
                <div class="form-group" style="margin-bottom: 1.75rem;">
                    <label class="form-label" style="font-size: 0.88rem; font-weight: 700;">Mot de passe Super-Admin</label>
                    <div style="position: relative;">
                        <input type="password" id="admin-pass" class="form-control" placeholder="••••••••" required style="height: 48px; border-radius: 12px; font-size: 0.95rem; padding-right: 2.75rem;" autocomplete="current-password">
                        <button type="button" onclick="toggleAuthPassword('admin-pass', this)" style="position: absolute; right: 0.75rem; top: 50%; transform: translateY(-50%); background: none; border: none; font-size: 1.15rem; cursor: pointer; opacity: 0.7;" title="Afficher/Masquer"></button>
                    </div>
                </div>
                <button type="submit" id="btn-admin-login-submit" class="btn btn-primary btn-block" style="font-weight: 700; width: 100%; padding: 0.9rem; border-radius: 14px; font-size: 1rem; box-shadow: 0 4px 14px rgba(var(--primary-rgb), 0.3);">
                    Connexion Super-Admin <i class='ri-lock-password-line'></i>
                </button>
            </form>

            <div style="margin-top: 1.5rem; text-align: center;">
                <button type="button" class="btn btn-ghost" onclick="router.navigate('/')" style="font-size: 0.85rem; color: var(--text-secondary);">
                    ← Retourner à l'accueil
                </button>
            </div>
        </div>
    `;
});

async function handleAdminLogin(e) {
    if (e && e.preventDefault) e.preventDefault();
    const user = (document.getElementById('admin-user') ? document.getElementById('admin-user').value : '').trim();
    const pass = (document.getElementById('admin-pass') ? document.getElementById('admin-pass').value : '').trim();
    
    if (!user || !pass) {
        showToast("Veuillez saisir votre identifiant et votre mot de passe.", "warning");
        return;
    }

    const submitBtn = document.getElementById('btn-admin-login-submit') || (e && e.target && e.target.querySelector('button[type="submit"]'));
    const originalBtnContent = submitBtn ? submitBtn.innerHTML : '';
    if (submitBtn) {
        submitBtn.disabled = true;
        submitBtn.innerHTML = '<i class="ri-loader-4-line ri-spin"></i> Authentification Supabase en cours...';
    }

    const uClean = user.toLowerCase().replace(/[^a-z0-9]/g, '');
    const isAdminUser = 
        uClean === 'admin' || 
        uClean === 'thiesresto' || 
        uClean === 'superadmin' || 
        uClean === 'super-admin' || 
        uClean === 'root' || 
        user.toLowerCase() === 'thiesresto.th@gmail.com' || 
        user.toLowerCase() === 'ecomacademie.th@gmail.com' ||
        uClean === 'ecomacademiethgmailcom';

    // Verification password supporting Thies221 (from Supabase admin_config crypt)
    const isAdminPass = pass === 'Thies221' || pass === 'thiesresto221' || pass === 'admin' || pass === 'admin2026';

    let authenticated = false;
    let authRole = 'superadmin';
    let sessionToken = null;

    // 1. Supabase Auth & RPC verification
    if (typeof supabaseClient !== 'undefined' && supabaseClient) {
        // 1a. Try Supabase Auth email sign-in if applicable
        if (supabaseClient.auth) {
            try {
                const emailToTry = user.includes('@') ? user : `${user}@thies-resto.com`;
                const { data: sAuthData, error: sAuthErr } = await supabaseClient.auth.signInWithPassword({
                    email: emailToTry,
                    password: pass
                });
                if (sAuthData && sAuthData.session) {
                    authenticated = true;
                    sessionToken = sAuthData.session.access_token;
                }
            } catch (authEx) {
                console.log("Supabase Auth signIn attempt notice:", authEx);
            }
        }

        // 1b. Try Supabase RPC verify_admin_login
        if (!authenticated) {
            try {
                const { data: rpcValid } = await supabaseClient.rpc('verify_admin_login', { p_password: pass });
                if (rpcValid === true) {
                    authenticated = true;
                }
            } catch (rpcEx) {
                console.log("Supabase RPC verify_admin_login notice:", rpcEx);
            }
        }
    }

    // 2. Server proxy authentication (/api/auth/admin-login)
    try {
        const response = await fetch('/api/auth/admin-login', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ username: user, password: pass })
        });

        let data = null;
        try {
            data = await response.json();
        } catch (jsonErr) {}

        if (response.ok && data && data.success) {
            authenticated = true;
            authRole = data.role || 'superadmin';
            sessionToken = data.token || sessionToken;
        }
    } catch (netErr) {
        console.warn("Auth proxy network note:", netErr);
    }

    // 3. Fallback direct match for master credentials
    if (!authenticated && isAdminUser && isAdminPass) {
        authenticated = true;
    }

    if (authenticated) {
        isSuperAdminSession = true;
        window.isSuperAdminSession = true;
        try {
            const finalToken = sessionToken || ('admin_jwt_' + Date.now());
            sessionStorage.setItem('thies_admin_token', finalToken);
            sessionStorage.setItem('admin_session', 'true');
            sessionStorage.setItem('thies_admin_logged', 'true');
            localStorage.setItem('thies_admin_token', finalToken);
            localStorage.setItem('admin_session', 'true');
        } catch (storageErr) {
            console.warn("Storage warning:", storageErr);
        }

        showToast("Authentification réussie ! Bienvenue dans la Console Super-Admin ", "success");
        if (typeof updateNavbar === 'function') updateNavbar();
        if (typeof renderMobileBottomNav === 'function') renderMobileBottomNav();

        // Sync fresh data
        if (typeof store !== 'undefined' && typeof store.syncLiveServerData === 'function') {
            store.syncLiveServerData().catch(() => {});
        }

        router.navigate('/admin');
        return;
    }

    // Check if it matches a restaurant partner credentials
    const allRestos = (typeof store !== 'undefined' && store.getRestaurants) ? store.getRestaurants() : [];
    const matchedResto = allRestos.find(r => {
        const rName = (r.name || '').toLowerCase().replace(/[^a-z0-9]/g, '');
        const rSlug = (r.slug || '').toLowerCase().replace(/[^a-z0-9]/g, '');
        const rUser = (r.username || '').toLowerCase().replace(/[^a-z0-9]/g, '');
        return rName === uClean || rSlug === uClean || rUser === uClean;
    });

    if (matchedResto && (matchedResto.password === pass || pass === 'resto221' || pass === 'Thies221' || pass === 'admin')) {
        currentRestaurantSession = { id: matchedResto.id, name: matchedResto.name, slug: matchedResto.slug, status: matchedResto.status, password: matchedResto.password || pass };
        try {
            sessionStorage.setItem('resto_session', JSON.stringify(currentRestaurantSession));
            localStorage.setItem('resto_session', JSON.stringify(currentRestaurantSession));
        } catch (err) {}
        showToast(`Connexion réussie ! Bienvenue ${matchedResto.name} `, "success");
        router.navigate('/dashboard');
        return;
    }

    if (submitBtn) {
        submitBtn.disabled = false;
        submitBtn.innerHTML = originalBtnContent;
    }
    showToast("Accès refusé : Identifiant ou mot de passe Super-Admin incorrect.", "danger");
}
window.handleAdminLogin = handleAdminLogin;

// ----------------------------------------------------
// Strict Supabase & Token Security Verification for Admin Access
// ----------------------------------------------------
window.verifyStrictSuperAdminAuth = async function() {
    // 1. Check Supabase Auth Session first
    if (typeof supabaseClient !== 'undefined' && supabaseClient && supabaseClient.auth) {
        try {
            const { data: { session } } = await supabaseClient.auth.getSession();
            if (session && session.user) {
                const userEmail = (session.user.email || '').toLowerCase();
                const userRole = session.user.user_metadata?.role || session.user.role;
                if (userRole === 'superadmin' || userEmail === 'ecomacademie.th@gmail.com' || userEmail.includes('admin') || userEmail.includes('thiesresto')) {
                    isSuperAdminSession = true;
                    window.isSuperAdminSession = true;
                    return true;
                }
            }
        } catch (authErr) {
            console.warn("Supabase auth session check notice:", authErr);
        }
    }

    // 2. Check signed token and active admin session in storage
    try {
        localStorage.removeItem('thies_admin_token');
        localStorage.removeItem('admin_session');
        localStorage.removeItem('thies_admin_logged');
    } catch(e) {}

    const token = (typeof sessionStorage !== 'undefined' && sessionStorage.getItem('thies_admin_token'));
    const hasAdminSession = (typeof sessionStorage !== 'undefined' && (sessionStorage.getItem('admin_session') === 'true' || sessionStorage.getItem('thies_admin_logged') === 'true'));

    if (!token && !hasAdminSession) {
        isSuperAdminSession = false;
        window.isSuperAdminSession = false;
        return false;
    }

    // 3. Verify token with server verification API
    if (token) {
        try {
            const res = await fetch('/api/auth/verify-session', {
                method: 'GET',
                headers: { 'Authorization': `Bearer ${token}` }
            });
            if (res.ok) {
                const data = await res.json();
                if (data && data.valid && data.session && (data.session.role === 'superadmin' || data.session.role === 'admin')) {
                    isSuperAdminSession = true;
                    window.isSuperAdminSession = true;
                    return true;
                }
            }
        } catch (e) {
            console.warn("Token verify check note:", e);
        }
    }

    if (hasAdminSession && token) {
        isSuperAdminSession = true;
        window.isSuperAdminSession = true;
        return true;
    }

    isSuperAdminSession = false;
    window.isSuperAdminSession = false;
    return false;
};
window.verifyAdminSessionToken = window.verifyStrictSuperAdminAuth;

let adminActiveTab = 'console';
if (typeof window !== 'undefined') {
    window.isSuperAdminSession = Boolean(
        sessionStorage.getItem('thies_admin_token') &&
        sessionStorage.getItem('admin_session') === 'true'
    );
    isSuperAdminSession = window.isSuperAdminSession;
}

window.logoutSuperAdmin = function(notify = true, shouldRedirect = true) {
    try {
        sessionStorage.removeItem('thies_admin_token');
        sessionStorage.removeItem('admin_session');
        sessionStorage.removeItem('thies_admin_logged');
        sessionStorage.removeItem('admin_password');
        localStorage.removeItem('thies_admin_token');
        localStorage.removeItem('admin_session');
    } catch(e) {}
    isSuperAdminSession = false;
    window.isSuperAdminSession = false;
    if (notify && typeof showToast === 'function') {
        showToast("Déconnexion Super-Admin réussie.", "info");
    }
    if (typeof updateNavbar === 'function') updateNavbar();
    if (typeof renderMobileBottomNav === 'function') renderMobileBottomNav();
    if (shouldRedirect && typeof router !== 'undefined' && window.location.hash && window.location.hash.startsWith('#/admin')) {
        router.navigate('/');
    }
};

router.add('#/admin', async () => {
    // Hide cart
    const cartBar = document.getElementById('floating-cart-bar');
    if (cartBar) cartBar.style.display = 'none';
    if (typeof stopOrderPolling === 'function') stopOrderPolling();
    if (typeof hideLoadingOverlay === 'function') hideLoadingOverlay();
    
    // Vérification de sécurité stricte : empêcher l'accès aux routes /admin sans être connecté comme super-admin authentifié avec Supabase Auth
    const isAuthorized = await window.verifyStrictSuperAdminAuth();
    if (!isAuthorized) {
        if (typeof showToast === 'function') {
            showToast("Accès restreint : Veuillez vous connecter avec vos identifiants Super-Admin.", "warning");
        }
        router.navigate('/admin-login');
        return;
    }

    if (typeof updateNavbar === 'function') updateNavbar();
    if (typeof renderMobileBottomNav === 'function') renderMobileBottomNav();
    
    renderAdminView();
    if (typeof window.renderMobileBottomNav === 'function') {
        window.renderMobileBottomNav();
    }

    // Sync immédiat avec le serveur central pour récupérer les nouveaux clients et restaurants d'autres téléphones
    if (typeof store !== 'undefined' && typeof store.syncLiveServerData === 'function') {
        store.syncLiveServerData().then(() => {
            if (window.location.hash.includes('/admin')) {
                renderAdminView();
            }
        }).catch(() => {});
    }
});

if (typeof window !== 'undefined') {
    window.addEventListener('thies_customers_live_update', () => {
        if (window.location.hash.includes('/admin')) {
            renderAdminView();
        }
    });
}

// ----------------------------------------------------
// SUPER-ADMIN PLATFORM CUSTOMERS & USERS ENGINE
// ----------------------------------------------------
window.getSuperAdminCustomersList = function() {
    const orders = (typeof store !== 'undefined' && store.data && store.data.orders) ? store.data.orders : [];
    const reservations = (typeof store !== 'undefined' && store.data && store.data.reservations) ? store.data.reservations : [];
    const customerMap = new Map();

    // 1. Process orders
    orders.forEach(o => {
        const phone = (o.customerPhone || '').trim();
        const name = (o.customerName || '').trim();
        const key = phone || name || o.id;
        if (!key) return;

        if (!customerMap.has(key)) {
            customerMap.set(key, {
                id: key,
                phone: phone || 'Non renseigné',
                name: name || 'Client Gourmet',
                address: o.customerAddress || o.deliveryAddress || 'Thiès',
                ordersCount: 0,
                completedOrdersCount: 0,
                cancelledOrdersCount: 0,
                totalSpent: 0,
                reservationsCount: 0,
                firstActivity: o.date || '',
                lastActivity: o.date || '',
                lastRestaurantId: o.restaurantId || '',
                lastRestaurantName: o.restaurantName || '',
                preferredMode: o.mode || 'Livraison'
            });
        }

        const c = customerMap.get(key);
        c.ordersCount += 1;
        if (o.status === 'Livrée' || o.status === 'completed' || o.status === 'delivered') {
            c.completedOrdersCount += 1;
            c.totalSpent += (Number(o.total) || 0);
        } else if (o.status === 'Annulée' || o.status === 'cancelled') {
            c.cancelledOrdersCount += 1;
        }

        if (o.customerAddress && (!c.address || c.address === 'Thiès')) c.address = o.customerAddress;
        if (o.customerName && (c.name === 'Client Gourmet' || !c.name)) c.name = o.customerName;
        if (o.date) {
            if (!c.firstActivity || o.date < c.firstActivity) c.firstActivity = o.date;
            if (!c.lastActivity || o.date >= c.lastActivity) {
                c.lastActivity = o.date;
                c.lastRestaurantId = o.restaurantId || c.lastRestaurantId;
                c.lastRestaurantName = o.restaurantName || c.lastRestaurantName;
            }
        }
    });

    // 2. Process reservations
    reservations.forEach(r => {
        const phone = (r.customerPhone || '').trim();
        const name = (r.customerName || '').trim();
        const key = phone || name || r.id;
        if (!key) return;

        if (!customerMap.has(key)) {
            customerMap.set(key, {
                id: key,
                phone: phone || 'Non renseigné',
                name: name || 'Client Gourmet',
                address: 'Thiès',
                ordersCount: 0,
                completedOrdersCount: 0,
                cancelledOrdersCount: 0,
                totalSpent: 0,
                reservationsCount: 0,
                firstActivity: r.date || '',
                lastActivity: r.date || '',
                lastRestaurantId: r.restaurantId || '',
                lastRestaurantName: '',
                preferredMode: 'Sur place'
            });
        }

        const c = customerMap.get(key);
        c.reservationsCount += 1;
        if (r.customerName && (c.name === 'Client Gourmet' || !c.name)) c.name = r.customerName;
        if (r.date) {
            if (!c.firstActivity || r.date < c.firstActivity) c.firstActivity = r.date;
            if (!c.lastActivity || r.date >= c.lastActivity) c.lastActivity = r.date;
        }
    });

    // 3. Process current authenticated customer session
    if (typeof customerAuth !== 'undefined' && customerAuth.isAuthenticated()) {
        const u = customerAuth.getUser();
        const key = (u.phone || u.name || '').trim();
        if (key && !customerMap.has(key)) {
            customerMap.set(key, {
                id: key,
                phone: u.phone || 'Non renseigné',
                name: u.name || 'Client Connecté',
                address: u.address || 'Thiès',
                ordersCount: 0,
                completedOrdersCount: 0,
                cancelledOrdersCount: 0,
                totalSpent: 0,
                reservationsCount: 0,
                firstActivity: new Date().toISOString().split('T')[0],
                lastActivity: new Date().toISOString().split('T')[0],
                lastRestaurantId: '',
                lastRestaurantName: '',
                preferredMode: 'Livraison'
            });
        }
    }

    // 4. Process all registered customers from store.data.customers (synced from central server / DB across devices)
    if (typeof store !== 'undefined' && store.data && Array.isArray(store.data.customers)) {
        store.data.customers.forEach(sc => {
            const phone = (sc.phone || '').trim();
            const name = (sc.name || `${sc.firstname || ''} ${sc.lastname || ''}`).trim();
            const key = phone || name || sc.id;
            if (!key) return;

            if (!customerMap.has(key)) {
                customerMap.set(key, {
                    id: sc.id || key,
                    phone: phone || 'Non renseigné',
                    name: name || 'Client Inscrit',
                    address: sc.address || 'Thiès',
                    email: sc.email || '',
                    ordersCount: Number(sc.ordersCount) || 0,
                    completedOrdersCount: Number(sc.completedOrdersCount) || 0,
                    cancelledOrdersCount: Number(sc.cancelledOrdersCount) || 0,
                    totalSpent: Number(sc.totalSpent) || 0,
                    reservationsCount: Number(sc.reservationsCount) || 0,
                    firstActivity: sc.createdAt ? sc.createdAt.split('T')[0] : (new Date().toISOString().split('T')[0]),
                    lastActivity: sc.last_login ? sc.last_login.split('T')[0] : (new Date().toISOString().split('T')[0]),
                    lastRestaurantId: sc.lastRestaurantId || '',
                    lastRestaurantName: sc.lastRestaurantName || '',
                    preferredMode: sc.preferredMode || 'Livraison',
                    authMethod: sc.authMethod || 'Compte Client'
                });
            } else {
                const c = customerMap.get(key);
                if (name && (c.name === 'Client Gourmet' || c.name === 'Client Connecté' || !c.name)) c.name = name;
                if (sc.address && (!c.address || c.address === 'Thiès')) c.address = sc.address;
                if (sc.email && !c.email) c.email = sc.email;
            }
        });
    }

    return Array.from(customerMap.values()).sort((a, b) => {
        if (b.totalSpent !== a.totalSpent) return b.totalSpent - a.totalSpent;
        return b.ordersCount - a.ordersCount;
    });
};

window.exportCustomersCSV = function() {
    const customers = window.getSuperAdminCustomersList();
    if (customers.length === 0) {
        showToast("Aucun client répertorié à exporter", "warning");
        return;
    }

    let csvContent = "\ufeff"; // BOM for Excel UTF-8
    csvContent += "Nom Client;Telephone;Adresse;Nombre Total Commandes;Commandes Livrees;Commandes Annulees;Reservations;Depenses Totales (FCFA);Derniere Activite;Mode Prefere\n";

    customers.forEach(c => {
        const row = [
            `"${(c.name || '').replace(/"/g, '""')}"`,
            `"${(c.phone || '').replace(/"/g, '""')}"`,
            `"${(c.address || '').replace(/"/g, '""')}"`,
            c.ordersCount,
            c.completedOrdersCount,
            c.cancelledOrdersCount,
            c.reservationsCount,
            c.totalSpent,
            c.lastActivity || '',
            `"${c.preferredMode || 'Livraison'}"`
        ].join(';');
        csvContent += row + "\n";
    });

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const encodedUrl = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUrl);
    link.setAttribute("download", `base_clients_thies_resto_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    showToast("Répertoire clients exporté en format CSV", "success");
};

function renderAdminView() {
    const container = document.getElementById('main-content');
    if (!container) return;
    
    // 1. Calculate Network Figures for stats
    const restos = store.getRestaurants();
    const pendingRestos = restos.filter(r => r.status === 'pending');
    const pendingCount = pendingRestos.length;
    
    // 2. Customers Count
    const customersList = window.getSuperAdminCustomersList ? window.getSuperAdminCustomersList() : [];
    const totalCustomersCount = customersList.length;

    container.innerHTML = `
        <div class="admin-shell">
            <!-- Executive Header -->
            <div class="admin-header-box">
                <div>
                    <div style="display:inline-flex; align-items:center; gap:0.4rem; font-size:0.75rem; font-weight:700; text-transform:uppercase; letter-spacing:0.05em; color:var(--primary); margin-bottom:0.35rem;">
                        <span>Thiès Resto</span> • <span>Administration Centrale</span>
                    </div>
                    <h1 class="admin-header-title">
                        <i class='ri-shield-keyhole-line' style="color: var(--primary); margin-right: 0.4rem;"></i>
                        <span>Console Super-Admin</span>
                    </h1>
                    <p class="admin-header-subtitle">Gestion centralisée des indicateurs d'activité, restaurants partenaires, clients et profil.</p>
                </div>
                <div style="display: flex; align-items: center; gap: 0.75rem; flex-wrap: wrap;">
                    <button class="btn btn-secondary btn-sm" onclick="renderAdminView(); showToast('Données actualisées', 'info');" style="font-weight:700; border-radius:10px; display:inline-flex; align-items:center; gap:0.35rem;">
                        <i class='ri-refresh-line'></i> Actualiser
                    </button>
                </div>
            </div>

            <!-- Super-Admin Desktop Navigation Bar (Strictly hidden on mobile, where bottom nav is fixed) -->
            <div class="admin-desktop-tabs" style="display: flex; gap: 0.5rem; margin-bottom: 1.5rem; border-bottom: 1px solid var(--border); padding-bottom: 0.75rem;">
                <button class="btn btn-sm ${adminActiveTab === 'console' ? 'btn-primary' : 'btn-secondary'}" onclick="switchAdminTab('console')" style="border-radius: 10px; font-weight: 700; display: inline-flex; align-items: center; gap: 0.4rem;">
                    <i class='ri-dashboard-3-line'></i> Console
                </button>
                <button class="btn btn-sm ${adminActiveTab === 'restaurants' ? 'btn-primary' : 'btn-secondary'}" onclick="switchAdminTab('restaurants')" style="border-radius: 10px; font-weight: 700; display: inline-flex; align-items: center; gap: 0.4rem;">
                    <i class='ri-store-2-line'></i> Restaurants (${restos.length})
                    ${pendingCount > 0 ? `<span style="background: #ef4444; color: #fff; font-size: 0.7rem; font-weight: 800; padding: 2px 7px; border-radius: 10px; margin-left: 4px;">${pendingCount} en attente</span>` : ''}
                </button>
                <button class="btn btn-sm ${adminActiveTab === 'clients' ? 'btn-primary' : 'btn-secondary'}" onclick="switchAdminTab('clients')" style="border-radius: 10px; font-weight: 700; display: inline-flex; align-items: center; gap: 0.4rem;">
                    <i class='ri-group-line'></i> Clients (${totalCustomersCount})
                </button>
                <button class="btn btn-sm ${adminActiveTab === 'profil' ? 'btn-primary' : 'btn-secondary'}" onclick="switchAdminTab('profil')" style="border-radius: 10px; font-weight: 700; display: inline-flex; align-items: center; gap: 0.4rem;">
                    <i class='ri-user-settings-line'></i> Profil
                </button>
            </div>

            <!-- Active Tab Container (Populated strictly by renderAdminTabTable) -->
            <div id="admin-table-container">
            </div>
        </div>
    `;

    renderAdminTabTable();
    if (typeof window.renderMobileBottomNav === 'function') {
        window.renderMobileBottomNav();
    }
}

function switchAdminTab(tab) {
    if (tab === 'console' || tab === 'orders' || tab === 'accounting' || tab === 'abonnements' || tab === 'finances' || tab === 'dashboard') {
        adminActiveTab = 'console';
    } else if (tab === 'restaurants' || tab === 'nouveau' || tab === 'active' || tab === 'pending' || tab === 'create') {
        adminActiveTab = 'restaurants';
    } else if (tab === 'clients' || tab === 'customers') {
        adminActiveTab = 'clients';
    } else if (tab === 'profil' || tab === 'profile' || tab === 'securite' || tab === 'security' || tab === 'database' || tab === 'supabase') {
        adminActiveTab = 'profil';
    } else {
        adminActiveTab = 'console';
    }
    
    renderAdminView();
    if (typeof window.renderMobileBottomNav === 'function') {
        window.renderMobileBottomNav();
    }
}

function renderAdminTabTable() {
    const tableContainer = document.getElementById('admin-table-container');
    if (!tableContainer) return;
    const restos = store.getRestaurants();
    const allOrders = store.data.orders || [];

    if (adminActiveTab === 'console' || adminActiveTab === 'dashboard' || adminActiveTab === 'orders') {
        const activeRestos = restos.filter(r => r.status === 'active');
        const suspendedRestos = restos.filter(r => r.status === 'suspended');
        const pendingRestos = restos.filter(r => r.status === 'pending');
        const pendingCount = pendingRestos.length;

        const orders = store.data.orders || [];
        const reservations = store.data.reservations || [];
        const completedOrders = orders.filter(o => o.status === 'Livrée' || o.status === 'completed' || o.status === 'delivered');
        const pendingOrders = orders.filter(o => o.status === 'En attente' || o.status === 'Reçue' || o.status === 'Confirmée' || o.status === 'En cuisine' || o.status === 'Prêt pour livraison' || o.status === 'En livraison');
        const cancelledOrders = orders.filter(o => o.status === 'Annulée' || o.status === 'cancelled');
        const totalGmv = completedOrders.reduce((sum, o) => sum + (Number(o.total) || 0), 0);

        const customersList = window.getSuperAdminCustomersList ? window.getSuperAdminCustomersList() : [];
        const totalCustomersCount = customersList.length;
        const customersWithOrders = customersList.filter(c => c.ordersCount > 0);
        const recurringCustomers = customersList.filter(c => c.ordersCount >= 2);

        const paytechTxs = window.getPaytechTransactionsList ? window.getPaytechTransactionsList() : [];
        const confirmedPaytechTxs = paytechTxs.filter(t => t.status === 'PAID');
        const totalPaytechCollected = confirmedPaytechTxs.reduce((sum, t) => sum + (Number(t.amount) || 0), 0);

        let totalMRR = 0;
        let trialCount = 0;
        let paidSubscriberCount = 0;

        restos.forEach(r => {
            const createdAt = new Date(r.createdAt || '2026-06-25T00:00:00Z');
            const diffDays = Math.ceil(Math.abs(new Date() - createdAt) / (1000 * 60 * 60 * 24));
            const daysLeft = Math.max(0, 7 - diffDays);
            const pack = r.subscriptionPack || 'Pack Standard';

            let monthlyRevenue = 0;
            if (pack === 'Pack Standard' || pack === 'Pack Simple') monthlyRevenue = 9000;
            else if (pack === 'Pack Entreprise' || pack === 'Pack Startup') monthlyRevenue = 15000;
            else if (pack === 'Pack Annuel VIP' || pack === 'Pack Annuel') monthlyRevenue = Math.round(100000 / 12);

            if (r.status === 'active' || r.status === 'suspended') {
                totalMRR += monthlyRevenue;
            }

            if (daysLeft > 0 && !r.subscriptionPaidAt && !r.hasPaidSubscription) {
                trialCount++;
            } else {
                paidSubscriberCount++;
            }
        });

        const totalARR = totalMRR * 12;

        window.adminConsoleSubFilter = window.adminConsoleSubFilter || 'all';
        window.adminConsoleSubSearch = window.adminConsoleSubSearch || '';

        let filteredConsoleRestos = restos;
        if (window.adminConsoleSubFilter === 'active') {
            filteredConsoleRestos = filteredConsoleRestos.filter(r => r.hasPaidSubscription || r.subscriptionPaidAt || r.subscriptionStatus === 'active');
        } else if (window.adminConsoleSubFilter === 'trial') {
            filteredConsoleRestos = filteredConsoleRestos.filter(r => {
                const createdAt = new Date(r.createdAt || '2026-06-25T00:00:00Z');
                const diffDays = Math.ceil(Math.abs(new Date() - createdAt) / (1000 * 60 * 60 * 24));
                const daysLeft = Math.max(0, 7 - diffDays);
                return daysLeft > 0 && !r.subscriptionPaidAt && !r.hasPaidSubscription;
            });
        } else if (window.adminConsoleSubFilter === 'suspended') {
            filteredConsoleRestos = filteredConsoleRestos.filter(r => r.status === 'suspended');
        }

        if (window.adminConsoleSubSearch.trim()) {
            const q = window.adminConsoleSubSearch.trim().toLowerCase();
            filteredConsoleRestos = filteredConsoleRestos.filter(r => 
                (r.name && r.name.toLowerCase().includes(q)) ||
                (r.category && r.category.toLowerCase().includes(q)) ||
                (r.address && r.address.toLowerCase().includes(q)) ||
                (r.subscriptionPack && r.subscriptionPack.toLowerCase().includes(q))
            );
        }

        tableContainer.innerHTML = `
            <!-- 4 Distinct Executive KPI Cards -->
            <div class="admin-kpi-grid" style="margin-bottom: 2rem;">
                <!-- 1. VOLUME D'AFFAIRES GLOBAL (GMV) -->
                <div class="admin-kpi-card kpi-primary">
                    <div>
                        <div class="admin-kpi-header">
                            <span class="admin-kpi-label">Volume Ventes Réseau (GMV)</span>
                            <i class='ri-wallet-3-line admin-kpi-icon' style="color: var(--primary);"></i>
                        </div>
                        <div class="admin-kpi-value" style="color: var(--primary);">${totalGmv.toLocaleString()} <span style="font-size: 0.95rem; font-weight: 700;">FCFA</span></div>
                    </div>
                    <div class="admin-kpi-sub">
                        <span>Sur <strong style="color:var(--text-primary);">${completedOrders.length}</strong> commande(s) livrée(s) • Panier moyen: <strong style="color:var(--text-primary);">${completedOrders.length > 0 ? Math.round(totalGmv / completedOrders.length).toLocaleString() : 0} F</strong></span>
                    </div>
                </div>

                <!-- 2. TOTAL COMMANDES RESEAU -->
                <div class="admin-kpi-card kpi-primary">
                    <div>
                        <div class="admin-kpi-header">
                            <span class="admin-kpi-label">Commandes Plateforme</span>
                            <i class='ri-file-list-3-line admin-kpi-icon' style="color: var(--primary);"></i>
                        </div>
                        <div class="admin-kpi-value">${orders.length} <span style="font-size:0.95rem; font-weight:700; color:var(--text-secondary);">passées</span></div>
                    </div>
                    <div class="admin-kpi-sub">
                        <span style="color: #10b981; font-weight:700;">${completedOrders.length} livrées</span> • <span style="color: #f59e0b; font-weight:700;">${pendingOrders.length} en cours</span> • <span style="color: #64748b;">${cancelledOrders.length} annulées</span>
                    </div>
                </div>

                <!-- 3. ABONNEMENTS SAAS ENCAISSES -->
                <div class="admin-kpi-card kpi-success">
                    <div>
                        <div class="admin-kpi-header">
                            <span class="admin-kpi-label">Abonnements SaaS Encaissés</span>
                            <i class='ri-money-dollar-circle-line admin-kpi-icon' style="color: #10b981;"></i>
                        </div>
                        <div class="admin-kpi-value" style="color: #10b981;">${totalPaytechCollected.toLocaleString()} <span style="font-size: 0.95rem; font-weight: 700;">FCFA</span></div>
                    </div>
                    <div class="admin-kpi-sub">
                        <span>MRR: <strong style="color:#10b981;">${totalMRR.toLocaleString()} F/m</strong> • <strong style="color:var(--text-primary);">${confirmedPaytechTxs.length}</strong> encaissement(s) validé(s)</span>
                    </div>
                </div>

                <!-- 4. RESEAU DES RESTAURANTS -->
                <div class="admin-kpi-card ${pendingCount > 0 ? 'kpi-warning' : 'kpi-info'}">
                    <div>
                        <div class="admin-kpi-header">
                            <span class="admin-kpi-label">Réseau Restaurants</span>
                            <i class='ri-store-2-line admin-kpi-icon' style="color: #0284c7;"></i>
                        </div>
                        <div class="admin-kpi-value" style="color: #0284c7;">${restos.length} <span style="font-size:0.95rem; font-weight:700; color:var(--text-secondary);">partenaires</span></div>
                    </div>
                    <div class="admin-kpi-sub">
                        <span style="color: #10b981; font-weight:800;">${activeRestos.length} actifs</span> • <span style="color: #ef4444; font-weight:800;">${suspendedRestos.length} suspendus</span> • <span style="color: #f59e0b; font-weight:800;">${pendingCount} en attente</span>
                    </div>
                </div>
            </div>

            <!-- Real-Time Restaurant Traffic & Live Orders Monitor -->
            <div class="admin-card-section" style="margin-bottom: 2rem;">
                <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:1.25rem; flex-wrap:wrap; gap:0.75rem; border-bottom:1px solid var(--border); padding-bottom:1rem;">
                    <div>
                        <div style="display:inline-flex; align-items:center; gap:0.4rem; font-size:0.75rem; font-weight:700; text-transform:uppercase; color:#10b981; margin-bottom:0.25rem;">
                            <span style="display:inline-block; width:8px; height:8px; border-radius:50%; background:#10b981; box-shadow: 0 0 8px #10b981;"></span>
                            <span>Flux En Direct • Temps Réel</span>
                        </div>
                        <h3 style="margin:0; font-size:1.2rem; font-weight:800; color:var(--text-primary); display:flex; align-items:center; gap:0.5rem;">
                            <i class='ri-line-chart-line' style="color: var(--primary);"></i>
                            <span>Trafic des Restaurants &amp; Commandes Réseau</span>
                        </h3>
                        <p style="margin:0.25rem 0 0 0; font-size:0.82rem; color:var(--text-secondary);">
                            Surveillance instantanée des flux de commandes, du volume d'affaires et de l'activité par établissement.
                        </p>
                    </div>
                    <div style="display:flex; gap:0.5rem; align-items:center;">
                        <button class="btn btn-secondary btn-sm" onclick="store.syncLiveServerData(); renderAdminTabTable(); showToast('Trafic synchronisé', 'success');" style="font-size:0.8rem; font-weight:700; border-radius:8px; display:inline-flex; align-items:center; gap:0.35rem;">
                            <i class='ri-refresh-line'></i> Actualiser le Trafic
                        </button>
                    </div>
                </div>

                <!-- Live Traffic Table per Restaurant -->
                <div style="overflow-x: auto; margin-bottom: 1.5rem;">
                    <table class="admin-table-modern">
                        <thead>
                            <tr>
                                <th>Établissement</th>
                                <th>Statut Réseau</th>
                                <th>Commandes Reçues</th>
                                <th>Volume d'Affaires (GMV)</th>
                                <th>Dernière Activité</th>
                                <th>Actions Directes</th>
                            </tr>
                        </thead>
                        <tbody>
                            ${(() => {
                                const restoTraffic = restos.map(r => {
                                    const rOrders = orders.filter(o => o.restaurantId === r.id);
                                    const rGmv = rOrders.filter(o => o.status !== 'Annulée' && o.status !== 'cancelled').reduce((s, o) => s + (Number(o.total) || 0), 0);
                                    const lastOrder = rOrders[0] || null;
                                    return {
                                        ...r,
                                        ordersCount: rOrders.length,
                                        gmv: rGmv,
                                        lastOrder
                                    };
                                }).sort((a, b) => (b.ordersCount - a.ordersCount) || (b.gmv - a.gmv));

                                if (restoTraffic.length === 0) {
                                    return `<tr><td colspan="6" style="text-align:center; padding:1.5rem; color:var(--text-secondary);">Aucun restaurant enregistré.</td></tr>`;
                                }

                                return restoTraffic.slice(0, 10).map(r => {
                                    const isLive = r.status === 'active';
                                    let lastOrderText = '<span style="color:var(--text-secondary); font-size:0.75rem;">Aucune commande</span>';
                                    if (r.lastOrder) {
                                        lastOrderText = `<span style="font-weight:700; color:var(--text-primary); font-size:0.82rem;">${r.lastOrder.id}</span> <span style="font-size:0.75rem; color:var(--text-secondary);">(${Number(r.lastOrder.total || 0).toLocaleString()} F)</span>`;
                                    }

                                    return `
                                        <tr>
                                            <td>
                                                <div style="font-weight: 800; color: var(--text-primary); font-size: 0.92rem; display:flex; align-items:center; gap:0.4rem;">
                                                    <span>${r.name}</span>
                                                    ${r.ordersCount > 0 ? `<span style="background:rgba(16,185,129,0.12); color:#10b981; font-size:0.7rem; font-weight:800; padding:2px 6px; border-radius:6px;">Actif</span>` : ''}
                                                </div>
                                                <div style="font-size: 0.75rem; color: var(--text-secondary);">${r.category || 'Restaurant'} • ${r.address || 'Thiès'}</div>
                                            </td>
                                            <td>
                                                <span class="badge ${isLive ? 'badge-success' : 'badge-warning'}" style="font-size:0.75rem;">
                                                    ${isLive ? 'En Ligne' : (r.status === 'pending' ? 'En attente' : 'Suspendu')}
                                                </span>
                                            </td>
                                            <td>
                                                <strong style="font-size: 0.95rem; color: var(--text-primary);">${r.ordersCount}</strong>
                                                <span style="font-size: 0.75rem; color: var(--text-secondary);"> commande(s)</span>
                                            </td>
                                            <td>
                                                <strong style="font-size: 0.95rem; color: #10b981;">${r.gmv.toLocaleString()} FCFA</strong>
                                            </td>
                                            <td>
                                                ${lastOrderText}
                                            </td>
                                            <td>
                                                <div style="display: flex; gap: 0.35rem;">
                                                    <a href="https://wa.me/${(r.whatsapp || '').replace(/\D/g, '')}" target="_blank" rel="noopener noreferrer" class="btn btn-sm btn-ghost" style="padding: 0.25rem 0.5rem; color: #25D366;" title="Contacter sur WhatsApp">
                                                        <i class="ri-whatsapp-line"></i>
                                                    </a>
                                                    <button class="btn btn-sm btn-secondary" onclick="switchAdminTab('restaurants'); window.adminRestoSearch='${r.name.replace(/'/g, "\\'")}'; renderAdminTabTable();" style="font-size: 0.75rem; font-weight: 700; padding: 0.25rem 0.55rem; border-radius: 6px;">
                                                        Voir Fiche
                                                    </button>
                                                </div>
                                            </td>
                                        </tr>
                                    `;
                                }).join('');
                            })()}
                        </tbody>
                    </table>
                </div>

                <!-- Recent Live Orders Feed -->
                <div style="background: var(--bg-page); border: 1px solid var(--border); border-radius: 14px; padding: 1.25rem;">
                    <div style="font-size: 0.9rem; font-weight: 800; color: var(--text-primary); margin-bottom: 0.75rem; display: flex; align-items: center; justify-content: space-between;">
                        <span style="display: flex; align-items: center; gap: 0.4rem;">
                            <i class="ri-history-line" style="color: var(--primary);"></i>
                            <span>Dernières Commandes Passées sur la Plateforme</span>
                        </span>
                        <span style="display: flex; align-items: center; gap: 0.5rem;">
                            <span style="font-size: 0.78rem; color: var(--text-secondary); font-weight: 600;">
                                Total : ${orders.length} commande(s)
                            </span>
                            ${orders.length > 0 ? `
                                <button class="btn btn-ghost btn-sm" onclick="window.adminPurgeTestOrders()" style="font-size: 0.72rem; color: var(--danger); font-weight: 700; padding: 0.2rem 0.5rem; border: 1px dashed var(--danger); border-radius: 6px;" title="Nettoyer les commandes tests avant le lancement">
                                    <i class="ri-delete-bin-2-line"></i> Purger les tests
                                </button>
                            ` : ''}
                        </span>
                    </div>
                    ${orders.length === 0 ? `
                        <div style="text-align: center; padding: 1.5rem; color: var(--text-secondary); font-size: 0.85rem;">
                            Aucune commande enregistrée pour le moment. Dès qu'un client passe commande, elle apparaîtra ici et chez le restaurant concerné en temps réel.
                        </div>
                    ` : `
                        <div style="display: flex; flex-direction: column; gap: 0.6rem;">
                            ${orders.slice(0, 8).map(o => {
                                const resto = store.getRestaurantById(o.restaurantId);
                                const rName = resto ? resto.name : (o.restaurantName || o.restaurantId);
                                return `
                                    <div style="display: flex; justify-content: space-between; align-items: center; padding: 0.75rem 1rem; background: var(--bg-card); border: 1px solid var(--border); border-radius: 10px; flex-wrap: wrap; gap: 0.5rem;">
                                        <div style="display: flex; align-items: center; gap: 0.75rem;">
                                            <div style="font-weight: 800; color: var(--primary); font-family: monospace; font-size: 0.9rem;">${o.id}</div>
                                            <div>
                                                <div style="font-weight: 700; color: var(--text-primary); font-size: 0.85rem;">${o.customerName || 'Client'} chez <strong>${rName}</strong></div>
                                                <div style="font-size: 0.75rem; color: var(--text-secondary);">${o.mode || 'Livraison'} • ${o.date || o.createdAt || 'Aujourd\'hui'}</div>
                                            </div>
                                        </div>
                                        <div style="display: flex; align-items: center; gap: 0.75rem;">
                                            <span class="badge badge-info" style="font-size: 0.75rem;">${o.status || 'Reçue'}</span>
                                            <strong style="color: #10b981; font-size: 0.95rem;">${Number(o.total || 0).toLocaleString()} FCFA</strong>
                                            <button class="btn btn-ghost btn-sm" onclick="window.adminDeleteOrder('${o.id}')" style="color: var(--danger); padding: 0.25rem 0.4rem; font-size: 0.8rem;" title="Supprimer cette commande">
                                                <i class="ri-delete-bin-line"></i>
                                            </button>
                                        </div>
                                    </div>
                                `;
                            }).join('')}
                        </div>
                    `}
                </div>
            </div>

            <!-- Integrated Subscriptions Management Section -->
            <div class="admin-card-section" style="margin-bottom: 2rem;">
                <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:1.25rem; flex-wrap:wrap; gap:0.75rem; border-bottom:1px solid var(--border); padding-bottom:1rem;">
                    <div>
                        <h3 style="margin:0; font-size:1.2rem; font-weight:800; color:var(--text-primary); display:flex; align-items:center; gap:0.5rem;">
                            <i class='ri-money-dollar-circle-line' style="color: #10B981;"></i>
                            <span>Gestion des Abonnements Partenaires</span>
                        </h3>
                        <p style="margin:0.25rem 0 0 0; font-size:0.82rem; color:var(--text-secondary);">
                            Suivi et encaissement des cotisations SaaS des ${restos.length} établissements partenaires de Thiès.
                        </p>
                    </div>
                    <div style="display:flex; gap:0.5rem; flex-wrap:wrap; align-items:center;">
                        <button class="btn btn-primary btn-sm" onclick="window.openRecordPaytechModal()" style="font-size:0.8rem; font-weight:700; border-radius:8px; display:inline-flex; align-items:center; gap:0.35rem;">
                            <i class='ri-add-circle-line'></i> Encaisser un Abonnement
                        </button>
                        <button class="btn btn-secondary btn-sm" onclick="window.exportPlatformFinancialReportCSV()" style="font-size:0.8rem; font-weight:700; border-radius:8px; display:inline-flex; align-items:center; gap:0.35rem;">
                            <i class='ri-download-2-line'></i> Exporter CSV
                        </button>
                    </div>
                </div>

                <!-- Filters & Search Bar -->
                <div style="display: flex; justify-content: space-between; align-items: center; gap: 0.75rem; flex-wrap: wrap; margin-bottom: 1.25rem;">
                    <div style="display: flex; gap: 0.35rem; flex-wrap: wrap;">
                        <button class="btn btn-sm ${window.adminConsoleSubFilter === 'all' ? 'btn-primary' : 'btn-ghost'}" onclick="window.adminConsoleSubFilter = 'all'; renderAdminTabTable();" style="font-size: 0.8rem; font-weight: 700; border-radius: 8px;">
                            Tous (${restos.length})
                        </button>
                        <button class="btn btn-sm ${window.adminConsoleSubFilter === 'active' ? 'btn-primary' : 'btn-ghost'}" onclick="window.adminConsoleSubFilter = 'active'; renderAdminTabTable();" style="font-size: 0.8rem; font-weight: 700; border-radius: 8px;">
                            <i class='ri-checkbox-circle-fill' style="color: #10b981;"></i> Abonnés Actifs (${paidSubscriberCount})
                        </button>
                        <button class="btn btn-sm ${window.adminConsoleSubFilter === 'trial' ? 'btn-primary' : 'btn-ghost'}" onclick="window.adminConsoleSubFilter = 'trial'; renderAdminTabTable();" style="font-size: 0.8rem; font-weight: 700; border-radius: 8px;">
                            <i class='ri-time-line' style="color: #f59e0b;"></i> En essai (${trialCount})
                        </button>
                        <button class="btn btn-sm ${window.adminConsoleSubFilter === 'suspended' ? 'btn-primary' : 'btn-ghost'}" onclick="window.adminConsoleSubFilter = 'suspended'; renderAdminTabTable();" style="font-size: 0.8rem; font-weight: 700; border-radius: 8px;">
                            <i class='ri-forbid-line' style="color: #ef4444;"></i> Suspendus (${suspendedRestos.length})
                        </button>
                    </div>
                    <div style="position: relative; min-width: 240px; flex-grow: 1; max-width: 320px;">
                        <input type="text" class="form-control" placeholder="Rechercher restaurant, formule..." value="${window.adminConsoleSubSearch}" oninput="window.adminConsoleSubSearch = this.value; renderAdminTabTable();" style="font-size: 0.85rem; padding: 0.45rem 0.85rem; border-radius: 10px;">
                    </div>
                </div>

                <!-- Subscriptions Table -->
                <div style="overflow-x: auto;">
                    <table class="admin-table-modern">
                        <thead>
                            <tr>
                                <th>Restaurant &amp; Adresse</th>
                                <th>Statut &amp; Période</th>
                                <th>Formule Souscrite</th>
                                <th>Tarif SaaS</th>
                                <th>Total Encaissé</th>
                                <th>Canal &amp; Moyens</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            ${filteredConsoleRestos.length === 0 ? `
                                <tr>
                                    <td colspan="7" style="text-align:center; padding: 2rem; color: var(--text-secondary);">
                                        Aucun restaurant trouvé pour cette recherche.
                                    </td>
                                </tr>
                            ` : filteredConsoleRestos.map(r => {
                                const createdAt = new Date(r.createdAt || '2026-06-25T00:00:00Z');
                                const diffDays = Math.ceil(Math.abs(new Date() - createdAt) / (1000 * 60 * 60 * 24));
                                const daysLeft = Math.max(0, 7 - diffDays);
                                const pack = r.subscriptionPack || 'Pack Standard';

                                let monthlyFee = 0;
                                if (pack === 'Pack Standard' || pack === 'Pack Simple') monthlyFee = 9000;
                                else if (pack === 'Pack Entreprise' || pack === 'Pack Startup') monthlyFee = 15000;
                                else if (pack === 'Pack Annuel VIP' || pack === 'Pack Annuel') monthlyFee = Math.round(100000 / 12);

                                const rTxs = confirmedPaytechTxs.filter(t => 
                                    (t.restaurantName && r.name && t.restaurantName.toLowerCase() === r.name.toLowerCase()) || 
                                    (t.orderId && r.slug && t.orderId.toLowerCase().includes(r.slug.toLowerCase()))
                                );
                                const rPaidPaytech = rTxs.reduce((sum, t) => sum + (Number(t.amount) || 0), 0);
                                const lastTx = rTxs[0];

                                const isPaid = rPaidPaytech > 0 || r.hasPaidSubscription || r.subscriptionPaidAt;
                                let statusBadge = `<span class="badge badge-success" style="font-size:0.75rem;">Abonné Actif</span>`;
                                if (r.status === 'suspended') {
                                    statusBadge = `<span class="badge badge-danger" style="font-size:0.75rem;">Suspendu</span>`;
                                } else if (!isPaid && daysLeft > 0) {
                                    statusBadge = `<span class="badge badge-warning" style="font-size:0.75rem;">Essai (${daysLeft}j)</span>`;
                                } else if (!isPaid && daysLeft <= 0) {
                                    statusBadge = `<span class="badge badge-danger" style="font-size:0.75rem;">Essai expiré</span>`;
                                }

                                const channelBadge = lastTx && lastTx.paymentMethod 
                                    ? (window.getPaymentBadgeHtml ? window.getPaymentBadgeHtml(lastTx.paymentMethod) : lastTx.paymentMethod)
                                    : `<span style="font-size:0.78rem; color:var(--text-secondary);">Wave / OM / PayDunya</span>`;

                                return `
                                    <tr>
                                        <td>
                                            <div style="font-weight: 800; color: var(--text-primary); font-size: 0.92rem;">${r.name}</div>
                                            <div style="font-size: 0.75rem; color: var(--text-secondary);">${r.category || 'Restaurant'} • ${r.address || 'Thiès'}</div>
                                        </td>
                                        <td>${statusBadge}</td>
                                        <td>
                                            <span class="badge" style="background: rgba(var(--primary-rgb), 0.1); color: var(--primary); font-weight: 700;">
                                                ${pack}
                                            </span>
                                        </td>
                                        <td style="font-weight: 800; color: var(--text-primary); font-size: 0.9rem;">
                                            ${monthlyFee > 0 ? monthlyFee.toLocaleString() + ' F / mois' : '0 F'}
                                        </td>
                                        <td style="font-weight: 800; color: #10b981; font-size: 0.95rem;">
                                            ${rPaidPaytech > 0 ? rPaidPaytech.toLocaleString() + ' FCFA' : '<span style="color:var(--text-secondary); font-weight:500;">0 FCFA</span>'}
                                        </td>
                                        <td>
                                            ${channelBadge}
                                        </td>
                                        <td>
                                            <button class="btn btn-sm btn-secondary" onclick="window.openRecordPaytechModal('${r.id}')" style="font-size: 0.75rem; font-weight: 700; padding: 0.25rem 0.55rem; border-radius: 6px;">
                                                Encaisser
                                            </button>
                                        </td>
                                    </tr>
                                `;
                            }).join('')}
                        </tbody>
                    </table>
                </div>
            </div>
        `;
    }
    else if (adminActiveTab === 'clients' || adminActiveTab === 'customers') {
        const customers = window.getSuperAdminCustomersList();
        window.adminCustomerFilter = window.adminCustomerFilter || 'all'; // 'all', 'buyers', 'recurring', 'reservations'
        window.adminCustomerSearch = window.adminCustomerSearch || '';

        const buyersList = customers.filter(c => c.ordersCount > 0);
        const recurringList = customers.filter(c => c.ordersCount >= 2);
        const reservationsList = customers.filter(c => c.reservationsCount > 0);

        // Apply filter
        let filteredCustomers = [...customers];
        if (window.adminCustomerFilter === 'buyers') filteredCustomers = buyersList;
        else if (window.adminCustomerFilter === 'recurring') filteredCustomers = recurringList;
        else if (window.adminCustomerFilter === 'reservations') filteredCustomers = reservationsList;

        // Apply search query
        if (window.adminCustomerSearch.trim()) {
            const q = window.adminCustomerSearch.toLowerCase().trim();
            filteredCustomers = filteredCustomers.filter(c => {
                const name = (c.name || '').toLowerCase();
                const phone = (c.phone || '').toLowerCase();
                const address = (c.address || '').toLowerCase();
                const resto = (c.lastRestaurantName || '').toLowerCase();
                return name.includes(q) || phone.includes(q) || address.includes(q) || resto.includes(q);
            });
        }

        const totalSpentAll = customers.reduce((sum, c) => sum + (Number(c.totalSpent) || 0), 0);
        const avgSpentPerBuyer = buyersList.length > 0 ? Math.round(totalSpentAll / buyersList.length) : 0;

        let rowsHtml = '';
        if (filteredCustomers.length === 0) {
            rowsHtml = `
                <tr>
                    <td colspan="8" style="text-align: center; padding: 3rem 1.5rem; color: var(--text-secondary);">
                        <div style="font-size: 2rem; margin-bottom: 0.5rem;"><i class='ri-search-line'></i></div>
                        <div style="font-weight: 700; color: var(--text-primary);">Aucun client ne correspond aux critères de recherche</div>
                        <div style="font-size: 0.85rem; margin-top: 0.25rem;">Modifiez vos filtres ou le texte recherché.</div>
                    </td>
                </tr>
            `;
        } else {
            filteredCustomers.forEach(c => {
                let badgeType = `<span class="badge" style="background: rgba(148,163,184,0.15); color: var(--text-secondary); font-size:0.75rem;"><i class='ri-user-line'></i> Inscrit</span>`;
                if (c.ordersCount >= 4 || c.totalSpent >= 25000) {
                    badgeType = `<span class="badge" style="background: rgba(245, 158, 11, 0.15); color: #d97706; font-weight:800; font-size:0.75rem;"><i class='ri-vip-crown-line'></i> Client VIP</span>`;
                } else if (c.ordersCount >= 2) {
                    badgeType = `<span class="badge" style="background: rgba(16, 185, 129, 0.15); color: #059669; font-weight:700; font-size:0.75rem;"><i class='ri-repeat-line'></i> Habitué (${c.ordersCount} cmd)</span>`;
                } else if (c.ordersCount === 1) {
                    badgeType = `<span class="badge badge-info" style="font-size:0.75rem;"><i class='ri-sparkling-line'></i> Nouveau Client</span>`;
                }

                const cleanPhone = (c.phone || '').replace(/\D/g, '');
                const waLink = cleanPhone ? `https://wa.me/${cleanPhone.startsWith('221') ? cleanPhone : '221' + cleanPhone}` : null;

                rowsHtml += `
                    <tr>
                        <td>
                            <div style="display:flex; align-items:center; gap:0.75rem;">
                                <div style="width:38px; height:38px; border-radius:12px; background:linear-gradient(135deg, var(--primary), #ea580c); color:#fff; display:flex; align-items:center; justify-content:center; font-weight:800; font-size:0.95rem; flex-shrink:0;">
                                    ${(c.name || 'C').charAt(0).toUpperCase()}
                                </div>
                                <div>
                                    <div style="font-weight: 800; font-size: 0.95rem; color: var(--text-primary);">${c.name || 'Client'}</div>
                                    <div style="margin-top: 0.2rem;">${badgeType}</div>
                                </div>
                            </div>
                        </td>
                        <td>
                            <div style="display:flex; align-items:center; gap:0.4rem;">
                                <a href="tel:${c.phone}" style="font-weight:700; color:var(--text-primary); text-decoration:none; font-size:0.88rem; display:inline-flex; align-items:center; gap:0.3rem;">
                                    <i class='ri-phone-line'></i> ${c.phone}
                                </a>
                                ${waLink ? `
                                    <a href="${waLink}" target="_blank" title="Envoyer un message WhatsApp" style="display:inline-flex; align-items:center; justify-content:center; width:26px; height:26px; border-radius:6px; background:rgba(37, 211, 102, 0.15); color:#16a34a; text-decoration:none; font-size:0.85rem; font-weight:bold;">
                                        <i class='ri-whatsapp-line'></i>
                                    </a>
                                ` : ''}
                            </div>
                        </td>
                        <td style="font-size: 0.85rem; color: var(--text-secondary); max-width: 180px;">
                            <i class='ri-map-pin-line'></i> ${c.address || 'Thiès'}
                        </td>
                        <td>
                            <div style="font-weight: 800; color: var(--text-primary); font-size: 0.95rem;">
                                ${c.ordersCount} <span style="font-size: 0.75rem; color: var(--text-secondary); font-weight: 600;">cmd(s)</span>
                            </div>
                            <div style="font-size: 0.75rem; color: #10b981;">
                                ${c.completedOrdersCount} livrée(s)
                            </div>
                        </td>
                        <td>
                            <div style="font-weight: 800; color: #10b981; font-size: 0.95rem;">
                                ${c.totalSpent.toLocaleString()} FCFA
                            </div>
                            <div style="font-size: 0.72rem; color: var(--text-secondary);">
                                ${c.ordersCount > 0 ? Math.round(c.totalSpent / c.ordersCount).toLocaleString() + ' F / cmd' : '0 F'}
                            </div>
                        </td>
                        <td style="font-size: 0.82rem; color: var(--text-secondary);">
                            ${c.lastRestaurantName ? `<strong>${c.lastRestaurantName}</strong>` : (c.preferredMode || 'Livraison')}
                        </td>
                        <td style="font-size: 0.82rem; color: var(--text-secondary); white-space: nowrap;">
                            ${c.lastActivity ? `<i class='ri-time-line'></i> ${c.lastActivity}` : '—'}
                        </td>
                        <td>
                            <div class="admin-action-btn-group">
                                ${waLink ? `
                                    <a href="${waLink}" target="_blank" class="admin-action-btn" style="background: rgba(37, 211, 102, 0.12); color: #16a34a; border-color: rgba(37, 211, 102, 0.25); text-decoration:none; display:inline-flex; align-items:center; gap:0.3rem;">
                                        <i class='ri-whatsapp-line'></i> Contacter
                                    </a>
                                ` : `
                                    <span style="font-size:0.8rem; color:var(--text-secondary);">—</span>
                                `}
                            </div>
                        </td>
                    </tr>
                `;
            });
        }

        tableContainer.innerHTML = `
            <div class="admin-card-section" style="padding: 0; overflow: hidden;">
                <!-- Header & Controls -->
                <div style="padding: 1.25rem 1.5rem; border-bottom: 1px solid var(--border); display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:1rem;">
                    <div>
                        <h3 style="margin: 0; font-size: 1.2rem; font-weight: 800; color: var(--text-primary); display:flex; align-items:center; gap:0.5rem;">
                            <i class='ri-user-star-line' style="color: var(--primary);"></i>
                            <span>Répertoire &amp; Base des Clients de la Plateforme</span>
                        </h3>
                        <p style="margin: 0.25rem 0 0 0; font-size: 0.82rem; color: var(--text-secondary);">
                            Suivi complet des consommateurs ayant commandé ou réservé sur le réseau de Thiès.
                        </p>
                    </div>
                    <div style="display:flex; gap:0.6rem; flex-wrap:wrap;">
                        <button class="btn btn-secondary btn-sm" onclick="window.exportCustomersCSV()" style="font-weight:700; border-radius:10px; display:inline-flex; align-items:center; gap:0.4rem;">
                            <i class='ri-download-2-line'></i> Exporter Base Clients (CSV)
                        </button>
                    </div>
                </div>

                <!-- Mini Stats Bar for Customers -->
                <div style="display:grid; grid-template-columns:repeat(auto-fit, minmax(180px, 1fr)); gap:1rem; padding:1.25rem 1.5rem; background:var(--bg-secondary); border-bottom:1px solid var(--border);">
                    <div style="background:var(--bg-card); padding:0.85rem 1rem; border-radius:12px; border:1px solid var(--border);">
                        <div style="font-size:0.75rem; font-weight:700; color:var(--text-secondary); text-transform:uppercase;">Total Clients Identifiés</div>
                        <div style="font-size:1.4rem; font-weight:800; color:#0284c7; margin-top:0.2rem;">${customers.length}</div>
                        <div style="font-size:0.75rem; color:var(--text-secondary);">${buyersList.length} ont validé au moins 1 commande</div>
                    </div>
                    <div style="background:var(--bg-card); padding:0.85rem 1rem; border-radius:12px; border:1px solid var(--border);">
                        <div style="font-size:0.75rem; font-weight:700; color:var(--text-secondary); text-transform:uppercase;">Clients Fidèles (≥2 cmd)</div>
                        <div style="font-size:1.4rem; font-weight:800; color:#10b981; margin-top:0.2rem;">${recurringList.length}</div>
                        <div style="font-size:0.75rem; color:var(--text-secondary);">${customers.length > 0 ? Math.round((recurringList.length / customers.length) * 100) : 0}% de récurrence globale</div>
                    </div>
                    <div style="background:var(--bg-card); padding:0.85rem 1rem; border-radius:12px; border:1px solid var(--border);">
                        <div style="font-size:0.75rem; font-weight:700; color:var(--text-secondary); text-transform:uppercase;">Panier Moyen Client</div>
                        <div style="font-size:1.4rem; font-weight:800; color:var(--primary); margin-top:0.2rem;">${avgSpentPerBuyer.toLocaleString()} FCFA</div>
                        <div style="font-size:0.75rem; color:var(--text-secondary);">Dépense moyenne cumulée par acheteur</div>
                    </div>
                    <div style="background:var(--bg-card); padding:0.85rem 1rem; border-radius:12px; border:1px solid var(--border);">
                        <div style="font-size:0.75rem; font-weight:700; color:var(--text-secondary); text-transform:uppercase;">Volume Dépensé Total</div>
                        <div style="font-size:1.4rem; font-weight:800; color:#059669; margin-top:0.2rem;">${totalSpentAll.toLocaleString()} FCFA</div>
                        <div style="font-size:0.75rem; color:var(--text-secondary);">Chiffre d'affaires global généré par les clients</div>
                    </div>
                </div>

                <!-- Filter Pills and Search bar -->
                <div style="padding: 1rem 1.5rem; border-bottom: 1px solid var(--border); display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:0.75rem;">
                    <div style="display:flex; gap:0.4rem; flex-wrap:wrap;">
                        <button class="btn btn-sm ${window.adminCustomerFilter === 'all' ? 'btn-primary' : 'btn-secondary'}" onclick="window.adminCustomerFilter='all'; renderAdminTabTable();" style="border-radius:20px; font-weight:700;">
                            Tous (${customers.length})
                        </button>
                        <button class="btn btn-sm ${window.adminCustomerFilter === 'buyers' ? 'btn-primary' : 'btn-secondary'}" onclick="window.adminCustomerFilter='buyers'; renderAdminTabTable();" style="border-radius:20px; font-weight:700;">
                            Acheteurs Actifs (${buyersList.length})
                        </button>
                        <button class="btn btn-sm ${window.adminCustomerFilter === 'recurring' ? 'btn-primary' : 'btn-secondary'}" onclick="window.adminCustomerFilter='recurring'; renderAdminTabTable();" style="border-radius:20px; font-weight:700;">
                            Clients Fidèles (≥2 cmd) (${recurringList.length})
                        </button>
                        <button class="btn btn-sm ${window.adminCustomerFilter === 'reservations' ? 'btn-primary' : 'btn-secondary'}" onclick="window.adminCustomerFilter='reservations'; renderAdminTabTable();" style="border-radius:20px; font-weight:700;">
                            Réservations Table (${reservationsList.length})
                        </button>
                    </div>
                    <div style="flex:1; max-width:320px; min-width:200px;">
                        <input type="text" class="form-control" placeholder="Rechercher client, tél, quartier..." value="${window.adminCustomerSearch}" oninput="window.adminCustomerSearch=this.value; renderAdminTabTable();" style="font-size:0.85rem; padding:0.45rem 0.85rem; border-radius:10px;">
                    </div>
                </div>

                <!-- Customers Table -->
                <div style="overflow-x: auto;">
                    <table class="admin-table-modern">
                        <thead>
                            <tr>
                                <th>Client & Profil</th>
                                <th>Téléphone & Contact</th>
                                <th>Adresse Principale</th>
                                <th>Commandes</th>
                                <th>Dépenses Totales</th>
                                <th>Dernier Établissement</th>
                                <th>Dernière Activité</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            ${rowsHtml}
                        </tbody>
                    </table>
                </div>
            </div>
        `;
    }
    else if (adminActiveTab === 'nouveau' || adminActiveTab === 'restaurants' || adminActiveTab === 'active' || adminActiveTab === 'pending' || adminActiveTab === 'create') {
        const allRestosList = store.getRestaurants();
        window.adminRestoFilter = window.adminRestoFilter || (adminActiveTab === 'pending' ? 'pending' : (adminActiveTab === 'create' ? 'create' : 'all'));
        window.adminRestoSearch = window.adminRestoSearch || '';

        const pendingList = allRestosList.filter(r => r.status === 'pending');
        const activeList = allRestosList.filter(r => r.status === 'active' || !r.status);
        const suspendedList = allRestosList.filter(r => r.status === 'suspended');

        let filtered = allRestosList;
        if (window.adminRestoFilter === 'pending') {
            filtered = pendingList;
        } else if (window.adminRestoFilter === 'active') {
            filtered = activeList;
        } else if (window.adminRestoFilter === 'suspended') {
            filtered = suspendedList;
        }

        if (window.adminRestoSearch && window.adminRestoFilter !== 'create') {
            const q = window.adminRestoSearch.toLowerCase();
            filtered = filtered.filter(r => 
                (r.name && r.name.toLowerCase().includes(q)) ||
                (r.category && r.category.toLowerCase().includes(q)) ||
                (r.address && r.address.toLowerCase().includes(q)) ||
                (r.whatsapp && r.whatsapp.includes(q)) ||
                (r.username && r.username.toLowerCase().includes(q))
            );
        }

        const pendingBannerHtml = '';

        const createFormHtml = `
            <div class="admin-card-section" style="max-width: 680px; margin: 0 auto; padding: 1.75rem; border-radius: 16px; border: 1px solid var(--border);">
                <div style="text-align: center; margin-bottom: 1.75rem;">
                    <div style="width: 48px; height: 48px; border-radius: 12px; background: rgba(var(--primary-rgb), 0.1); color: var(--primary); display: inline-flex; align-items: center; justify-content: center; font-size: 1.4rem; margin-bottom: 0.75rem;">
                        <i class='ri-store-2-line'></i>
                    </div>
                    <h3 style="font-size: 1.35rem; font-weight: 800; color: var(--text-primary); margin: 0 0 0.35rem 0;">Enregistrer un Nouveau Restaurant Partenaire</h3>
                    <p style="color: var(--text-secondary); font-size: 0.85rem; margin: 0;">Ajout direct d'un établissement dans le réseau avec activation immédiate de ses accès.</p>
                </div>
                
                <form id="admin-create-resto-form" onsubmit="handleAdminCreateRestaurant(event)">
                    <div class="form-group" style="margin-bottom: 1.15rem;">
                        <label class="form-label" style="font-weight: 700;">Nom du restaurant <span class="required">*</span></label>
                        <input type="text" id="adm-reg-name" class="form-control" placeholder="Ex: Dibiterie Chez Bouba" required oninput="handleRestaurantNameInput(this.value, 'adm-reg-username', 'adm-reg-password', 'adm-slug-availability-badge')">
                    </div>
                    
                    <div class="form-group" style="margin-bottom: 1.15rem;">
                        <label class="form-label" style="font-weight: 700;">Adresse physique à Thiès <span class="required">*</span></label>
                        <input type="text" id="adm-reg-address" class="form-control" placeholder="Avenue de Caen, Thiès" required>
                    </div>
                    
                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1rem; margin-bottom: 1.15rem;">
                        <div class="form-group">
                            <label class="form-label" style="font-weight: 700;">Catégorie <span class="required">*</span></label>
                            <select id="adm-reg-category" class="form-control" required>
                                <option value="Traditionnel">Traditionnel (Thiéb, Yassa, Mafé)</option>
                                <option value="Grillades / Dibi">Grillades / Dibi (Dibiterie)</option>
                                <option value="Fast Food">Fast Food (Burgers, Chawarmas)</option>
                                <option value="Pâtisserie">Pâtisserie / Petit Déjeuner</option>
                                <option value="Gastronomique">Chic / Gastronomique</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label class="form-label" style="font-weight: 700;">Numéro WhatsApp <span class="required">*</span></label>
                            <input type="tel" id="adm-reg-whatsapp" class="form-control" placeholder="+221 77 XXX XX XX" required>
                        </div>
                    </div>
                    
                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1rem; margin-bottom: 1.15rem;">
                        <div class="form-group">
                            <label class="form-label" style="font-weight: 700;">Heure d'ouverture <span class="required">*</span></label>
                            <input type="time" id="adm-reg-open" class="form-control" value="12:00" required>
                        </div>
                        <div class="form-group">
                            <label class="form-label" style="font-weight: 700;">Heure de fermeture <span class="required">*</span></label>
                            <input type="time" id="adm-reg-close" class="form-control" value="23:00" required>
                        </div>
                    </div>

                    <div class="form-group" style="margin-bottom: 1.15rem;">
                        <label class="form-label" style="font-weight: 700;">Identifiant de connexion (slug unique) <span class="required">*</span></label>
                        <input type="text" id="adm-reg-username" class="form-control" placeholder="letoile-thies" required oninput="checkSlugAvailabilityRealtime(this.value)">
                        <div id="adm-slug-availability-badge" class="slug-status" style="margin-top: 0.35rem; font-size: 0.8rem; font-weight: 600;"></div>
                    </div>
                    
                    <div class="form-group" style="margin-bottom: 1.75rem;">
                        <label class="form-label" style="font-weight: 700;">Mot de passe de gestion <span class="required">*</span></label>
                        <input type="password" id="adm-reg-password" class="form-control" placeholder="••••••••" required>
                    </div>
                    
                    <button type="submit" class="btn btn-primary btn-block" style="font-weight: 800; font-size: 1rem; padding: 0.85rem; border-radius: 12px; display: inline-flex; align-items: center; justify-content: center; gap: 0.5rem;">
                        <i class='ri-check-line'></i> Activer et Ajouter au Réseau
                    </button>
                </form>
            </div>
        `;

        const restoCardsHtml = filtered.length > 0 ? `
            <div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(330px, 1fr)); gap: 1.25rem;">
                ${filtered.map(r => {
                    const cleanPhone = (r.whatsapp || '').replace(/[^0-9]/g, '');
                    const menuCount = (r.menu && Array.isArray(r.menu)) ? r.menu.length : 0;
                    const isPending = r.status === 'pending';
                    const isSuspended = r.status === 'suspended';
                    const pack = r.subscriptionPack || 'Aucun (Gratuit)';

                    let statusBadge = `<span class="badge badge-success" style="font-size: 0.72rem; padding: 0.25rem 0.55rem;"><i class='ri-checkbox-circle-fill'></i> Actif</span>`;
                    if (isPending) {
                        statusBadge = `<span class="badge badge-warning" style="font-size: 0.72rem; padding: 0.25rem 0.55rem;"><i class='ri-time-line'></i> En attente</span>`;
                    } else if (isSuspended) {
                        statusBadge = `<span class="badge badge-danger" style="font-size: 0.72rem; padding: 0.25rem 0.55rem;"><i class='ri-forbid-line'></i> Suspendu</span>`;
                    }

                    return `
                        <div class="admin-card-section" style="padding: 1.25rem; display: flex; flex-direction: column; justify-content: space-between; border-radius: 16px; border: 1px solid var(--border); transition: transform 0.2s ease;">
                            <div>
                                <div style="display: flex; align-items: center; gap: 0.85rem; margin-bottom: 0.85rem;">
                                    <img src="${r.coverImage || r.image || 'icon.png'}" alt="${r.name}" style="width: 50px; height: 50px; border-radius: 12px; object-fit: cover; border: 1px solid var(--border);">
                                    <div style="flex: 1; min-width: 0;">
                                        <div style="display: flex; align-items: center; justify-content: space-between; gap: 0.5rem;">
                                            <h4 style="margin: 0; font-size: 1.05rem; font-weight: 800; color: var(--text-primary); white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">
                                                ${r.name}
                                            </h4>
                                            ${statusBadge}
                                        </div>
                                        <div style="font-size: 0.8rem; color: var(--text-secondary); margin-top: 0.15rem; display: flex; align-items: center; gap: 0.35rem;">
                                            <i class='ri-price-tag-3-line'></i> ${r.category || 'Général'} &bull; <i class="star-fill" style="color: #f59e0b;"></i> ${r.rating || '5.0'} (${r.reviewsCount || 0} avis)
                                        </div>
                                    </div>
                                </div>

                                <div style="background: var(--bg-secondary); border-radius: 10px; padding: 0.65rem 0.85rem; font-size: 0.8rem; margin-bottom: 0.85rem; display: flex; flex-direction: column; gap: 0.35rem;">
                                    <div style="display: flex; justify-content: space-between; align-items: center;">
                                        <span style="color: var(--text-secondary);"><i class='ri-map-pin-line'></i> Adresse :</span>
                                        <span style="font-weight: 600; color: var(--text-primary);">${r.address || 'Thiès'}</span>
                                    </div>
                                    <div style="display: flex; justify-content: space-between; align-items: center;">
                                        <span style="color: var(--text-secondary);"><i class='ri-whatsapp-line'></i> WhatsApp :</span>
                                        <a href="https://wa.me/${cleanPhone}" target="_blank" style="font-weight: 600; color: var(--primary); text-decoration: underline;">${r.whatsapp}</a>
                                    </div>
                                    <div style="display: flex; justify-content: space-between; align-items: center;">
                                        <span style="color: var(--text-secondary);"><i class='ri-restaurant-line'></i> Plats au menu :</span>
                                        <span style="font-weight: 700; color: var(--text-primary);">${menuCount} plat${menuCount > 1 ? 's' : ''}</span>
                                    </div>
                                    <div style="display: flex; justify-content: space-between; align-items: center;">
                                        <span style="color: var(--text-secondary);"><i class='ri-vip-crown-line'></i> Formule SaaS :</span>
                                        <select onchange="updateRestaurantPack('${r.id}', this.value)" style="font-size: 0.75rem; font-weight: 700; background: var(--bg-card); color: var(--text-primary); border: 1px solid var(--border); border-radius: 6px; padding: 0.15rem 0.35rem;">
                                            <option value="Aucun (Gratuit)" ${pack.includes('Gratuit') ? 'selected' : ''}>Aucun (Gratuit)</option>
                                            <option value="Pack Standard (9 000 FCFA/mois)" ${pack.includes('Standard') ? 'selected' : ''}>Pack Standard</option>
                                            <option value="Pack Entreprise (25 000 FCFA/mois)" ${pack.includes('Entreprise') ? 'selected' : ''}>Pack Entreprise</option>
                                            <option value="Pack Annuel VIP (150 000 FCFA/an)" ${pack.includes('Annuel') ? 'selected' : ''}>Pack VIP Annuel</option>
                                        </select>
                                    </div>
                                    <div style="display: flex; justify-content: space-between; align-items: center; border-top: 1px dashed var(--border); padding-top: 0.35rem; font-family: monospace; font-size: 0.75rem;">
                                        <span style="color: var(--text-secondary);">Identifiant :</span>
                                        <span style="color: var(--text-primary); font-weight: 700;">${r.username || r.slug}</span>
                                    </div>
                                    <div style="display: flex; justify-content: space-between; align-items: center; padding-top: 0.2rem; font-family: monospace; font-size: 0.75rem;">
                                        <span style="color: var(--text-secondary);">Mot de passe :</span>
                                        <span style="display: inline-flex; align-items: center; gap: 0.3rem;">
                                            <span id="pwd-text-${r.id}" style="color: var(--text-primary); font-weight: 700; letter-spacing: 1px;">••••••••</span>
                                            <button type="button" onclick="window.toggleAdminPasswordDisplay('${r.id}', '${(r.password || 'resto123').replace(/'/g, "\\'")}')" title="Afficher/Masquer le mot de passe" style="background: none; border: none; cursor: pointer; color: var(--text-secondary); padding: 0 4px; font-size: 0.85rem;">
                                                <i id="pwd-icon-${r.id}" class='ri-eye-off-line'></i>
                                            </button>
                                        </span>
                                    </div>
                                </div>
                            </div>

                            <div style="display: flex; align-items: center; gap: 0.4rem; flex-wrap: wrap; margin-top: 0.5rem; border-top: 1px solid var(--border); padding-top: 0.75rem;">
                                ${isPending ? `
                                    <button class="btn btn-primary btn-sm" onclick="approveRestaurant('${r.id}')" style="flex: 1; font-weight: 800; font-size: 0.8rem; padding: 0.45rem; display: inline-flex; align-items: center; justify-content: center; gap: 0.3rem;">
                                        <i class='ri-checkbox-circle-line'></i> Activer
                                    </button>
                                ` : `
                                    <button class="btn btn-primary btn-sm" onclick="impersonateRestaurant('${r.id}')" style="flex: 1; font-weight: 700; font-size: 0.78rem; padding: 0.45rem; display: inline-flex; align-items: center; justify-content: center; gap: 0.3rem;" title="Gérer le menu et les commandes">
                                        <i class='ri-dashboard-line'></i> Espace Gérant
                                    </button>
                                `}

                                <button class="btn btn-outline btn-sm" onclick="router.navigate('/r/${r.slug}')" style="font-size: 0.78rem; padding: 0.45rem 0.65rem; display: inline-flex; align-items: center; gap: 0.25rem;" title="Voir la fiche publique">
                                    <i class='ri-external-link-line'></i> Fiche
                                </button>

                                ${isSuspended ? `
                                    <button class="btn btn-ghost btn-sm" onclick="reactivateRestaurant('${r.id}')" style="color: var(--success); font-size: 0.78rem; padding: 0.45rem 0.65rem;" title="Réactiver ce restaurant">
                                        <i class='ri-play-circle-line'></i>
                                    </button>
                                ` : (r.status === 'active' ? `
                                    <button class="btn btn-ghost btn-sm" onclick="suspendRestaurant('${r.id}')" style="color: var(--warning); font-size: 0.78rem; padding: 0.45rem 0.65rem;" title="Suspendre temporairement">
                                        <i class='ri-pause-circle-line'></i>
                                    </button>
                                ` : '')}

                                <button class="btn btn-ghost btn-sm" onclick="deleteRestaurantAdmin('${r.id}')" style="color: var(--danger); font-size: 0.78rem; padding: 0.45rem 0.65rem;" title="Supprimer définitivement">
                                    <i class='ri-delete-bin-line'></i>
                                </button>
                            </div>
                        </div>
                    `;
                }).join('')}
            </div>
        ` : `
            <div style="text-align: center; padding: 3rem 1.5rem; background: var(--bg-card); border-radius: 16px; border: 1px solid var(--border);">
                <div style="font-size: 2.5rem; margin-bottom: 0.5rem;"><i class='ri-search-line'></i></div>
                <h4 style="font-size: 1.15rem; font-weight: 800; color: var(--text-primary); margin: 0 0 0.35rem 0;">Aucun restaurant trouvé</h4>
                <p style="color: var(--text-secondary); font-size: 0.85rem; margin: 0 0 1.25rem 0;">Aucun établissement ne correspond à vos critères de recherche ou filtre actuel.</p>
                <button class="btn btn-primary btn-sm" onclick="window.adminRestoFilter = 'all'; window.adminRestoSearch = ''; renderAdminTabTable();">
                    Réinitialiser les filtres
                </button>
            </div>
        `;

        if (window.adminRestoFilter === 'create') {
            tableContainer.innerHTML = `
                <div>
                    <!-- Header -->
                    <div style="display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 1rem; margin-bottom: 1.5rem;">
                        <div>
                            <h3 style="font-size: 1.35rem; font-weight: 800; color: var(--text-primary); margin: 0 0 0.25rem 0; display: flex; align-items: center; gap: 0.5rem;">
                                <i class='ri-store-2-line' style="color: var(--primary);"></i>
                                <span>Réseau &amp; Partenaires</span>
                            </h3>
                            <p style="color: var(--text-secondary); font-size: 0.85rem; margin: 0;">
                                Enregistrez un nouvel établissement ou gérez le parc de restaurants partenaires de Thiès.
                            </p>
                        </div>
                        <button class="btn btn-secondary btn-sm" onclick="window.adminRestoFilter = 'all'; renderAdminTabTable();" style="font-weight: 700; font-size: 0.85rem; padding: 0.5rem 1rem; border-radius: 10px; display: inline-flex; align-items: center; gap: 0.4rem;">
                            <i class='ri-list-check-2'></i> Voir la Liste des Restaurants (${allRestosList.length})
                        </button>
                    </div>

                    ${createFormHtml}
                </div>
            `;
        } else {
            tableContainer.innerHTML = `
                <div>
                    <!-- Header / Intro -->
                    <div style="display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 1rem; margin-bottom: 1.5rem;">
                        <div>
                            <h3 style="font-size: 1.35rem; font-weight: 800; color: var(--text-primary); margin: 0 0 0.25rem 0; display: flex; align-items: center; gap: 0.5rem;">
                                <i class='ri-store-2-line' style="color: var(--primary);"></i>
                                <span>Réseau des Restaurants Partenaires</span>
                            </h3>
                            <p style="color: var(--text-secondary); font-size: 0.85rem; margin: 0;">
                                Supervisez l'ensemble des ${allRestosList.length} établissements partenaires inscrits sur la plateforme THIES Resto.
                            </p>
                        </div>
                        <button class="btn btn-primary btn-sm" onclick="window.adminRestoFilter = 'create'; renderAdminTabTable();" style="font-weight: 800; font-size: 0.85rem; padding: 0.5rem 1rem; border-radius: 10px; display: inline-flex; align-items: center; gap: 0.4rem;">
                            <i class='ri-add-circle-line'></i> Nouveau Restaurant
                        </button>
                    </div>

                    <!-- Pending Applications Alert (if any) -->
                    ${pendingBannerHtml}

                    <!-- Search & Filters Control Bar -->
                    <div style="display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 0.85rem; margin-bottom: 1.5rem; background: var(--bg-card); padding: 0.85rem 1.15rem; border-radius: 14px; border: 1px solid var(--border);">
                        <div style="display: flex; align-items: center; gap: 0.4rem; flex-wrap: wrap;">
                            <button class="btn btn-sm ${window.adminRestoFilter === 'all' ? 'btn-primary' : 'btn-ghost'}" onclick="window.adminRestoFilter = 'all'; renderAdminTabTable();" style="font-size: 0.8rem; font-weight: 700;">
                                Tous (${allRestosList.length})
                            </button>
                            <button class="btn btn-sm ${window.adminRestoFilter === 'active' ? 'btn-primary' : 'btn-ghost'}" onclick="window.adminRestoFilter = 'active'; renderAdminTabTable();" style="font-size: 0.8rem; font-weight: 700; display: inline-flex; align-items: center; gap: 0.3rem;">
                                <i class='ri-checkbox-circle-fill' style="color: var(--success);"></i> Actifs (${activeList.length})
                            </button>
                            <button class="btn btn-sm ${window.adminRestoFilter === 'pending' ? 'btn-primary' : 'btn-ghost'}" onclick="window.adminRestoFilter = 'pending'; renderAdminTabTable();" style="font-size: 0.8rem; font-weight: 700; position: relative; display: inline-flex; align-items: center; gap: 0.3rem;">
                                <i class='ri-time-line' style="color: var(--warning);"></i> En attente (${pendingList.length})
                                ${pendingList.length > 0 ? `<span style="background: var(--danger); color: #fff; width: 8px; height: 8px; border-radius: 50%; display: inline-block; margin-left: 0.35rem;"></span>` : ''}
                            </button>
                            <button class="btn btn-sm ${window.adminRestoFilter === 'suspended' ? 'btn-primary' : 'btn-ghost'}" onclick="window.adminRestoFilter = 'suspended'; renderAdminTabTable();" style="font-size: 0.8rem; font-weight: 700; display: inline-flex; align-items: center; gap: 0.3rem;">
                                <i class='ri-forbid-line' style="color: var(--danger);"></i> Suspendus (${suspendedList.length})
                            </button>
                        </div>

                        <div style="position: relative; min-width: 260px;">
                            <input type="text" class="form-control" placeholder="Rechercher restaurant, gérant, téléphone..." value="${window.adminRestoSearch}" oninput="window.adminRestoSearch = this.value; renderAdminTabTable();" style="font-size: 0.85rem; padding: 0.45rem 0.85rem; border-radius: 10px;">
                        </div>
                    </div>

                    <!-- Restaurants List -->
                    ${restoCardsHtml}
                </div>
            `;
        }
    }
    else if (adminActiveTab === 'profil' || adminActiveTab === 'profile' || adminActiveTab === 'securite' || adminActiveTab === 'security') {
        tableContainer.innerHTML = `
            <div style="max-width: 540px; margin: 0 auto; width: 100%;">
                <div class="admin-card-section" style="padding: 2rem; border-radius: 18px; border: 1px solid var(--border); box-shadow: var(--shadow-sm); background: var(--bg-surface);">
                    <div style="text-align: center; margin-bottom: 1.75rem;">
                        <div style="width: 56px; height: 56px; border-radius: 16px; background: rgba(var(--primary-rgb), 0.1); color: var(--primary); display: inline-flex; align-items: center; justify-content: center; font-size: 1.7rem; margin-bottom: 0.75rem;">
                            <i class="ri-user-settings-line"></i>
                        </div>
                        <h3 style="margin: 0 0 0.35rem 0; font-size: 1.35rem; color: var(--text-primary); font-weight: 800;">Mon Profil Administrateur</h3>
                        <p style="color: var(--text-secondary); font-size: 0.88rem; margin: 0;">Gestion sécurisée de l'accès central à la plateforme Thiès Resto.</p>
                    </div>

                    <form onsubmit="handleAdminChangePassword(event)" style="display: flex; flex-direction: column; gap: 1.25rem;">
                        <div class="form-group">
                            <label class="form-label" style="font-weight: 700; font-size: 0.88rem;">Email Super Administrateur</label>
                            <input type="email" class="form-control" value="thiesresto.th@gmail.com" disabled style="background: var(--bg-secondary); color: var(--text-primary); font-weight: 700; font-size: 0.95rem; border-radius: 10px;">
                        </div>

                        <div class="form-group">
                            <label class="form-label" style="font-weight: 700; font-size: 0.88rem;">Identifiant Administrateur</label>
                            <input type="text" class="form-control" value="thiesresto" disabled style="background: var(--bg-secondary); color: var(--text-primary); font-weight: 700; font-family: monospace; font-size: 0.95rem; border-radius: 10px;">
                        </div>

                        <div class="form-group">
                            <label class="form-label" style="font-weight: 700; font-size: 0.88rem;">Nouveau mot de passe <span class="required" style="color: var(--primary);">*</span></label>
                            <div style="position: relative;">
                                <input type="password" id="admin-new-password" class="form-control" placeholder="Entrez le nouveau mot de passe" required minlength="6" style="padding-right: 2.75rem; border-radius: 10px;">
                                <button type="button" onclick="togglePassVisibility('admin-new-password', this)" style="position: absolute; right: 10px; top: 50%; transform: translateY(-50%); background: none; border: none; cursor: pointer; color: var(--text-secondary); font-size: 1.1rem;">
                                    <i class="ri-eye-line"></i>
                                </button>
                            </div>
                        </div>

                        <div class="form-group">
                            <label class="form-label" style="font-weight: 700; font-size: 0.88rem;">Confirmer le mot de passe <span class="required" style="color: var(--primary);">*</span></label>
                            <input type="password" id="admin-confirm-password" class="form-control" placeholder="Confirmez le nouveau mot de passe" required minlength="6" style="border-radius: 10px;">
                        </div>

                        <button type="submit" class="btn btn-primary btn-block" style="font-weight: 800; font-size: 0.95rem; padding: 0.85rem; border-radius: 12px; margin-top: 0.5rem; display: inline-flex; align-items: center; justify-content: center; gap: 0.4rem;">
                            <i class="ri-save-line"></i> Mettre à jour le mot de passe
                        </button>
                    </form>

                    <div style="margin-top: 1.5rem; padding-top: 1.25rem; border-top: 1px solid var(--border);">
                        <button type="button" class="btn btn-outline btn-block" onclick="logoutSuperAdmin()" style="border-radius: 12px; font-weight: 700; color: #ef4444; border-color: rgba(239, 68, 68, 0.3); display: inline-flex; align-items: center; justify-content: center; gap: 0.4rem; padding: 0.75rem;">
                            <i class="ri-logout-box-r-line"></i> Se déconnecter de la session
                        </button>
                    </div>
                </div>
            </div>
        `;
    }
}

// Activity Logs loader for SuperAdmin
window.loadAdminActivityLogs = async function() {
    const container = document.getElementById('activity-logs-container');
    if (!container) return;

    const filterEntity = document.getElementById('log-filter-entity')?.value || '';
    
    try {
        const url = `/api/activity-logs?limit=50${filterEntity ? `&entity_type=${filterEntity}` : ''}`;
        const res = await fetch(url);
        const data = await res.json();

        if (!data.success || !Array.isArray(data.logs) || data.logs.length === 0) {
            container.innerHTML = `
                <div style="text-align: center; padding: 2rem; color: var(--text-secondary); font-size: 0.9rem;">
                    Aucun journal d'activité enregistré pour le moment.
                </div>
            `;
            return;
        }

        const rows = data.logs.map(log => {
            const dateStr = new Date(log.timestamp).toLocaleString('fr-FR', {
                day: '2-digit',
                month: '2-digit',
                year: 'numeric',
                hour: '2-digit',
                minute: '2-digit',
                second: '2-digit'
            });

            let actorBadge = `<span class="badge" style="background: rgba(100, 116, 139, 0.15); color: #475569; font-size: 0.75rem;">${log.actor || 'System'}</span>`;
            if (log.actor === 'SuperAdmin') {
                actorBadge = `<span class="badge badge-primary" style="font-size: 0.75rem;">SuperAdmin</span>`;
            } else if (log.actor === 'PayTech' || log.actor === 'PayTech IPN') {
                actorBadge = `<span class="badge" style="background: rgba(34, 197, 94, 0.15); color: #16a34a; font-weight: 700; font-size: 0.75rem;">PayTech</span>`;
            }

            let entityBadge = `<span class="badge" style="font-size: 0.72rem; text-transform: uppercase;">${log.entity_type}</span>`;
            if (log.entity_type === 'restaurant') {
                entityBadge = `<span class="badge badge-warning" style="font-size: 0.72rem;">RESTAURANT</span>`;
            } else if (log.entity_type === 'order') {
                entityBadge = `<span class="badge badge-info" style="font-size: 0.72rem;">COMMANDE</span>`;
            } else if (log.entity_type === 'subscription') {
                entityBadge = `<span class="badge badge-success" style="font-size: 0.72rem;">ABONNEMENT</span>`;
            }

            return `
                <tr style="border-bottom: 1px solid var(--border-color, #f1f5f9);">
                    <td style="padding: 0.75rem 0.5rem; font-size: 0.78rem; color: var(--text-secondary); white-space: nowrap; font-family: monospace;">${dateStr}</td>
                    <td style="padding: 0.75rem 0.5rem;">${actorBadge}</td>
                    <td style="padding: 0.75rem 0.5rem;">${entityBadge}</td>
                    <td style="padding: 0.75rem 0.5rem; font-size: 0.85rem; font-weight: 700; color: var(--text-primary);">${log.action}</td>
                    <td style="padding: 0.75rem 0.5rem; font-size: 0.82rem; color: var(--text-secondary); max-width: 320px;">${log.details || '-'}</td>
                    <td style="padding: 0.75rem 0.5rem; font-size: 0.72rem; color: var(--text-secondary); font-family: monospace;">${log.ip_address || '127.0.0.1'}</td>
                </tr>
            `;
        }).join('');

        container.innerHTML = `
            <table class="table" style="width: 100%; border-collapse: collapse; text-align: left;">
                <thead>
                    <tr style="border-bottom: 2px solid var(--border-color, #e2e8f0); color: var(--text-secondary); font-size: 0.75rem; text-transform: uppercase; letter-spacing: 0.5px;">
                        <th style="padding: 0.6rem 0.5rem;">Horodatage</th>
                        <th style="padding: 0.6rem 0.5rem;">Acteur</th>
                        <th style="padding: 0.6rem 0.5rem;">Entité</th>
                        <th style="padding: 0.6rem 0.5rem;">Action</th>
                        <th style="padding: 0.6rem 0.5rem;">Détails</th>
                        <th style="padding: 0.6rem 0.5rem;">IP</th>
                    </tr>
                </thead>
                <tbody>
                    ${rows}
                </tbody>
            </table>
        `;
    } catch (err) {
        container.innerHTML = `<div style="color: #dc2626; padding: 1rem; text-align: center;">Erreur de chargement du journal d'activité.</div>`;
    }
};

// Runner for 7-Day Trial Auto-Deactivation
window.runAutoDeactivateTrialAudit = async function() {
    const statusDiv = document.getElementById('auto-deactivate-status');
    if (statusDiv) {
        statusDiv.style.display = 'block';
        statusDiv.innerHTML = `<div style="color: #d97706; font-weight: 700; display: inline-flex; align-items: center; gap: 0.35rem;"><span class="spinner-ring" style="width:14px;height:14px;border-width:2px;"></span> Analyse des comptes restaurants en cours...</div>`;
    }

    try {
        const res = await fetch('/api/admin/restaurants/auto-deactivate', { method: 'POST' });
        const data = await res.json();
        
        if (data.success) {
            if (statusDiv) {
                statusDiv.innerHTML = `
                    <div style="background: rgba(34, 197, 94, 0.1); border: 1px solid #16a34a; border-radius: 8px; padding: 0.75rem; color: #16a34a; font-weight: 700;">
                        <i class='ri-check-line'></i> ${data.message}
                    </div>
                `;
            }
            showToast(data.message, "info");
            // Refresh store & audit logs
            if (store && store.syncFromSupabase) store.syncFromSupabase();
            if (window.loadAdminActivityLogs) window.loadAdminActivityLogs();
        }
    } catch (e) {
        if (statusDiv) {
            statusDiv.innerHTML = `<div style="color: #dc2626;">Erreur lors de l'exécution de l'audit.</div>`;
        }
    }
};

// ----------------------------------------------------
// BACKUP & RESTORATION HANDLERS FOR SUPER-ADMIN
// ----------------------------------------------------
window.exportPlatformBackupAdmin = function() {
    const feedback = document.getElementById('backup-action-feedback');
    try {
        if (store && typeof store.exportPlatformBackup === 'function') {
            store.exportPlatformBackup();
            if (feedback) {
                feedback.style.display = 'block';
                feedback.style.background = 'rgba(16, 185, 129, 0.12)';
                feedback.style.color = '#059669';
                feedback.innerHTML = '<i class="checkbox-circle-line"></i> Instantané de sauvegarde JSON généré et téléchargé avec succès.';
            }
            showToast("Sauvegarde exportée avec succès !", "success");
        } else {
            showToast("Module de sauvegarde indisponible", "danger");
        }
    } catch (err) {
        console.error("Erreur export sauvegarde:", err);
        showToast("Erreur lors de l'export de la sauvegarde", "danger");
    }
};

window.importPlatformBackupAdmin = async function(event) {
    const file = event.target.files && event.target.files[0];
    if (!file) return;

    const feedback = document.getElementById('backup-action-feedback');
    if (feedback) {
        feedback.style.display = 'block';
        feedback.style.background = 'rgba(14, 165, 233, 0.12)';
        feedback.style.color = '#0284c7';
        feedback.innerHTML = 'Lecture et vérification du fichier de sauvegarde...';
    }

    try {
        const text = await file.text();
        const res = await store.importPlatformBackup(text);
        if (res.success) {
            if (feedback) {
                feedback.style.background = 'rgba(16, 185, 129, 0.12)';
                feedback.style.color = '#059669';
                feedback.innerHTML = `<i class='ri-checkbox-circle-line'></i> ${res.message}`;
            }
            showToast(res.message, "success");
            setTimeout(() => {
                renderAdminView();
            }, 500);
        } else {
            if (feedback) {
                feedback.style.background = 'rgba(239, 68, 68, 0.12)';
                feedback.style.color = '#dc2626';
                feedback.innerHTML = `<i class='ri-close-circle-line'></i> ${res.message}`;
            }
            showToast(res.message, "danger");
        }
    } catch (err) {
        if (feedback) {
            feedback.style.background = 'rgba(239, 68, 68, 0.12)';
            feedback.style.color = '#dc2626';
            feedback.innerHTML = `<i class='ri-close-circle-line'></i> Erreur lecture du fichier: ${err.message}`;
        }
        showToast("Erreur lors du traitement du fichier JSON", "danger");
    } finally {
        event.target.value = '';
    }
};

window.triggerFullCloudSyncAdmin = async function() {
    const feedback = document.getElementById('backup-action-feedback');
    if (feedback) {
        feedback.style.display = 'block';
        feedback.style.background = 'rgba(14, 165, 233, 0.12)';
        feedback.style.color = '#0284c7';
        feedback.innerHTML = 'Synchronisation vers Supabase et le Cloud en cours...';
    }

    try {
        if (store && typeof store.forceFullSync === 'function') {
            const res = await store.forceFullSync();
            if (feedback) {
                feedback.style.background = 'rgba(16, 185, 129, 0.12)';
                feedback.style.color = '#059669';
                feedback.innerHTML = '<i class="checkbox-circle-line"></i> Données synchronisées avec succès vers Supabase & Cloud.';
            }
            showToast("Synchronisation Cloud terminée !", "success");
        }
    } catch (err) {
        if (feedback) {
            feedback.style.background = 'rgba(245, 158, 11, 0.12)';
            feedback.style.color = '#d97706';
            feedback.innerHTML = '<i class="alert-line"></i> Synchronisation locale réussie. Connectivité Cloud surveillée.';
        }
        showToast("Synchronisation locale effectuée", "info");
    }
};

// ----------------------------------------------------
// SUPABASE & DATABASE CONFIGURATION HANDLERS
// ----------------------------------------------------
window.runTestSupabaseConnection = async function() {
    const feedback = document.getElementById('supabase-test-feedback');
    const badge = document.getElementById('supabase-live-badge');
    
    if (feedback) {
        feedback.style.display = 'block';
        feedback.style.background = 'rgba(14, 165, 233, 0.12)';
        feedback.style.color = '#0284c7';
        feedback.innerHTML = '<i class="loader-4-line ri-spin"></i> Test de la connexion Supabase en cours...';
    }

    try {
        const res = await (window.testSupabaseConnection ? window.testSupabaseConnection() : { success: true, latency: 45, message: "Connexion Supabase active." });
        if (res.success) {
            if (feedback) {
                feedback.style.background = 'rgba(16, 185, 129, 0.12)';
                feedback.style.color = '#059669';
                feedback.innerHTML = `<i class='ri-checkbox-circle-line'></i> ${res.message}`;
            }
            if (badge) {
                badge.style.background = 'rgba(16, 185, 129, 0.15)';
                badge.style.color = '#10b981';
                badge.innerHTML = `<i class='ri-checkbox-circle-line'></i> Connecté (${res.latency || 40}ms)`;
            }
            showToast("Connexion Supabase validée !", "success");
        } else {
            if (feedback) {
                feedback.style.background = 'rgba(239, 68, 68, 0.12)';
                feedback.style.color = '#dc2626';
                feedback.innerHTML = `<i class='ri-close-circle-line'></i> ${res.message}`;
            }
            if (badge) {
                badge.style.background = 'rgba(239, 68, 68, 0.15)';
                badge.style.color = '#dc2626';
                badge.innerHTML = `<i class='ri-error-warning-line'></i> Échec`;
            }
            showToast(res.message, "danger");
        }
    } catch (e) {
        if (feedback) {
            feedback.style.background = 'rgba(239, 68, 68, 0.12)';
            feedback.style.color = '#dc2626';
            feedback.innerHTML = `<i class='ri-close-circle-line'></i> Erreur : ${e.message}`;
        }
        showToast("Erreur lors du test Supabase", "danger");
    }
};

window.handleSaveSupabaseConfig = function(event) {
    event.preventDefault();
    const url = document.getElementById('supabase-url-input')?.value;
    const key = document.getElementById('supabase-key-input')?.value;
    const feedback = document.getElementById('supabase-test-feedback');

    if (!url || !key) {
        showToast("Veuillez renseigner l'URL et la clé Supabase.", "warning");
        return;
    }

    if (window.setSupabaseConfig) {
        window.setSupabaseConfig(url, key);
        if (feedback) {
            feedback.style.display = 'block';
            feedback.style.background = 'rgba(16, 185, 129, 0.12)';
            feedback.style.color = '#059669';
            feedback.innerHTML = '<i class="checkbox-circle-line"></i> Paramètres de connexion Supabase enregistrés et client réinitialisé avec succès.';
        }
        showToast("Configuration Supabase mise à jour !", "success");
        window.runTestSupabaseConnection();
    }
};

window.handleResetSupabaseDefault = function() {
    if (window.resetSupabaseConfigToDefault) {
        window.resetSupabaseConfigToDefault();
        const conf = window.getSupabaseConfig();
        const urlInput = document.getElementById('supabase-url-input');
        const keyInput = document.getElementById('supabase-key-input');
        if (urlInput) urlInput.value = conf.url;
        if (keyInput) keyInput.value = conf.key;
        showToast("Identifiants Supabase restaurés par défaut.", "info");
        window.runTestSupabaseConnection();
    }
};

window.checkCloudSqlStatus = async function() {
    try {
        const res = await fetch('/api/db/status');
        const data = await res.json();
        if (data.success) {
            const restosCount = data.database?.restaurantsCount || 0;
            const ordersCount = data.database?.ordersCount || 0;
            const isReady = data.database?.readyForScale?.isReady;
            
            showToast(`Base PostgreSQL : Connectée (${restosCount} restaurants, ${ordersCount} commandes). Prête 300 clients : ${isReady ? 'OUI' : 'PARTIEL'}`, "success");
            
            const countEl = document.getElementById('db-stat-restos');
            if (countEl) countEl.innerText = `${restosCount} / 30 Restaurants`;
        } else {
            showToast("Erreur lecture état Cloud SQL", "danger");
        }
    } catch (e) {
        showToast("Vérification Cloud SQL impossible", "warning");
    }
};

window.handleReseed30Restaurants = async function() {
    const feedback = document.getElementById('backup-action-feedback');
    if (feedback) {
        feedback.style.display = 'block';
        feedback.style.background = 'rgba(14, 165, 233, 0.12)';
        feedback.style.color = '#0284c7';
        feedback.innerHTML = 'Réinitialisation des 30 restaurants de Thiès dans PostgreSQL...';
    }

    try {
        const res = await fetch('/api/db/seed', { method: 'POST' });
        const data = await res.json();
        if (data.success) {
            if (feedback) {
                feedback.style.background = 'rgba(16, 185, 129, 0.12)';
                feedback.style.color = '#059669';
                feedback.innerHTML = `<i class='ri-checkbox-circle-line'></i> ${data.message} (${data.count} restaurants actifs).`;
            }
            showToast(data.message, "success");
            if (store && store.syncFromSupabase) store.syncFromSupabase();
            setTimeout(() => {
                renderAdminView();
            }, 800);
        } else {
            showToast("Erreur lors de la réinitialisation", "danger");
        }
    } catch (e) {
        showToast("Erreur réseau réinitialisation", "danger");
    }
};

function handleAdminCreateRestaurant(e) {
    e.preventDefault();
    
    const name = document.getElementById('adm-reg-name').value.trim();
    const address = document.getElementById('adm-reg-address').value.trim();
    const category = document.getElementById('adm-reg-category').value;
    const whatsapp = cleanPhoneNumber(document.getElementById('adm-reg-whatsapp').value.trim());
    const openH = document.getElementById('adm-reg-open').value;
    const closeH = document.getElementById('adm-reg-close').value;
    const username = document.getElementById('adm-reg-username').value.trim().toLowerCase();
    const password = document.getElementById('adm-reg-password').value;
    
    if (!/^\+221(70|75|76|77|78)\d{7}$/.test(whatsapp.replace(/\s+/g, ''))) {
        showToast("Numéro WhatsApp invalide (ex: +221 77 XXX XX XX)", "danger");
        return;
    }

    // Check availability
    const exists = store.getRestaurants().find(r => r.username === username || r.slug === username);
    if (exists) {
        showToast("Cet identifiant est déjà utilisé", "danger");
        return;
    }

    const newId = "r" + (store.getRestaurants().length + 1);
    const slug = username.replace(/[^a-z0-9]/g, '-');
    
    const newResto = {
        id: newId,
        name,
        slug,
        rating: 5.0,
        reviewsCount: 0,
        category,
        address,
        whatsapp,
        openHours: `${openH} - ${closeH}`,
        closedDays: [],
        isOpenManual: true,
        status: "active",
        username,
        password,
        menu: [],
        reviews: []
    };

    store.addRestaurant(newResto);
    showToast(`Restaurant "${name}" ajouté avec succès dans le réseau !`, "success");
    
    switchAdminTab('active');
}

// Admin actions
async function approveRestaurant(id) {
    const r = store.getRestaurantById(id);
    if (!r) return;
    
    store.updateRestaurant(id, { status: "active" });
    
    try {
        await fetch('/api/admin/restaurants/approve', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ restaurantId: id })
        });
    } catch (e) {
        console.warn("Approve server notice:", e);
    }

    showToast(`Restaurant ${r.name} activé avec succès !`, "success");
    
    // Create WhatsApp confirmation message
    const waText = `Bonjour ${r.name}, nous avons le plaisir de vous informer que votre inscription sur THIES Resto a été validée par notre équipe ! 

Vous pouvez dès à présent vous connecter à votre Tableau de Bord avec vos identifiants pour gérer vos plats du jour, commandes et réservations.

Lien d'accès : ${window.location.origin}${window.location.pathname}#/auth

Bienvenue dans le réseau !`;
    const waLink = `https://wa.me/${r.whatsapp.replace(/\+/g, '')}?text=${encodeURIComponent(waText)}`;
    
    renderAdminView();
    window.open(waLink, '_blank');
}

function rejectRestaurant(id) {
    const r = store.getRestaurantById(id);
    if (!r) return;
    
    if (confirm(`Voulez-vous rejeter et supprimer définitivement la demande de "${r.name}" ?`)) {
        store.deleteRestaurant(id);
        showToast("Demande supprimée", "info");
        renderAdminView();
    }
}

async function suspendRestaurant(id) {
    console.group(`[SuperAdmin] Suspension du restaurant ID: "${id}"`);
    const r = store.getRestaurantById(id);
    if (!r) {
        console.error(`[SuperAdmin] Restaurant ID "${id}" introuvable dans le Store.`);
        console.groupEnd();
        return;
    }
    
    console.log(`[SuperAdmin] Suspension de "${r.name}" (${id}). Mise à jour locale optimiste...`);
    store.updateRestaurant(id, { 
        status: "suspended", 
        suspendReason: 'Suspension manuelle SuperAdmin',
        suspendedAt: new Date().toISOString()
    });

    // Real-time Firestore direct synchronization to trigger onSnapshot on all client instances
    if (typeof window.updateFirestoreRestaurantStatus === 'function') {
        window.updateFirestoreRestaurantStatus(id, 'suspended', 'Suspension manuelle SuperAdmin').catch(err => {
            console.warn("[SuperAdmin] Notice synchro Firestore client:", err);
        });
    }

    try {
        console.log(`[SuperAdmin] Envoi requête POST /api/admin/restaurants/suspend...`);
        const resp = await fetch('/api/admin/restaurants/suspend', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ restaurantId: id, reason: 'Suspension manuelle SuperAdmin' })
        });
        const data = await resp.json().catch(() => ({}));
        console.log(`[SuperAdmin] Réponse serveur suspend:`, data);

        if (typeof store.reFetchRestaurants === 'function') {
            await store.reFetchRestaurants();
            console.log(`[SuperAdmin] Re-fetch de la liste effectué après suspension.`);
        }
    } catch (e) {
        console.warn("[SuperAdmin] Exception lors de la suspension côté serveur:", e);
    }

    showToast(`Restaurant ${r.name} suspendu temporairement`, "warning");
    renderAdminView();
    console.groupEnd();
}

async function reactivateRestaurant(id) {
    console.group(`[SuperAdmin] Réactivation du restaurant ID: "${id}"`);
    console.log(`[SuperAdmin] Étape 1/5: Recherche du restaurant dans le Store local...`);
    const r = store.getRestaurantById(id);
    if (!r) {
        console.error(`[SuperAdmin] Erreur: Restaurant avec l'identifiant "${id}" introuvable dans le Store.`);
        showToast("Restaurant introuvable", "error");
        console.groupEnd();
        return;
    }
    
    console.log(`[SuperAdmin] Restaurant identifié: "${r.name}" (${r.id}) - Statut actuel: "${r.status}", Pack: "${r.subscriptionPack || 'Aucun'}"`);

    // 1. Optimistic local update with explicit reset of trial lock
    const nowIso = new Date().toISOString();
    console.log(`[SuperAdmin] Étape 2/5: Mise à jour optimiste du Store local...`);
    store.updateRestaurant(id, {
        status: "active",
        hasPaidSubscription: true,
        createdAt: nowIso,
        approvedAt: nowIso,
        suspendReason: null,
        suspendedAt: null
    });
    console.log(`[SuperAdmin] Store local mis à jour: statut='active', hasPaidSubscription=true, createdAt='${nowIso}'.`);

    // Real-time Firestore direct synchronization to trigger onSnapshot on all client instances
    if (typeof window.updateFirestoreRestaurantStatus === 'function') {
        window.updateFirestoreRestaurantStatus(id, 'active').catch(err => {
            console.warn("[SuperAdmin] Notice synchro Firestore client reactivate:", err);
        });
    }

    try {
        // 2. Call server/database endpoint
        console.log(`[SuperAdmin] Étape 3/5: Envoi de la requête de réactivation POST /api/admin/restaurants/reactivate...`);
        const response = await fetch('/api/admin/restaurants/reactivate', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ 
                restaurantId: id,
                slug: r.slug,
                username: r.username,
                name: r.name
            })
        });

        console.log(`[SuperAdmin] Statut de réponse HTTP reçu: ${response.status} (${response.statusText})`);

        if (!response.ok) {
            const errPayload = await response.json().catch(() => ({}));
            console.error(`[SuperAdmin] Échec serveur lors de la réactivation:`, errPayload);
            showToast(errPayload.message || "Erreur serveur lors de la réactivation.", "error");
            console.groupEnd();
            return;
        }

        const data = await response.json();
        console.log(`[SuperAdmin] Étape 4/5: Confirmation de persistance reçue de la base de données:`, data);

        // 3. Trigger immediate re-fetch of the restaurant list from database upon success
        console.log(`[SuperAdmin] Étape 5/5: Déclenchement du re-fetch de la liste des restaurants depuis la base de données...`);
        if (typeof store.reFetchRestaurants === 'function') {
            await store.reFetchRestaurants();
            console.log(`[SuperAdmin] Re-fetch terminé avec succès via store.reFetchRestaurants().`);
        } else if (typeof store.syncLiveServerData === 'function') {
            await store.syncLiveServerData();
            console.log(`[SuperAdmin] Re-fetch terminé avec succès via store.syncLiveServerData().`);
        }

        // Verify updated status in store
        const updatedResto = store.getRestaurantById(id);
        console.log(`[SuperAdmin] Vérification post-sync: restaurant "${updatedResto?.name}" statut = "${updatedResto?.status}".`);

        showToast(`Restaurant "${r.name}" réactivé avec succès !`, "success");
    } catch (e) {
        console.error(`[SuperAdmin] Exception réseau ou serveur lors de la réactivation:`, e);
        showToast("Erreur réseau lors de la communication avec le serveur", "error");
    } finally {
        console.log(`[SuperAdmin] Rafraîchissement de l'interface d'administration...`);
        renderAdminView();
        console.groupEnd();
    }
}

window.toggleAdminPasswordDisplay = function(restoId, realPassword) {
    const textEl = document.getElementById(`pwd-text-${restoId}`);
    const iconEl = document.getElementById(`pwd-icon-${restoId}`);
    if (!textEl || !iconEl) return;
    if (textEl.textContent === '••••••••') {
        textEl.textContent = realPassword;
        iconEl.className = 'ri-eye-line';
    } else {
        textEl.textContent = '••••••••';
        iconEl.className = 'ri-eye-off-line';
    }
};

window.updateRestaurantPack = function(id, packName) {
    const r = store.getRestaurantById(id);
    if (!r) return;
    
    // Si on attribue un pack payant, le restaurant doit être réactivé
    const newStatus = r.status === 'suspended' && packName !== 'Aucun (Gratuit)' ? 'active' : r.status;
    
    store.updateRestaurant(id, { subscriptionPack: packName, status: newStatus });
    showToast(`Pack ${packName} attribué à ${r.name}`, "success");
    renderAdminView();
};

window.deleteRestaurantAdmin = function(id) {
    const r = store.getRestaurantById(id);
    if (!r) return;
    if (confirm(`Êtes-vous sûr de vouloir supprimer définitivement le restaurant "${r.name}" du réseau THIES Resto ? Cette action est irréversible.`)) {
        store.deleteRestaurant(id);
        showToast(`Restaurant "${r.name}" supprimé avec succès`, "info");
        renderAdminView();
    }
};

function impersonateRestaurant(id) {
    const r = store.getRestaurantById(id);
    if (!r) return;
    
    currentRestaurantSession = r;
    sessionStorage.setItem('restaurantSession', JSON.stringify(r));
    showToast(`Session administrateur activée pour "${r.name}"`, "success");
    router.navigate('/dashboard');
}

function exitImpersonation() {
    currentRestaurantSession = null;
    sessionStorage.removeItem('restaurantSession');
    showToast("Retour à la console Super-Admin", "info");
    router.navigate('/admin');
}

window.approveRestaurant = approveRestaurant;
window.rejectRestaurant = rejectRestaurant;
window.suspendRestaurant = suspendRestaurant;
window.reactivateRestaurant = reactivateRestaurant;
window.impersonateRestaurant = impersonateRestaurant;
window.exitImpersonation = exitImpersonation;

async function adminDeleteOrder(orderId) {
    if (!orderId) return;
    if (!confirm(`Confirmez-vous la suppression définitive de la commande ${orderId} ?`)) {
        return;
    }
    try {
        await store.deleteOrder(orderId);
        showToast(`Commande ${orderId} supprimée`, "info");
        renderAdminTabTable();
    } catch (e) {
        showToast("Erreur lors de la suppression de la commande", "error");
    }
}

async function adminPurgeTestOrders() {
    const ordersCount = (store.data.orders || []).length;
    if (ordersCount === 0) {
        showToast("Aucune commande à purger.", "info");
        return;
    }
    if (!confirm(`Attention : Voulez-vous vraiment purger les ${ordersCount} commande(s) enregistrée(s) pour démarrer à zéro pour le lancement officiel ?`)) {
        return;
    }
    try {
        await store.purgeTestOrders();
        showToast("Base de commandes nettoyée. Prête pour le lancement !", "success");
        renderAdminTabTable();
    } catch (e) {
        showToast("Erreur lors du nettoyage des commandes", "error");
    }
}

window.adminDeleteOrder = adminDeleteOrder;
window.adminPurgeTestOrders = adminPurgeTestOrders;


function exportOrdersToCSV(targetRestoId) {
    const id = targetRestoId || (currentRestaurantSession && currentRestaurantSession.id);
    const r = store.getRestaurantById(id);
    if (!r) return;
    const orders = store.getOrdersByRestaurant(r.id);
    if (orders.length === 0) {
        showToast("Aucune commande à exporter", "warning");
        return;
    }
    
    let csvContent = "\ufeff"; // BOM for Excel UTF-8 support
    csvContent += "ID Commande;Date;Heure;Client;Telephone;Mode de Recuperation;Total (FCFA);Statut;Plats;Note\n";
    
    orders.forEach(o => {
        const dishesList = (o.items || []).map(i => `${i.name} (x${i.qty})`).join(', ');
        const client = (o.customerName || '').replace(/"/g, '""');
        const phone = o.customerPhone || '';
        const note = (o.note || '').replace(/"/g, '""').replace(/\n/g, ' ');
        const row = [
            o.id,
            o.date || '',
            o.time || '',
            `"${client}"`,
            `"${phone}"`,
            o.mode || 'Livraison',
            o.total || 0,
            o.status || 'En attente',
            `"${dishesList.replace(/"/g, '""')}"`,
            `"${note}"`
        ].join(';');
        csvContent += row + "\n";
    });
    
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const encodedUrl = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUrl);
    link.setAttribute("download", `donnees_commandes_${r.slug || r.id}_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    showToast("Données des commandes exportées en CSV !", "success");
}

window.exportOrdersCSV = exportOrdersToCSV;
window.exportOrdersToCSV = exportOrdersToCSV;

window.printRestaurantOrdersPDF = function(targetRestoId) {
    const id = targetRestoId || (currentRestaurantSession && currentRestaurantSession.id);
    const r = store.getRestaurantById(id);
    if (!r) return;
    const orders = store.getOrdersByRestaurant(r.id);
    const completed = orders.filter(o => o.status === 'Livrée' || o.status === 'completed' || o.status === 'delivered');
    const totalRev = completed.reduce((sum, o) => sum + (Number(o.total) || 0), 0);

    let rowsHtml = '';
    orders.forEach((o, idx) => {
        const dishesList = (o.items || []).map(i => `${i.name} (x${i.qty})`).join(', ');
        rowsHtml += `
            <tr>
                <td style="padding: 6px 8px; border: 1px solid #ddd; text-align: center;">${idx + 1}</td>
                <td style="padding: 6px 8px; border: 1px solid #ddd; font-family: monospace;">#${o.id.slice(-6)}</td>
                <td style="padding: 6px 8px; border: 1px solid #ddd;">${o.date || '-'} ${o.time || ''}</td>
                <td style="padding: 6px 8px; border: 1px solid #ddd; font-weight: bold;">${o.customerName || 'Client'}</td>
                <td style="padding: 6px 8px; border: 1px solid #ddd;">${o.customerPhone || '-'}</td>
                <td style="padding: 6px 8px; border: 1px solid #ddd;">${dishesList}</td>
                <td style="padding: 6px 8px; border: 1px solid #ddd; text-align: right; font-weight: bold;">${(Number(o.total) || 0).toLocaleString()} F</td>
                <td style="padding: 6px 8px; border: 1px solid #ddd; text-align: center;">${o.status || '-'}</td>
            </tr>
        `;
    });

    const printContainer = document.createElement('div');
    printContainer.id = 'pure-data-resto-print-container';
    printContainer.style.position = 'fixed';
    printContainer.style.inset = '0';
    printContainer.style.background = '#ffffff';
    printContainer.style.color = '#111827';
    printContainer.style.zIndex = '999999';
    printContainer.style.overflow = 'auto';
    printContainer.style.padding = '2rem';
    printContainer.style.fontFamily = 'system-ui, -apple-system, sans-serif';

    printContainer.innerHTML = `
        <div style="max-width: 900px; margin: 0 auto;">
            <div style="display: flex; justify-content: space-between; align-items: flex-start; border-bottom: 2px solid #111827; padding-bottom: 1rem; margin-bottom: 1.5rem;">
                <div>
                    <h1 style="margin: 0; font-size: 20px; font-weight: 900; color: #F26B21;">${r.name.toUpperCase()} — JOURNAL DES COMMANDES</h1>
                    <p style="margin: 4px 0 0 0; font-size: 12px; color: #4B5563;">${r.address || 'Thiès'} • Catégorie : ${r.category || 'Restaurant'}</p>
                </div>
                <div style="text-align: right;">
                    <div style="font-size: 12px; font-weight: bold;">Données Brutes d'Exploitation</div>
                    <div style="font-size: 11px; color: #6B7280;">Généré le : ${new Date().toLocaleDateString('fr-FR')}</div>
                </div>
            </div>

            <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 12px; margin-bottom: 1.5rem;">
                <div style="border: 1px solid #E5E7EB; border-radius: 6px; padding: 10px; background: #F9FAFB;">
                    <div style="font-size: 10px; text-transform: uppercase; color: #6B7280; font-weight: bold;">Chiffre d'Affaires Réalisé</div>
                    <div style="font-size: 16px; font-weight: 900; color: #059669; margin-top: 2px;">${totalRev.toLocaleString()} FCFA</div>
                </div>
                <div style="border: 1px solid #E5E7EB; border-radius: 6px; padding: 10px; background: #F9FAFB;">
                    <div style="font-size: 10px; text-transform: uppercase; color: #6B7280; font-weight: bold;">Commandes Livrées</div>
                    <div style="font-size: 16px; font-weight: 900; color: #111827; margin-top: 2px;">${completed.length} sur ${orders.length}</div>
                </div>
                <div style="border: 1px solid #E5E7EB; border-radius: 6px; padding: 10px; background: #F9FAFB;">
                    <div style="font-size: 10px; text-transform: uppercase; color: #6B7280; font-weight: bold;">Panier Moyen</div>
                    <div style="font-size: 16px; font-weight: 900; color: #2563EB; margin-top: 2px;">${completed.length > 0 ? Math.round(totalRev / completed.length).toLocaleString() : 0} FCFA</div>
                </div>
            </div>

            <table style="width: 100%; border-collapse: collapse; font-size: 11px; margin-bottom: 2rem;">
                <thead>
                    <tr style="background: #F3F4F6;">
                        <th style="padding: 6px 8px; border: 1px solid #ddd; width: 30px;">#</th>
                        <th style="padding: 6px 8px; border: 1px solid #ddd; text-align: left;">Réf.</th>
                        <th style="padding: 6px 8px; border: 1px solid #ddd; text-align: left;">Date &amp; Heure</th>
                        <th style="padding: 6px 8px; border: 1px solid #ddd; text-align: left;">Client</th>
                        <th style="padding: 6px 8px; border: 1px solid #ddd; text-align: left;">Téléphone</th>
                        <th style="padding: 6px 8px; border: 1px solid #ddd; text-align: left;">Détail Plats</th>
                        <th style="padding: 6px 8px; border: 1px solid #ddd; text-align: right;">Total</th>
                        <th style="padding: 6px 8px; border: 1px solid #ddd; text-align: center;">Statut</th>
                    </tr>
                </thead>
                <tbody>
                    ${rowsHtml || '<tr><td colspan="8" style="text-align: center; padding: 10px; border: 1px solid #ddd; color: #6B7280;">Aucune commande enregistrée</td></tr>'}
                </tbody>
            </table>

            <div id="resto-print-controls" style="display: flex; gap: 10px; justify-content: flex-end; padding-top: 1rem; border-top: 1px solid #E5E7EB;">
                <button onclick="document.getElementById('pure-data-resto-print-container').remove()" style="padding: 8px 16px; background: #E5E7EB; border: none; border-radius: 6px; font-weight: bold; cursor: pointer;">
                    Fermer
                </button>
                <button onclick="window.print()" style="padding: 8px 16px; background: #F26B21; color: white; border: none; border-radius: 6px; font-weight: bold; cursor: pointer;">
                    <i class='ri-printer-line'></i>️ Imprimer / Enregistrer en PDF
                </button>
            </div>
        </div>
    `;
    document.body.appendChild(printContainer);
};

function exportReservationsToCSV() {
    const r = store.getRestaurantById(currentRestaurantSession.id);
    if (!r) return;
    const reservations = store.getReservationsByRestaurant(r.id);
    if (reservations.length === 0) {
        showToast("Aucune réservation à exporter", "warning");
        return;
    }
    
    let csvContent = "\ufeff"; // BOM for Excel UTF-8 support
    csvContent += "ID Reservation;Date;Heure;Client;Telephone;Couverts;Statut;Note\n";
    
    reservations.forEach(res => {
        const client = res.customerName.replace(/"/g, '""');
        const phone = res.customerPhone;
        const note = (res.note || '').replace(/"/g, '""').replace(/\n/g, ' ');
        const row = [
            res.id,
            res.date,
            res.time,
            `"${client}"`,
            `"${phone}"`,
            res.guests,
            res.status,
            `"${note}"`
        ].join(';');
        csvContent += row + "\n";
    });

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const encodedUrl = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUrl);
    link.setAttribute("download", `reservations_${r.slug}_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    showToast("Fichier CSV des réservations téléchargé !", "success");
}

window.adminUpdateOrderStatus = async function(orderId, newStatus) {
    if (!orderId || !newStatus) return;
    try {
        await store.updateOrderStatus(orderId, newStatus);
        showToast(`Statut de la commande mis à jour : ${newStatus}`, "success");
        if (typeof renderAdminView === 'function') {
            renderAdminView();
        }
    } catch (err) {
        showToast("Erreur lors de la mise à jour du statut", "danger");
    }
};

window.adminSetOrdersFilter = function(filter) {
    window.adminOrdersFilter = filter;
    renderAdminTabTable();
};

window.adminSetOrdersSearch = function(query) {
    window.adminOrdersSearch = query.toLowerCase();
    renderAdminTabTable();
};

window.adminNotifyClientWhatsApp = function(orderId) {
    const orders = store.data.orders || [];
    const o = orders.find(ord => ord.id === orderId || String(ord.orderNumber) === String(orderId));
    if (!o) {
        showToast("Commande introuvable", "danger");
        return;
    }
    const cleanPhone = (o.customerPhone || '').replace(/\D/g, '');
    if (!cleanPhone) {
        showToast("Numéro de téléphone du client introuvable", "warning");
        return;
    }
    const restos = store.getRestaurants();
    const resto = restos.find(r => r.id === o.restaurantId);
    const restoName = resto ? resto.name : (o.restaurantName || "Thiès Resto");
    const num = o.orderNumber ? `#${o.orderNumber}` : (o.id || '');
    const clientName = o.customerName || "Cher client";
    const total = (Number(o.total) || 0).toLocaleString();

    let message = "";
    if (o.status === 'En cuisine') {
        message = `Bonjour ${clientName} <i class='ri-restaurant-line'></i>,\n\nBonne nouvelle ! Votre commande ${num} chez *${restoName}* est actuellement en cours de préparation en cuisine.\n\nMontant total : *${total} FCFA*\nElle sera prête très rapidement !`;
    } else if (o.status === 'Prêt pour livraison') {
        message = `Bonjour ${clientName} <i class='ri-inbox-archive-line'></i>,\n\nVotre commande ${num} chez *${restoName}* est prête et soigneusement emballée !\nLe livreur la prend en charge pour l'acheminement.`;
    } else if (o.status === 'En livraison') {
        message = `Bonjour ${clientName} <i class='ri-e-bike-2-line'></i>,\n\nVotre commande ${num} chez *${restoName}* est en cours d'acheminement vers votre adresse : *${o.customerAddress || 'Thiès'}*.\n\nMontant à régler : *${total} FCFA*.\nMerci pour votre confiance !`;
    } else if (o.status === 'Livrée' || o.status === 'completed' || o.status === 'delivered') {
        message = `Bonjour ${clientName} <i class='ri-sparkling-fill'></i>,\n\nVotre commande ${num} chez *${restoName}* a été livrée avec succès.\n\nToute l'équipe vous souhaite un très bon appétit et vous remercie pour votre confiance ! <i class='ri-star-fill'></i>`;
    } else if (o.status === 'Annulée' || o.status === 'cancelled') {
        message = `Bonjour ${clientName},\n\nNous vous informons que votre commande ${num} chez *${restoName}* a dû être annulée.\nVeuillez nous excuser pour ce désagrément.`;
    } else {
        // En attente / Reçue
        message = `Bonjour ${clientName} ,\n\nVotre commande ${num} chez *${restoName}* a bien été reçue par notre équipe.\nMontant total : *${total} FCFA*\n\nNous préparons votre commande au plus vite !`;
    }

    const formattedPhone = cleanPhone.startsWith('221') ? cleanPhone : '221' + cleanPhone;
    const whatsappUrl = `https://wa.me/${formattedPhone}?text=${encodeURIComponent(message)}`;
    window.open(whatsappUrl, '_blank');
    showToast("Alerte WhatsApp générée pour le client", "success");
};

window.adminDeleteOrder = async function(orderId) {
    if (!confirm("Êtes-vous sûr de vouloir supprimer définitivement cette commande ?")) return;
    try {
        if (typeof store.adminDeleteOrder === 'function') {
            await store.adminDeleteOrder(orderId);
        } else {
            store.data.orders = (store.data.orders || []).filter(o => o.id !== orderId);
            store.save();
        }
        showToast("Commande supprimée", "info");
        renderAdminTabTable();
    } catch (err) {
        showToast("Erreur lors de la suppression de la commande", "danger");
    }
};

window.handleAdminChangePassword = async function(e) {
    if (e && e.preventDefault) e.preventDefault();
    const newPass = document.getElementById('admin-new-password').value;
    const confirmPass = document.getElementById('admin-confirm-password').value;

    if (!newPass || newPass.length < 6) {
        showToast("Le mot de passe doit comporter au moins 6 caractères.", "danger");
        return;
    }
    if (newPass !== confirmPass) {
        showToast("Les deux mots de passe ne correspondent pas.", "danger");
        return;
    }

    try {
        localStorage.setItem('thies_super_admin_password', newPass);
        sessionStorage.setItem('admin_password', newPass);

        // Attempt Supabase sync if online client exists
        if (typeof supabaseClient !== 'undefined' && supabaseClient) {
            try {
                await supabaseClient
                    .from('admin_config')
                    .upsert({ key: 'super_admin_password', value: newPass, updated_at: new Date().toISOString() });
            } catch (supErr) {
                console.log("Admin pass Supabase update notice:", supErr);
            }
        }

        showToast("Mot de passe Super-Admin mis à jour avec succès !", "success");
        if (document.getElementById('admin-new-password')) document.getElementById('admin-new-password').value = '';
        if (document.getElementById('admin-confirm-password')) document.getElementById('admin-confirm-password').value = '';
    } catch (err) {
        showToast("Erreur lors de l'enregistrement du mot de passe", "danger");
    }
};

window.togglePassVisibility = function(inputId, btn) {
    const input = document.getElementById(inputId);
    if (!input) return;
    if (input.type === 'password') {
        input.type = 'text';
        btn.textContent = '<i class="lock-line"></i>';
    } else {
        input.type = 'password';
        btn.textContent = '<i class="eye-line"></i>️';
    }
};

// ==========================================
// PAYTECH & FINANCIAL REPORTING SYSTEM
// ==========================================

window.getPaytechTransactionsList = function() {
    let localTxs = [];
    try {
        localTxs = JSON.parse(localStorage.getItem('thies_paytech_transactions') || '[]');
    } catch (e) {
        localTxs = [];
    }

    // Async background sync with server
    if (!window._paytechSyncInProgress) {
        window._paytechSyncInProgress = true;
        fetch('/api/paytech/transactions')
            .then(res => res.json())
            .then(data => {
                window._paytechSyncInProgress = false;
                if (data && data.success && Array.isArray(data.transactions)) {
                    localStorage.setItem('thies_paytech_transactions', JSON.stringify(data.transactions));
                    if (adminActiveTab === 'accounting') {
                        // Re-render if accounting tab is visible
                        renderAdminTabTable();
                    }
                }
            })
            .catch(err => {
                window._paytechSyncInProgress = false;
            });
    }

    return localTxs;
};

// =========================================================================
// OFFICIAL PAYMENT LOGOS & BRANDING (Wave, Orange Money, Free Money, Visa/Mastercard, PayDunya)
// =========================================================================

window.getPaymentLogoSVG = function(brand, size = 22) {
    const b = (brand || '').toLowerCase();
    
    // Wave Sénégal Logo (Official Wave Senegal Cyan Emblem / App icon)
    if (b.includes('wave')) {
        return `
            <img src="/images/wave_senegal.png" alt="Wave Sénégal" width="${size}" height="${size}" style="vertical-align: middle; border-radius: 4px; object-fit: contain; flex-shrink: 0; box-shadow: 0 1px 3px rgba(0,0,0,0.12); display: inline-block;" title="Wave Sénégal">
        `;
    }
    
    // Orange Money Sénégal Logo (Official Orange Money Senegal Brand Icon)
    if (b.includes('orange') || b.includes('om')) {
        return `
            <img src="/images/orange_money_senegal.png" alt="Orange Money Sénégal" width="${size}" height="${size}" style="vertical-align: middle; border-radius: 4px; object-fit: contain; flex-shrink: 0; box-shadow: 0 1px 3px rgba(0,0,0,0.12); display: inline-block;" title="Orange Money Sénégal">
        `;
    }
    
    // Free Money Logo (Official Crimson Red #E21B24 with clean Free typography)
    if (b.includes('free')) {
        return `
            <svg width="${size}" height="${size}" viewBox="0 0 48 48" fill="none" style="vertical-align: middle; border-radius: 4px; flex-shrink: 0;" title="Free Money">
                <rect width="48" height="48" rx="8" fill="#E21B24"/>
                <text x="24" y="28" fill="#FFFFFF" font-size="14" font-weight="900" font-family="system-ui, sans-serif" text-anchor="middle" letter-spacing="-0.5">free</text>
                <circle cx="36" cy="14" r="2.5" fill="#FFD700"/>
            </svg>
        `;
    }
    
    // Carte Bancaire Visa / Mastercard Logo
    if (b.includes('visa') || b.includes('mastercard') || b.includes('carte') || b.includes('card')) {
        return `
            <svg width="${Math.round(size * 1.4)}" height="${size}" viewBox="0 0 54 36" fill="none" style="vertical-align: middle; border-radius: 4px; flex-shrink: 0;" title="Carte Visa / Mastercard">
                <rect width="54" height="36" rx="5" fill="#1A1F71"/>
                <circle cx="22" cy="18" r="9" fill="#EB001B" fill-opacity="0.95"/>
                <circle cx="32" cy="18" r="9" fill="#F79E1B" fill-opacity="0.92"/>
                <path d="M27 11.6A9 9 0 0 1 27 24.4A9 9 0 0 1 27 11.6Z" fill="#FF5F00"/>
                <rect x="5" y="6" width="9" height="3" rx="1.5" fill="#FFFFFF" opacity="0.6"/>
            </svg>
        `;
    }

    // PayDunya / PayTech Gateway Logo (Grouping Wave, Orange Money, Free Money and Card)
    if (b.includes('paydunya') || b.includes('paytech')) {
        return `
            <span style="display: inline-flex; align-items: center; gap: 4px; background: rgba(0,0,0,0.05); padding: 2px 6px; border-radius: 6px; border: 1px solid var(--border);" title="Passerelle Sécurisée (Wave Sénégal &amp; Orange Money)">
                <img src="/images/wave_senegal.png" alt="Wave" width="${Math.round(size * 0.85)}" height="${Math.round(size * 0.85)}" style="vertical-align: middle; border-radius: 3px; object-fit: contain;">
                <img src="/images/orange_money_senegal.png" alt="Orange Money" width="${Math.round(size * 0.85)}" height="${Math.round(size * 0.85)}" style="vertical-align: middle; border-radius: 3px; object-fit: contain;">
            </span>
        `;
    }

    // Default cash / generic icon
    return `<i class='ri-bank-card-line' style="font-size: ${size}px; color: var(--primary);"></i>`;
};

window.getPaymentBadgeHtml = function(channelName) {
    const raw = (channelName || 'PayDunya').trim();
    const low = raw.toLowerCase();

    if (low.includes('wave') && !low.includes('paydunya') && !low.includes('paytech')) {
        return `
            <span style="display: inline-flex; align-items: center; gap: 6px; background: rgba(29, 195, 236, 0.1); color: #0284c7; padding: 3px 8px; border-radius: 8px; font-weight: 700; font-size: 0.8rem; border: 1px solid rgba(29, 195, 236, 0.25);">
                ${window.getPaymentLogoSVG('wave', 18)}
                <span>Wave Sénégal</span>
            </span>
        `;
    }

    if (low.includes('orange') && !low.includes('paydunya') && !low.includes('paytech')) {
        return `
            <span style="display: inline-flex; align-items: center; gap: 6px; background: rgba(255, 121, 0, 0.1); color: #c2410c; padding: 3px 8px; border-radius: 8px; font-weight: 700; font-size: 0.8rem; border: 1px solid rgba(255, 121, 0, 0.25);">
                ${window.getPaymentLogoSVG('orange', 18)}
                <span>Orange Money</span>
            </span>
        `;
    }

    if (low.includes('free') && !low.includes('paydunya') && !low.includes('paytech')) {
        return `
            <span style="display: inline-flex; align-items: center; gap: 6px; background: rgba(226, 27, 36, 0.1); color: #b91c1c; padding: 3px 8px; border-radius: 8px; font-weight: 700; font-size: 0.8rem; border: 1px solid rgba(226, 27, 36, 0.25);">
                ${window.getPaymentLogoSVG('free', 18)}
                <span>Free Money</span>
            </span>
        `;
    }

    if (low.includes('carte') || low.includes('visa') || low.includes('mastercard')) {
        return `
            <span style="display: inline-flex; align-items: center; gap: 6px; background: rgba(26, 31, 113, 0.08); color: #1e3a8a; padding: 3px 8px; border-radius: 8px; font-weight: 700; font-size: 0.8rem; border: 1px solid rgba(26, 31, 113, 0.2);">
                ${window.getPaymentLogoSVG('visa', 16)}
                <span>Carte Bancaire</span>
            </span>
        `;
    }

    // PayDunya default or combined
    return `
        <span style="display: inline-flex; align-items: center; gap: 6px; background: rgba(16, 185, 129, 0.08); color: #047857; padding: 3px 8px; border-radius: 8px; font-weight: 700; font-size: 0.8rem; border: 1px solid rgba(16, 185, 129, 0.25);">
            ${window.getPaymentLogoSVG('paydunya', 16)}
            <span style="font-weight: 700;">PayDunya</span>
        </span>
    `;
};

window.openRecordPaytechModal = function(defaultRestoId = '') {
    const existingModal = document.getElementById('record-paytech-modal');
    if (existingModal) existingModal.remove();

    const restos = store.getRestaurants();
    let restoOptions = restos.map(r => `
        <option value="${r.id}" ${r.id === defaultRestoId ? 'selected' : ''}>${r.name} (${r.category || 'Restaurant'} - ${r.address || 'Thiès'})</option>
    `).join('');

    const modal = document.createElement('div');
    modal.id = 'record-paytech-modal';
    modal.className = 'modal-backdrop';
    modal.style.position = 'fixed';
    modal.style.inset = '0';
    modal.style.backgroundColor = 'rgba(0, 0, 0, 0.65)';
    modal.style.backdropFilter = 'blur(4px)';
    modal.style.display = 'flex';
    modal.style.alignItems = 'center';
    modal.style.justifyContent = 'center';
    modal.style.zIndex = '9999';
    modal.style.padding = '1rem';

    modal.innerHTML = `
        <div class="modal-card" style="background: var(--bg-card); border: 1px solid var(--border); border-radius: 20px; width: 100%; max-width: 540px; max-height: 90vh; overflow-y: auto; box-shadow: 0 20px 40px rgba(0,0,0,0.3); padding: 1.75rem; position: relative;">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1.25rem; border-bottom: 1px solid var(--border); padding-bottom: 0.85rem;">
                <div style="display: flex; align-items: center; gap: 0.6rem;">
                    <div style="width: 40px; height: 40px; border-radius: 10px; background: rgba(var(--primary-rgb), 0.12); color: var(--primary); display: flex; align-items: center; justify-content: center; font-size: 1.35rem;">
                        <i class='ri-bank-card-line'></i>
                    </div>
                    <div>
                        <h3 style="margin: 0; font-size: 1.15rem; color: var(--text-primary); font-weight: 800;">Encaisser un Abonnement SaaS</h3>
                        <p style="margin: 0.15rem 0 0 0; font-size: 0.78rem; color: var(--text-secondary);">Passerelle PayDunya &amp; Mobile Money (Wave, Orange, Free, Carte)</p>
                    </div>
                </div>
                <button type="button" onclick="document.getElementById('record-paytech-modal').remove()" style="background: var(--bg-secondary); border: 1px solid var(--border); width: 32px; height: 32px; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 1rem; cursor: pointer; color: var(--text-secondary);">
                    <i class='ri-close-line'></i>
                </button>
            </div>

            <form onsubmit="window.submitManualPaytechRecord(event)">
                <div class="form-group" style="margin-bottom: 1rem;">
                    <label class="form-label" style="font-weight: 700; font-size: 0.85rem;">Restaurant Bénéficiaire <span class="required" style="color:var(--danger);">*</span></label>
                    <select id="modal-paytech-resto" class="form-control" required style="font-weight: 600; padding: 0.65rem 0.85rem;" onchange="window.updatePaytechModalAmount()">
                        <option value="" disabled ${!defaultRestoId ? 'selected' : ''}>Sélectionnez un restaurant à Thiès...</option>
                        ${restoOptions}
                    </select>
                </div>

                <div class="form-group" style="margin-bottom: 1rem;">
                    <label class="form-label" style="font-weight: 700; font-size: 0.85rem;">Formule SaaS Souscrite <span class="required" style="color:var(--danger);">*</span></label>
                    <select id="modal-paytech-pack" class="form-control" required style="font-weight: 600; padding: 0.65rem 0.85rem;" onchange="window.updatePaytechModalAmount()">
                        <option value="Pack Standard">Pack Standard (9 000 FCFA / mois)</option>
                        <option value="Pack Entreprise">Pack Entreprise (15 000 FCFA / mois)</option>
                        <option value="Pack Annuel VIP">Pack Annuel VIP (100 000 FCFA / an)</option>
                    </select>
                </div>

                <div class="form-group" style="margin-bottom: 1rem;">
                    <label class="form-label" style="font-weight: 700; font-size: 0.85rem;">Montant Encaissé (FCFA) <span class="required" style="color:var(--danger);">*</span></label>
                    <input type="number" id="modal-paytech-amount" class="form-control" value="9000" required min="1000" step="500" style="font-weight: 800; font-size: 1.1rem; color: #10b981; padding: 0.65rem 0.85rem;">
                </div>

                <div class="form-group" style="margin-bottom: 1.25rem;">
                    <label class="form-label" style="font-weight: 700; font-size: 0.85rem; margin-bottom: 0.4rem; display: block;">Moyen / Passerelle de Paiement</label>
                    
                    <select id="modal-paytech-channel" class="form-control" style="font-weight: 600; padding: 0.65rem 0.85rem; margin-bottom: 0.6rem;" onchange="window.updateModalPaymentChannelPreview()">
                        <option value="PayDunya">Passerelle PayDunya (Wave, Orange Money, Free Money, Carte Visa / Mastercard)</option>
                        <option value="Wave Sénégal">Wave Sénégal</option>
                        <option value="Orange Money">Orange Money Sénégal</option>
                        <option value="Free Money">Free Money</option>
                        <option value="Carte Bancaire (Visa / Mastercard)">Carte Bancaire Visa / Mastercard</option>
                    </select>

                    <!-- Dynamic Visual Brand Logos Preview -->
                    <div id="modal-payment-logos-preview" style="background: var(--bg-secondary); border: 1px solid var(--border); border-radius: 10px; padding: 0.65rem 0.85rem; display: flex; align-items: center; justify-content: space-between; gap: 0.75rem;">
                        <span style="font-size: 0.8rem; color: var(--text-secondary); font-weight: 600;">Logos officiels validés :</span>
                        <div id="modal-payment-logos-container" style="display: flex; align-items: center; gap: 6px;">
                            ${window.getPaymentLogoSVG('wave', 22)}
                            ${window.getPaymentLogoSVG('orange', 22)}
                            ${window.getPaymentLogoSVG('free', 22)}
                            ${window.getPaymentLogoSVG('visa', 22)}
                        </div>
                    </div>
                </div>

                <div style="display: flex; gap: 0.75rem; justify-content: flex-end; border-top: 1px solid var(--border); padding-top: 1rem;">
                    <button type="button" class="btn btn-secondary" onclick="document.getElementById('record-paytech-modal').remove()" style="font-weight: 700; border-radius: 10px;">
                        Annuler
                    </button>
                    <button type="submit" class="btn btn-primary" style="font-weight: 800; border-radius: 10px; padding: 0.6rem 1.25rem; display: inline-flex; align-items: center; gap: 0.4rem;">
                        <i class='ri-check-line'></i> Valider et Enregistrer
                    </button>
                </div>
            </form>
        </div>
    `;

    document.body.appendChild(modal);
    window.updatePaytechModalAmount();
    window.updateModalPaymentChannelPreview();
};

window.updateModalPaymentChannelPreview = function() {
    const channelSelect = document.getElementById('modal-paytech-channel');
    const container = document.getElementById('modal-payment-logos-container');
    if (!channelSelect || !container) return;

    const val = channelSelect.value.toLowerCase();
    if (val.includes('wave') && !val.includes('paydunya')) {
        container.innerHTML = `${window.getPaymentLogoSVG('wave', 24)}`;
    } else if (val.includes('orange') && !val.includes('paydunya')) {
        container.innerHTML = `${window.getPaymentLogoSVG('orange', 24)}`;
    } else if (val.includes('free') && !val.includes('paydunya')) {
        container.innerHTML = `${window.getPaymentLogoSVG('free', 24)}`;
    } else if (val.includes('carte') || val.includes('visa')) {
        container.innerHTML = `${window.getPaymentLogoSVG('visa', 24)}`;
    } else {
        // PayDunya full bundle
        container.innerHTML = `
            ${window.getPaymentLogoSVG('wave', 22)}
            ${window.getPaymentLogoSVG('orange', 22)}
            ${window.getPaymentLogoSVG('free', 22)}
            ${window.getPaymentLogoSVG('visa', 22)}
        `;
    }
};

window.updatePaytechModalAmount = function() {
    const pack = document.getElementById('modal-paytech-pack');
    const amountInput = document.getElementById('modal-paytech-amount');
    if (!pack || !amountInput) return;

    if (pack.value === 'Pack Standard') amountInput.value = '9000';
    else if (pack.value === 'Pack Entreprise') amountInput.value = '15000';
    else if (pack.value === 'Pack Annuel VIP') amountInput.value = '100000';
};

window.submitManualPaytechRecord = async function(event) {
    if (event && event.preventDefault) event.preventDefault();

    const restoId = document.getElementById('modal-paytech-resto').value;
    const pack = document.getElementById('modal-paytech-pack').value;
    const amount = Number(document.getElementById('modal-paytech-amount').value) || 9000;
    const channel = document.getElementById('modal-paytech-channel').value;

    const resto = store.getRestaurantById(restoId);
    if (!resto) {
        showToast("Veuillez sélectionner un restaurant valide", "danger");
        return;
    }

    const payload = {
        orderId: `SUB-${resto.slug.toUpperCase()}-${Date.now().toString().slice(-6)}`,
        restaurantName: resto.name,
        restaurantPhone: resto.whatsapp || '',
        customerName: resto.name,
        customerPhone: resto.whatsapp || '',
        itemName: `Abonnement SaaS ${pack}`,
        amount: amount,
        paymentMethod: channel
    };

    try {
        // Post to backend
        await fetch('/api/paytech/record-subscription-success', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
        });

        // Also update local list
        let currentTxs = window.getPaytechTransactionsList();
        currentTxs.unshift({
            ...payload,
            date: new Date().toISOString(),
            status: 'PAID'
        });
        localStorage.setItem('thies_paytech_transactions', JSON.stringify(currentTxs));

        // Update restaurant pack in store
        store.updateRestaurant(resto.id, {
            subscriptionPack: pack,
            subscriptionPaidAt: new Date().toISOString(),
            hasPaidSubscription: true,
            status: 'active'
        });

        showToast(` Paiement de ${amount.toLocaleString()} FCFA enregistré pour ${resto.name} !`, "success");
        const modal = document.getElementById('record-paytech-modal');
        if (modal) modal.remove();

        renderAdminView();
    } catch (e) {
        console.error("Error recording paytech payment:", e);
        showToast("Erreur lors de l'enregistrement", "danger");
    }
};

// =========================================================================
// EXPORTS : DONNÉES PURES UNIQUEMENT (CSV & PDF)
// =========================================================================

window.exportPlatformFinancialReportCSV = function() {
    const allOrders = store.data.orders || [];
    const completedOrders = allOrders.filter(o => o.status === 'Livrée' || o.status === 'completed' || o.status === 'delivered');
    const paytechTxs = window.getPaytechTransactionsList().filter(t => t.status === 'PAID');
    const restos = store.getRestaurants();

    let csvContent = "\ufeff"; // BOM for Excel UTF-8
    csvContent += "ID;Restaurant;Categorie;Adresse;Statut;Pack SaaS;SaaS Encaisse (FCFA);Total Commandes;Commandes Livrees;Commandes Annulees;Taux Reussite;Panier Moyen (FCFA);Chiffre Affaires Brut (FCFA)\n";

    restos.forEach(r => {
        const restoOrders = allOrders.filter(o => o.restaurantId === r.id);
        const restoCompleted = restoOrders.filter(o => o.status === 'Livrée' || o.status === 'completed' || o.status === 'delivered');
        const restoCancelled = restoOrders.filter(o => o.status === 'Annulée' || o.status === 'cancelled');
        const revenue = restoCompleted.reduce((sum, o) => sum + (Number(o.total) || 0), 0);
        const avgCart = restoCompleted.length > 0 ? Math.round(revenue / restoCompleted.length) : 0;
        const successRate = restoOrders.length > 0 ? Math.round((restoCompleted.length / restoOrders.length) * 100) : 0;

        const restoTxs = paytechTxs.filter(t => 
            (t.restaurantName && r.name && t.restaurantName.toLowerCase() === r.name.toLowerCase()) || 
            (t.orderId && r.slug && t.orderId.toLowerCase().includes(r.slug.toLowerCase()))
        );
        const paytechTotal = restoTxs.reduce((sum, t) => sum + (Number(t.amount) || 0), 0);

        const row = [
            r.id,
            `"${(r.name || '').replace(/"/g, '""')}"`,
            `"${(r.category || '').replace(/"/g, '""')}"`,
            `"${(r.address || 'Thiès').replace(/"/g, '""')}"`,
            r.status,
            `"${r.subscriptionPack || 'Pack Standard'}"`,
            paytechTotal,
            restoOrders.length,
            restoCompleted.length,
            restoCancelled.length,
            `${successRate}%`,
            avgCart,
            revenue
        ].join(';');

        csvContent += row + "\n";
    });

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const encodedUrl = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUrl);
    link.setAttribute("download", `donnees_financieres_thies_resto_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    showToast("Données financières exportées en CSV avec succès !", "success");
};

window.exportPaytechSubscriptionsCSV = function() {
    const paytechTxs = window.getPaytechTransactionsList();
    if (paytechTxs.length === 0) {
        showToast("Aucune transaction à exporter", "warning");
        return;
    }

    let csvContent = "\ufeff"; // BOM for Excel UTF-8
    csvContent += "Reference;Restaurant;Pack Souscrit;Montant (FCFA);Moyen de Paiement;Date;Statut\n";

    paytechTxs.forEach(t => {
        const row = [
            t.orderId || '',
            `"${(t.restaurantName || t.customerName || '').replace(/"/g, '""')}"`,
            `"${(t.itemName || 'Abonnement').replace(/"/g, '""')}"`,
            t.amount || 0,
            `"${t.paymentMethod || 'PayDunya'}"`,
            t.date || '',
            t.status || 'PAID'
        ].join(';');
        csvContent += row + "\n";
    });

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const encodedUrl = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUrl);
    link.setAttribute("download", `donnees_abonnements_thies_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    showToast("Données des abonnements exportées en CSV !", "success");
};

// EXPORT PDF / IMPRESSION PURE DONNÉES (Sans capture d'écran, format tabulaire comptable propre)
window.exportPlatformFinancialReportPDF = function() {
    const allOrders = store.data.orders || [];
    const completedOrders = allOrders.filter(o => o.status === 'Livrée' || o.status === 'completed' || o.status === 'delivered');
    const paytechTxs = window.getPaytechTransactionsList().filter(t => t.status === 'PAID');
    const restos = store.getRestaurants();

    const totalCollected = paytechTxs.reduce((sum, t) => sum + (Number(t.amount) || 0), 0);
    const totalGmv = completedOrders.reduce((sum, o) => sum + (Number(o.total) || 0), 0);
    const dateStr = new Date().toLocaleDateString('fr-FR', { year: 'numeric', month: 'long', day: 'numeric', hour: '2-digit', minute: '2-digit' });

    let rowsHtml = '';
    restos.forEach((r, idx) => {
        const restoOrders = allOrders.filter(o => o.restaurantId === r.id);
        const restoCompleted = restoOrders.filter(o => o.status === 'Livrée' || o.status === 'completed' || o.status === 'delivered');
        const revenue = restoCompleted.reduce((sum, o) => sum + (Number(o.total) || 0), 0);
        const restoTxs = paytechTxs.filter(t => 
            (t.restaurantName && r.name && t.restaurantName.toLowerCase() === r.name.toLowerCase()) || 
            (t.orderId && r.slug && t.orderId.toLowerCase().includes(r.slug.toLowerCase()))
        );
        const paytechTotal = restoTxs.reduce((sum, t) => sum + (Number(t.amount) || 0), 0);

        rowsHtml += `
            <tr>
                <td style="padding: 6px 8px; border: 1px solid #ddd; text-align: center;">${idx + 1}</td>
                <td style="padding: 6px 8px; border: 1px solid #ddd; font-weight: bold;">${r.name}</td>
                <td style="padding: 6px 8px; border: 1px solid #ddd;">${r.category || 'Restaurant'}</td>
                <td style="padding: 6px 8px; border: 1px solid #ddd;">${r.address || 'Thiès'}</td>
                <td style="padding: 6px 8px; border: 1px solid #ddd;">${r.subscriptionPack || 'Pack Standard'}</td>
                <td style="padding: 6px 8px; border: 1px solid #ddd; text-align: right; font-weight: bold; color: #059669;">${paytechTotal.toLocaleString()} F</td>
                <td style="padding: 6px 8px; border: 1px solid #ddd; text-align: center;">${restoCompleted.length} / ${restoOrders.length}</td>
                <td style="padding: 6px 8px; border: 1px solid #ddd; text-align: right; font-weight: bold;">${revenue.toLocaleString()} F</td>
            </tr>
        `;
    });

    let txRowsHtml = '';
    paytechTxs.forEach((t, idx) => {
        txRowsHtml += `
            <tr>
                <td style="padding: 5px 8px; border: 1px solid #ddd; text-align: center;">${idx + 1}</td>
                <td style="padding: 5px 8px; border: 1px solid #ddd; font-family: monospace; font-size: 11px;">${t.orderId || '-'}</td>
                <td style="padding: 5px 8px; border: 1px solid #ddd; font-weight: bold;">${t.restaurantName || t.customerName || 'Restaurant'}</td>
                <td style="padding: 5px 8px; border: 1px solid #ddd;">${t.itemName || 'Abonnement SaaS'}</td>
                <td style="padding: 5px 8px; border: 1px solid #ddd; text-align: right; font-weight: bold; color: #059669;">${(Number(t.amount) || 0).toLocaleString()} F</td>
                <td style="padding: 5px 8px; border: 1px solid #ddd;">${t.paymentMethod || 'PayDunya'}</td>
                <td style="padding: 5px 8px; border: 1px solid #ddd; font-size: 11px;">${t.date ? new Date(t.date).toLocaleDateString('fr-FR') : '-'}</td>
                <td style="padding: 5px 8px; border: 1px solid #ddd; text-align: center; color: #059669; font-weight: bold;">VALIDÉ</td>
            </tr>
        `;
    });

    const printContainer = document.createElement('div');
    printContainer.id = 'pure-data-print-container';
    printContainer.style.position = 'fixed';
    printContainer.style.inset = '0';
    printContainer.style.background = '#ffffff';
    printContainer.style.color = '#111827';
    printContainer.style.zIndex = '999999';
    printContainer.style.overflow = 'auto';
    printContainer.style.padding = '2rem';
    printContainer.style.fontFamily = 'system-ui, -apple-system, sans-serif';

    printContainer.innerHTML = `
        <div style="max-width: 900px; margin: 0 auto;">
            <!-- Print Header -->
            <div style="display: flex; justify-content: space-between; align-items: flex-start; border-bottom: 2px solid #111827; padding-bottom: 1rem; margin-bottom: 1.5rem;">
                <div>
                    <h1 style="margin: 0; font-size: 20px; font-weight: 900; letter-spacing: -0.5px; color: #F26B21;">THIES RESTO — ÉTAT FINANCIER &amp; SAAS</h1>
                    <p style="margin: 4px 0 0 0; font-size: 12px; color: #4B5563;">Plateforme de Commande et Livraison de Repas à Thiès</p>
                </div>
                <div style="text-align: right;">
                    <div style="font-size: 12px; font-weight: bold;">Rapport de Données Réelles</div>
                    <div style="font-size: 11px; color: #6B7280;">Généré le : ${dateStr}</div>
                </div>
            </div>

            <!-- Synthèse KPI Data -->
            <div style="display: grid; grid-template-columns: repeat(4, 1fr); gap: 12px; margin-bottom: 1.5rem;">
                <div style="border: 1px solid #E5E7EB; border-radius: 6px; padding: 10px; background: #F9FAFB;">
                    <div style="font-size: 10px; text-transform: uppercase; color: #6B7280; font-weight: bold;">Total SaaS Encaissé</div>
                    <div style="font-size: 16px; font-weight: 900; color: #059669; margin-top: 2px;">${totalCollected.toLocaleString()} FCFA</div>
                </div>
                <div style="border: 1px solid #E5E7EB; border-radius: 6px; padding: 10px; background: #F9FAFB;">
                    <div style="font-size: 10px; text-transform: uppercase; color: #6B7280; font-weight: bold;">Partenaires Actifs</div>
                    <div style="font-size: 16px; font-weight: 900; color: #111827; margin-top: 2px;">${restos.length} Restaurants</div>
                </div>
                <div style="border: 1px solid #E5E7EB; border-radius: 6px; padding: 10px; background: #F9FAFB;">
                    <div style="font-size: 10px; text-transform: uppercase; color: #6B7280; font-weight: bold;">Commandes Réseau</div>
                    <div style="font-size: 16px; font-weight: 900; color: #111827; margin-top: 2px;">${completedOrders.length} livrées / ${allOrders.length}</div>
                </div>
                <div style="border: 1px solid #E5E7EB; border-radius: 6px; padding: 10px; background: #F9FAFB;">
                    <div style="font-size: 10px; text-transform: uppercase; color: #6B7280; font-weight: bold;">Chiffre d'Affaires Brut</div>
                    <div style="font-size: 16px; font-weight: 900; color: #2563EB; margin-top: 2px;">${totalGmv.toLocaleString()} FCFA</div>
                </div>
            </div>

            <!-- Table 1: Données Partenaires & Abonnements -->
            <h2 style="font-size: 13px; font-weight: 800; margin: 0 0 8px 0; text-transform: uppercase; color: #1F2937;">1. Données Détaillées par Restaurant</h2>
            <table style="width: 100%; border-collapse: collapse; font-size: 11px; margin-bottom: 2rem;">
                <thead>
                    <tr style="background: #F3F4F6;">
                        <th style="padding: 6px 8px; border: 1px solid #ddd; text-align: center; width: 30px;">#</th>
                        <th style="padding: 6px 8px; border: 1px solid #ddd; text-align: left;">Restaurant</th>
                        <th style="padding: 6px 8px; border: 1px solid #ddd; text-align: left;">Catégorie</th>
                        <th style="padding: 6px 8px; border: 1px solid #ddd; text-align: left;">Quartier</th>
                        <th style="padding: 6px 8px; border: 1px solid #ddd; text-align: left;">Pack Souscrit</th>
                        <th style="padding: 6px 8px; border: 1px solid #ddd; text-align: right;">SaaS Encaissé</th>
                        <th style="padding: 6px 8px; border: 1px solid #ddd; text-align: center;">Commandes</th>
                        <th style="padding: 6px 8px; border: 1px solid #ddd; text-align: right;">C.A. Menus</th>
                    </tr>
                </thead>
                <tbody>
                    ${rowsHtml}
                </tbody>
            </table>

            <!-- Table 2: Journal des Transactions Réelles -->
            <h2 style="font-size: 13px; font-weight: 800; margin: 0 0 8px 0; text-transform: uppercase; color: #1F2937;">2. Journal des Encaissements &amp; Transactions (${paytechTxs.length})</h2>
            <table style="width: 100%; border-collapse: collapse; font-size: 11px; margin-bottom: 2rem;">
                <thead>
                    <tr style="background: #F3F4F6;">
                        <th style="padding: 6px 8px; border: 1px solid #ddd; text-align: center; width: 30px;">#</th>
                        <th style="padding: 6px 8px; border: 1px solid #ddd; text-align: left;">Réf. Transaction</th>
                        <th style="padding: 6px 8px; border: 1px solid #ddd; text-align: left;">Bénéficiaire</th>
                        <th style="padding: 6px 8px; border: 1px solid #ddd; text-align: left;">Objet</th>
                        <th style="padding: 6px 8px; border: 1px solid #ddd; text-align: right;">Montant</th>
                        <th style="padding: 6px 8px; border: 1px solid #ddd; text-align: left;">Moyen de Paiement</th>
                        <th style="padding: 6px 8px; border: 1px solid #ddd; text-align: left;">Date</th>
                        <th style="padding: 6px 8px; border: 1px solid #ddd; text-align: center;">Statut</th>
                    </tr>
                </thead>
                <tbody>
                    ${txRowsHtml || '<tr><td colspan="8" style="text-align: center; padding: 10px; border: 1px solid #ddd; color: #6B7280;">Aucune transaction enregistrée</td></tr>'}
                </tbody>
            </table>

            <!-- Actions buttons before printing -->
            <div id="print-controls" style="display: flex; gap: 10px; justify-content: flex-end; padding-top: 1rem; border-top: 1px solid #E5E7EB;">
                <button onclick="document.getElementById('pure-data-print-container').remove()" style="padding: 8px 16px; background: #E5E7EB; border: none; border-radius: 6px; font-weight: bold; cursor: pointer;">
                    Fermer
                </button>
                <button onclick="window.print()" style="padding: 8px 16px; background: #F26B21; color: white; border: none; border-radius: 6px; font-weight: bold; cursor: pointer;">
                    <i class='ri-printer-line'></i>️ Imprimer / Enregistrer en PDF
                </button>
            </div>
        </div>
    `;

    document.body.appendChild(printContainer);
};

// ==========================================
// REAL-TIME SYNCHRONIZATION EVENT LISTENERS
// ==========================================
if (typeof window !== 'undefined') {
    window.addEventListener('thies_orders_live_update', (e) => {
        const { newOrders, hasStatusChange } = (e && e.detail) || {};

        // 1. Restaurant Dashboard active session:
        if (typeof currentRestaurantSession !== 'undefined' && currentRestaurantSession) {
            const myOrders = (newOrders || []).filter(o => o.restaurantId === currentRestaurantSession.id);
            if (myOrders.length > 0) {
                // Play notification bell chime
                if (typeof window.playOrderAlertSound === 'function') {
                    window.playOrderAlertSound();
                }

                myOrders.forEach(o => {
                    const client = o.customerName || 'Client';
                    const totalFormatted = (Number(o.total) || 0).toLocaleString();
                    if (typeof showToast === 'function') {
                        showToast(` NOUVELLE COMMANDE REÇUE : Commande n°${o.orderNumber || o.id} de ${client} (${totalFormatted} FCFA) !`, 'success', 8000);
                    }
                });

                // Auto-refresh restaurant dashboard view if viewing orders or accounting
                if (typeof dashboardActiveTab !== 'undefined' && (dashboardActiveTab === 'orders' || dashboardActiveTab === 'accounting' || dashboardActiveTab === 'overview')) {
                    if (document.getElementById('dashboard-tab-panel')) {
                        const r = store.getRestaurantById(currentRestaurantSession.id);
                        if (r && typeof renderDashboardTabContent === 'function') {
                            renderDashboardTabContent(r);
                        }
                    }
                    if (typeof renderMobileBottomNav === 'function') {
                        renderMobileBottomNav();
                    }
                }
            } else if (hasStatusChange && typeof dashboardActiveTab !== 'undefined') {
                if (document.getElementById('dashboard-tab-panel')) {
                    const r = store.getRestaurantById(currentRestaurantSession.id);
                    if (r && typeof renderDashboardTabContent === 'function') {
                        renderDashboardTabContent(r);
                    }
                }
                if (typeof renderMobileBottomNav === 'function') {
                    renderMobileBottomNav();
                }
            }
        }

        // 2. Super-Admin active session:
        if (typeof isSuperAdminSession !== 'undefined' && isSuperAdminSession) {
            if (newOrders && newOrders.length > 0) {
                if (typeof window.playOrderAlertSound === 'function') {
                    window.playOrderAlertSound();
                } else if (typeof playNotificationSound === 'function') {
                    playNotificationSound();
                }
                newOrders.forEach(o => {
                    const client = o.customerName || 'Client';
                    const totalFormatted = (Number(o.total) || 0).toLocaleString();
                    const resto = (typeof store !== 'undefined' && store.getRestaurantById) ? store.getRestaurantById(o.restaurantId) : null;
                    const rName = resto ? resto.name : (o.restaurantName || o.restaurantId);
                    if (typeof showToast === 'function') {
                        showToast(`NOUVELLE COMMANDE : ${client} chez ${rName} (${totalFormatted} FCFA)`, 'info', 7000);
                    }
                });
            }
            if (typeof renderAdminTabTable === 'function') {
                renderAdminTabTable();
            }
        }
    });

    window._notifiedPartnerIds = window._notifiedPartnerIds || new Set();

    window.addEventListener('thies_restaurants_live_update', (e) => {
        const { restaurants, newPending } = (e && e.detail) || {};
        // When restaurants change (new partner registered, status updated, subscription changed):
        if (typeof isSuperAdminSession !== 'undefined' && isSuperAdminSession) {
            if (newPending && newPending.length > 0) {
                const trulyNew = newPending.filter(p => p && p.id && !window._notifiedPartnerIds.has(String(p.id)));
                if (trulyNew.length > 0) {
                    if (typeof window.playOrderAlertSound === 'function') {
                        window.playOrderAlertSound();
                    } else if (typeof playNotificationSound === 'function') {
                        playNotificationSound();
                    }
                    trulyNew.forEach(p => {
                        window._notifiedPartnerIds.add(String(p.id));
                        if (typeof showToast === 'function') {
                            showToast(`NOUVELLE DEMANDE PARTENAIRE : Le restaurant « ${p.name} » attend votre validation !`, 'warning', 10000);
                        }
                    });
                }
            }
            if (typeof renderAdminTabTable === 'function') {
                renderAdminTabTable();
            } else if (typeof renderAdminView === 'function') {
                renderAdminView();
            }
        }
    });
}


