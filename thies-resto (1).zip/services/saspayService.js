import crypto from 'crypto';

/**
 * SASPAY Payment Gateway Integration Service for THIES Resto
 * Aggregates Wave, Orange Money, Free Money, YAS, and Cards in Senegal / UEMOA.
 * Official platform: https://saspay.me
 * API Documentation: https://docs.saspay.me
 */

// Default key provided by store owner for production
const DEFAULT_SASPAY_KEY = 'sk_live_N1hhuFV1Cp9xg9ub544QLDWyAMXkNjJpko2V3qjUZIQ';

export function getSaspayApiKey() {
  return process.env.SASPAY_API_KEY || DEFAULT_SASPAY_KEY;
}

export function getSaspaySecretKey() {
  return process.env.SASPAY_SECRET_KEY || getSaspayApiKey();
}

export function getSaspayEnv() {
  return process.env.SASPAY_ENV || 'prod';
}

export function isSaspayConfigured() {
  const key = getSaspayApiKey();
  return Boolean(key && key.trim().startsWith('sk_'));
}

/**
 * Initiates a hosted checkout session with SASPAY API.
 * Endpoint: POST https://api.saspay.me/api/v1/checkout-sessions/
 * 
 * @param {Object} params
 * @param {string} params.orderId - Unique order or subscription reference
 * @param {number} params.amount - Total amount in FCFA
 * @param {string} [params.itemName] - Name of the item/order being paid
 * @param {string} [params.customerName] - Customer or Restaurant Manager name
 * @param {string} [params.customerPhone] - Mobile phone number
 * @param {string} [params.customerEmail] - Customer email address
 * @param {string} [params.restaurantName] - Partner restaurant name
 * @param {string} [params.successUrl] - Return URL after successful payment
 * @param {string} [params.cancelUrl] - Return URL after cancellation
 * @param {string} [params.webhookUrl] - Webhook callback URL
 * @returns {Promise<Object>} Result with checkoutUrl and reference
 */
export async function createSaspayCheckoutSession({
  orderId,
  amount,
  itemName = '',
  customerName = '',
  customerPhone = '',
  customerEmail = '',
  restaurantName = 'THIES Resto',
  successUrl,
  cancelUrl,
  webhookUrl
}) {
  const apiKey = getSaspayApiKey();
  const numericAmount = Math.max(100, Math.round(Number(amount) || 0));
  const cleanRef = `SAS_${String(orderId).replace(/[^a-zA-Z0-9_-]/g, '')}_${Date.now()}`;

  if (!isSaspayConfigured()) {
    console.warn('[SASPAY Service] Clé API SASPAY non configurée.');
    return {
      success: false,
      notConfigured: true,
      message: 'La passerelle SASPAY n\'est pas encore configurée. Les paiements directs Wave / Orange Money et Cash restent actifs.',
      refCommand: cleanRef,
      amount: numericAmount
    };
  }

  // Format valid phone number with Senegal country code if applicable
  let formattedPhone = String(customerPhone || '').replace(/[^0-9]/g, '');
  if (formattedPhone.length === 9 && (formattedPhone.startsWith('7') || formattedPhone.startsWith('3'))) {
    formattedPhone = `221${formattedPhone}`;
  }

  // Ensure an email address is provided as required by SasPay checkout sessions
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  let finalEmail = (customerEmail && emailRegex.test(customerEmail)) ? customerEmail : '';
  if (!finalEmail) {
    // Generate a contextual customer email for receipt tracking if not provided
    const cleanPhone = formattedPhone || 'client';
    finalEmail = `client.${cleanPhone}@thiesresto.sn`;
  }

  const payload = {
    amount: (numericAmount).toFixed(2),
    currency: 'XOF',
    description: itemName || `Commande ${orderId} - ${restaurantName}`,
    customer_name: customerName || 'Client THIES Resto',
    customer_email: finalEmail,
    customer_phone: formattedPhone || undefined,
    return_url: successUrl || '',
    metadata: {
      orderId: String(orderId),
      restaurantName,
      reference: cleanRef,
      source: 'THIES_RESTO_PLATFORM'
    }
  };

  try {
    const apiBase = 'https://api.saspay.me';
    // Note: SasPay API requires the trailing slash on /checkout-sessions/
    const response = await fetch(`${apiBase}/api/v1/checkout-sessions/`, {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${apiKey}`
      },
      body: JSON.stringify(payload)
    });

    const result = await response.json().catch(() => ({}));

    // SasPay responds with: { success: true, data: { checkout_url, id, slug, ... } }
    const sessionData = result?.data || result;
    const checkoutUrl = sessionData?.checkout_url || sessionData?.payment_url || sessionData?.url;

    if (response.ok && (result.success !== false) && checkoutUrl) {
      return {
        success: true,
        checkoutUrl: checkoutUrl,
        redirectUrl: checkoutUrl,
        token: sessionData.id || sessionData.slug || cleanRef,
        sessionId: sessionData.id,
        refCommand: cleanRef,
        amount: numericAmount,
        provider: 'SASPAY'
      };
    } else {
      console.warn('[SASPAY API Response Notice]:', result);
      const errMsg = (result?.error && typeof result.error === 'object')
        ? Object.entries(result.error).map(([k, v]) => `${k}: ${Array.isArray(v) ? v.join(', ') : v}`).join(' | ')
        : (result?.message || result?.error || 'Erreur lors de la génération de la session de paiement SASPAY.');
      
      return {
        success: false,
        message: errMsg,
        raw: result,
        refCommand: cleanRef
      };
    }
  } catch (error) {
    console.error('[SASPAY Service Exception]:', error);
    return {
      success: false,
      message: 'Impossible de joindre le serveur SASPAY. Veuillez vérifier votre connexion.',
      error: error.message,
      refCommand: cleanRef
    };
  }
}

/**
 * Verifies payment status directly from SasPay
 * Endpoint: GET https://api.saspay.me/api/v1/payments/{payment_id}/verify/
 */
export async function verifySaspayPayment(paymentId) {
  if (!paymentId) return { success: false, message: 'paymentId requis' };
  const apiKey = getSaspayApiKey();

  try {
    const res = await fetch(`https://api.saspay.me/api/v1/payments/${paymentId}/verify/`, {
      method: 'GET',
      headers: {
        'Accept': 'application/json',
        'Authorization': `Bearer ${apiKey}`
      }
    });
    const data = await res.json().catch(() => ({}));
    return { success: res.ok, data };
  } catch (err) {
    return { success: false, error: err.message };
  }
}

/**
 * Validates SASPAY Webhook / IPN signature
 */
export function verifySaspayWebhookSignature(headers, body) {
  const secretKey = getSaspaySecretKey();
  if (!secretKey) return true;

  const signature = headers['x-saspay-signature'] || headers['x-signature'] || '';
  if (!signature) return true;

  try {
    const rawBody = typeof body === 'string' ? body : JSON.stringify(body);
    const computed = crypto.createHmac('sha256', secretKey).update(rawBody).digest('hex');
    return computed === signature;
  } catch (e) {
    return true;
  }
}
